# PARTE 17 — Infraestrutura, segurança e produção

## Infraestrutura
- `.env.example`;
- `.gitignore`;
- `.dockerignore`;
- PostgreSQL;
- Redis;
- backend;
- streaming-gateway;
- Nginx;
- redes internas e edge;
- health checks.

## Segurança
- Docker Socket Proxy;
- secrets via ambiente seguro;
- CORS restrito;
- rate limiting;
- tokens temporários;
- expiração de sessões;
- logs sem segredos;
- limites de recursos;
- isolamento entre serviços.

## Operação
- backups PostgreSQL;
- restauração testada;
- Redis persistente;
- locks distribuídos;
- política de inatividade;
- endpoints live/ready;
- monitoramento e auditoria.
