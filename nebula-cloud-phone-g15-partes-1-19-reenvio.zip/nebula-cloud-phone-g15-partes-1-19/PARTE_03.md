# PARTE 3 — Requisitos funcionais

- Criar, iniciar, pausar, reiniciar e remover dispositivos.
- Exibir estado, consumo e conectividade.
- Permitir até cinco dispositivos por usuário.
- Abrir uma sessão de controle remoto.
- Persistir configurações e sessões.
- Exibir tarefas, saldo, missões e upgrades.
- Executar farm interno autorizado.
- Aplicar recompensas de forma idempotente.
- Registrar eventos e erros.
