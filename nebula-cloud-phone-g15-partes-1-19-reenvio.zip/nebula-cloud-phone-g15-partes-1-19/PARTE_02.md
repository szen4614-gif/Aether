# PARTE 2 — Arquitetura e organização

## Camadas
1. Cliente Android.
2. API e autenticação.
3. Serviços de domínio.
4. Orquestrador de cloud phones.
5. Streaming.
6. Persistência.
7. Infraestrutura.

## Estrutura sugerida
```text
nebula-cloud-phone-g15/
├── android/
├── backend/
├── cloud-phone/
├── streaming-gateway/
├── database/
├── infra/
├── docs/
└── .github/workflows/
```

Cada camada deve possuir responsabilidades claras, contratos estáveis e testes próprios.
