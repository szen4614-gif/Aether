# PARTE 18 — Testes, build, CI/CD e entrega

## Testes
- máquina de estados;
- limite de cinco dispositivos;
- autenticação;
- autorização;
- carteira;
- idempotência;
- farm;
- integração com PostgreSQL;
- integração com Docker;
- API;
- UI Android.

## CI
- compilação do backend;
- testes;
- compilação Android;
- validação de migrations;
- build de imagens;
- lint;
- artefatos.

## Release
- versionamento semântico;
- assinatura APK por secrets;
- workflow de release;
- publicação de artefatos;
- checklist de aprovação.
