# PARTE 15 — Aplicativo Android

## Camadas
- `data`;
- `domain`;
- `ui`;
- `navigation`;
- `streaming`;
- `auth`.

## Telas principais
- Login;
- Dashboard;
- DeviceCard;
- Cloud phone details;
- Streaming;
- Farm;
- Wallet;
- Missions;
- Upgrades;
- Settings.

O aplicativo deve refletir os estados reais vindos da API, não estados Boolean locais ou respostas simuladas.
