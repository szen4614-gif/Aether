# PARTE 9 — Farm e economia

O farm deve ser um sistema interno e autorizado da própria plataforma.

## Componentes
- trabalhos de farm;
- duração;
- recompensa;
- cooldown;
- carteira;
- transações;
- missões;
- upgrades;
- reset mensal.

## Segurança
- idempotência;
- validação no servidor;
- nenhuma execução arbitrária;
- nenhuma automação de jogos de terceiros;
- nenhum bypass de CAPTCHA, Play Integrity ou mecanismos antifraude.
