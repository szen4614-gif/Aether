# PARTE 1 — Visão geral do projeto

## Objetivo
Construir o Nebula Cloud Phone G15: uma plataforma Android de cloud phone com até cinco dispositivos virtuais por usuário, painel mobile, streaming remoto, persistência, autenticação, farm AFK interno, economia, missões, upgrades e automação de build.

## Princípios
- Arquitetura modular.
- Segurança por padrão.
- Estado persistente e reconciliável.
- Limites rígidos de recursos.
- Compatibilidade com Android e dispositivos móveis.
- Nenhuma automação abusiva de jogos ou serviços de terceiros.

## Componentes
- Aplicativo Android.
- Backend HTTP/WebSocket.
- Runtime de dispositivos virtuais.
- Gateway de streaming.
- PostgreSQL.
- Redis.
- Proxy reverso.
- CI/CD com GitHub Actions.
