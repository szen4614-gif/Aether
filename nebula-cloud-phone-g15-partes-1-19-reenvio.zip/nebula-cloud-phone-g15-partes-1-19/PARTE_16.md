# PARTE 16 — Farm, economia e missões

## Entidades
- `FarmJob`;
- `WalletTransaction`;
- `Mission`;
- `UserMissionProgress`;
- `UserUpgrade`.

## Regras
- recompensa calculada no servidor;
- transação idempotente;
- bloqueio contra duplicidade;
- logs de auditoria;
- limites de duração e recompensa;
- tarefas diárias;
- reset mensal;
- upgrades com custo e efeitos verificáveis.

## Rotas
- iniciar trabalho;
- consultar trabalho;
- coletar recompensa;
- consultar carteira;
- listar missões;
- resgatar missão;
- listar e comprar upgrades.
