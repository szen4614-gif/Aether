# PARTE 19 — Auditoria final

## Níveis
1. Estrutura criada.
2. Funcionalidade implementada.
3. Funcionalidade validada em ambiente real.

## Correções obrigatórias
- substituir respostas fixas;
- validar imagem Android;
- validar boot, ADB, display e captura;
- implementar streaming real;
- completar autenticação;
- bloquear comandos arbitrários;
- integrar Android e backend;
- corrigir imports, versões e APIs;
- executar testes e workflows.

## MVP aprovado quando
- usuário consegue autenticar;
- criar até cinco dispositivos;
- iniciar e parar dispositivos;
- visualizar estado real;
- abrir streaming;
- executar farm interno;
- receber recompensas sem duplicação;
- usar missões e upgrades;
- recuperar estado após reinício;
- gerar build reproduzível.

## Release inicial
Preparar a versão `v0.1.0` somente após validação de ponta a ponta.
