# PARTE 12 — Orquestrador

Criar uma abstração `CloudRuntime` para desacoplar o backend do Docker.

## Operações
- create;
- start;
- stop;
- restart;
- inspect;
- remove;
- logs;
- health.

O worker de reconciliação deve comparar o estado persistido com o estado real dos containers, corrigindo divergências sem duplicar recursos.

O limite de cinco dispositivos deve ser aplicado transacionalmente no backend.
