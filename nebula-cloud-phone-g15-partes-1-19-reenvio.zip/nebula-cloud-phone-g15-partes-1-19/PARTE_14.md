# PARTE 14 — Streaming remoto

## Gateway
- autenticar tokens temporários;
- associar usuário a dispositivo;
- abrir sessão;
- encaminhar vídeo;
- encaminhar eventos de entrada;
- controlar reconexão;
- encerrar sessões expiradas.

## Eventos
- touch;
- swipe;
- key;
- back;
- home;
- recent_apps;
- rotate;
- ping.

A implementação WebRTC real deve ser testada em rede móvel, Wi-Fi, NAT e com perda de pacotes. WebSocket pode ser usado para sinalização e controle.
