# PARTE 11 — Backend funcional

## Contratos
Implementar modelos de usuário, dispositivo, sessão, farm, carteira, missão e upgrade.

## Estados de dispositivo
- STOPPED
- STARTING
- RUNNING
- STOPPING
- ERROR
- DESTROYED

## Serviços
- autenticação;
- autorização;
- gerenciamento de dispositivos;
- health check;
- persistência;
- rate limiting;
- auditoria.

## Rotas
- `/health/live`
- `/health/ready`
- `/api/v1/auth/*`
- `/api/v1/cloud/*`
- `/api/v1/farm/*`
- `/api/v1/economy/*`
- `/api/v1/missions/*`
- `/api/v1/upgrades/*`
