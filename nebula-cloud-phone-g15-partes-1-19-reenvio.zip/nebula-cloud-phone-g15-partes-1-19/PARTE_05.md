# PARTE 5 — Modelo visual e experiência

## Direção visual
Interface futurista, limpa e legível, com inspiração em painéis de controle de nave/terminal, sem sacrificar acessibilidade.

## Telas
- Login e cadastro.
- Dashboard.
- Lista de cloud phones.
- Tela de streaming.
- Farm.
- Economia e carteira.
- Missões.
- Loja e upgrades.
- Configurações.

## Regras de UX
- Estados sempre visíveis.
- Ações destrutivas com confirmação.
- Feedback de carregamento e erro.
- Layout responsivo.
- Botões grandes para uso em celular.
