# PARTE 8 — Aplicativo Android

## Tecnologias
- Kotlin.
- Jetpack Compose.
- Navigation.
- ViewModel.
- DataStore.
- Cliente HTTP.
- WebSocket/WebRTC conforme o gateway.

## Responsabilidades
- autenticação;
- armazenamento seguro de sessão;
- dashboard;
- gerenciamento de dispositivos;
- streaming;
- farm;
- missões;
- carteira;
- tratamento de estados offline e erro.
