# PARTE 10 — Integração e entrega

O fluxo completo deve conectar:

```text
Android → API → Banco/Redis → Orquestrador → Container Android
                         ↘ Gateway de streaming
```

A entrega deve incluir:
- código;
- Dockerfiles;
- Compose;
- migrations;
- workflows;
- testes;
- documentação;
- instruções de configuração;
- APK ou processo reproduzível de geração do APK.
