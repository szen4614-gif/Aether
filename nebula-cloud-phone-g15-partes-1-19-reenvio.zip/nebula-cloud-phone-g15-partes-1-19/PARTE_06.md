# PARTE 6 — Backend

## Stack
- Kotlin.
- Ktor.
- PostgreSQL.
- Redis.
- HikariCP.
- Exposed ou camada SQL equivalente.
- BCrypt/Argon2 para senhas.
- JWT ou tokens de sessão rotacionáveis.

## Módulos
- auth
- users
- cloud
- streaming
- farm
- economy
- missions
- upgrades
- health
- audit

O backend deve substituir respostas fixas por serviços reais e persistentes.
