# PARTE 13 — Android virtualizado

## Container
O container deve fornecer:
- sistema Android;
- boot verificável;
- ADB;
- display;
- captura de tela;
- entrada touch;
- limites de CPU, RAM, PIDs e memória compartilhada;
- volumes persistentes.

Uma imagem como `redroid` pode ser investigada, mas a tag exata deve ser validada antes da entrega. O esqueleto original não continha Android funcional.
