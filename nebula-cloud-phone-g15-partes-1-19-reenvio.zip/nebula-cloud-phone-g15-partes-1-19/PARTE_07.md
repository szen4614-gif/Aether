# PARTE 7 — Cloud phone

O runtime deve criar e administrar containers Android virtualizados.

## Operações
- provisionar;
- iniciar;
- parar;
- reiniciar;
- coletar health;
- remover;
- reconciliar estado.

A imagem Android, a versão da tag, o boot, o ADB, o display e a captura precisam ser validados durante a implementação real. O arquivo inicial era apenas um esqueleto e não fornecia Android funcional.
