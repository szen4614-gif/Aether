# PARTE 4 — Requisitos não funcionais

- Baixa latência no controle remoto.
- Recuperação automática após falhas.
- Logs estruturados.
- Health checks.
- Rate limiting.
- Isolamento de containers.
- Segredos fora do código.
- Backups e restauração.
- Build reproduzível.
- Compatibilidade com Android moderno e telas pequenas.
