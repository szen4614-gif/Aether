# Recovery

States: NORMAL → CRASHED → DIAGNOSE → SAFE_MODE → LAST_KNOWN_GOOD → RECOVERED. Recovery never deletes saves and never silently changes user content.
