# Changelog

## 0.2.1-validation-gates

- Added real Android instrumentation validation tests.
- Added Android 15 16 KB emulator CI job.
- Added physical-device self-hosted validation workflow.
- Added Minecraft Java self-hosted end-to-end workflow.
- Added real JVM process supervision in `N10LaunchService`.
- Added Android JVM environment construction with `JAVA_HOME`, `LD_LIBRARY_PATH`, `TMPDIR`, XDG paths and native directory.
- Added runtime/LWJGL provisioning contract documentation.
- Added device diagnostics collection for page size, thermal, display, memory and gfxinfo.
- Added explicit evidence-based promotion gates for `IMPLEMENTED` vs `VALIDATED`.

## Research basis

The Android 16 KB path follows Android's current guidance: AGP 8.5.1+ and NDK r28+ are the recommended baseline, with ELF and ZIP alignment checks and 16 KB emulator testing. See `docs/RESEARCH_SOURCES.md`.
