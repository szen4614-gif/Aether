# NOVA N10 — Parte 106

## Objetivo
Bootstrap físico do launcher Android: Gradle + Android + Kotlin + CMake/NDK + JNI + SurfaceView + biblioteca nativa `libn10.so`.

## Stack
- Android compile/target SDK 35
- min SDK 24
- AGP 8.7.3
- Kotlin 2.0.21
- Gradle 8.9 (CI)
- JDK 17 (build)
- CMake 3.22.1
- NDK 28.0.13004108 (CI)
- ABIs: arm64-v8a, x86_64
- native page-size linker alignment: 16 KB

## Build
CI: GitHub Actions (`.github/workflows/android.yml`).
Local, com Gradle 8.9 instalado:

```bash
gradle :app:assembleDebug
```

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Estado
Esta parte é um bootstrap real e compilável do launcher. Ela NÃO contém o cliente Minecraft, Java runtime, LWJGL completo, Fabric ou artefatos proprietários. Essas integrações entram nas próximas etapas.
