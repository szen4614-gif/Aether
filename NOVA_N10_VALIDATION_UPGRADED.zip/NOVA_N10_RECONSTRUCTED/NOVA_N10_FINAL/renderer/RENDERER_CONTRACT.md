# Renderer contract

Backend selection is capability-driven. Candidate backends are represented as contracts until native implementations are connected and benchmarked. Vulkan may be preferable on suitable hardware, but N10 never assumes it is universally faster. OpenGL/GLES/translation paths remain explicit fallbacks.
