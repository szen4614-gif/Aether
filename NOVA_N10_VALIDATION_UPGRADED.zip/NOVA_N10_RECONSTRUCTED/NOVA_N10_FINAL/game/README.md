# Minecraft execution

This directory defines the execution boundary. Real Minecraft artifacts, manifests, libraries, assets, natives and authentication must be supplied by their real providers. Nothing in this repository pretends those payloads are present.
