# CurseForge adapter boundary

CurseForge integration remains an external dependency because API credentials, access terms and redistribution rules must be supplied/configured by the deployment. The adapter contract accepts normalized project/version/file records so the core does not depend on a specific provider.
