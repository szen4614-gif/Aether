# Modrinth adapter

Uses the official v2 API contract for project versions/dependencies. Requests must include an identifying User-Agent and obey current rate limits/terms. The adapter stores source ID, project ID, version ID, file hash and license/provenance metadata.
