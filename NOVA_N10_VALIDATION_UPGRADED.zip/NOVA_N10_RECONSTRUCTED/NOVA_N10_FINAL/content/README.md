# N10 Content Hub

Content is referenced by source/project/version/file identifiers and hashes. N10 prefers official APIs or direct source links, preserves attribution/licensing, resolves dependencies before installation and keeps content isolated per instance.

Adapters are intentionally separated from the core so a source can be disabled without breaking launcher execution.
