# NOVA N10

NOVA N10 is an Android launcher/runtime platform under real engineering development for Minecraft Java Edition. The repository contains executable Android/native code, launcher contracts, artifact integrity primitives, an APEX performance foundation, and a merged CPU visual reference pipeline.

## Truth policy
The project never treats an interface or document as proof of implementation. Allowed states are:
`IMPLEMENTED`, `PARTIAL`, `SCAFFOLD`, `EXPERIMENTAL`, `EXTERNAL-DEPENDENCY`, `NOT-IMPLEMENTED`, `NOT-VALIDATED`.

End-to-end Minecraft Java execution is **NOT-VALIDATED** until a real Java runtime, real authentication, real game artifacts, a compatible renderer and an Android device/emulator have been exercised together.

## Consolidated sources
- `NOVA_N10_FIRST_TEST`: source of the merged N10 CPU visual reference pipeline.
- `N10_APEX_Renderer_FINAL_Forge_1.20.1`: source of the APEX native frame/visibility/command-stream reference and Forge lifecycle integration. Forge code remains a separate integration surface.
- `AI_AUDIT_REPORT.md`: evidence-backed audit and consolidation result.
- `docs/IMPLEMENTATION_MATRIX.md`: system-by-system decision matrix.

## Build
See `docs/BUILD.md`. CI provisions JDK 17, Gradle 8.9, AGP 8.7.3, SDK 35, NDK r28 and CMake 3.22.1.

## Current gate
The Android Gradle build is not validated in the present offline audit environment because no Gradle installation/wrapper was available. This limitation is explicitly recorded rather than hidden.

## Deep-research implementation status
The 2026-09-16 upgrade adds executable implementations for Microsoft auth, runtime installation/process supervision, Mojang vanilla artifacts, CurseForge access, Vulkan/GLES capability detection, Android Thermal/ADPF, benchmark sessions and 16 KB validation tooling. Device validation and Minecraft/LWJGL end-to-end execution remain evidence gates.
