# Compatibility graph

`Minecraft → Java → Loader → Mod → LWJGL → Native ABI → Renderer → Driver → GPU → Android`.

Every edge carries state, evidence and source. Unknown is preferable to guessing.
