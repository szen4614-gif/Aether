# Third-party / provenance notices

NOVA N10 does not redistribute Minecraft proprietary files.

The current tree consolidates source code supplied in:
- NOVA_N10_FIRST_TEST-1.zip
- N10_APEX_Renderer_FINAL_Forge_1.20.1.zip

Those supplied sources remain subject to their own licensing/provenance requirements. Before redistributing any external JRE, renderer, translation layer, Java library, Minecraft-adjacent binary or content-provider payload, record its exact version, license, source URL, checksum and redistribution permission.

Known upstream projects referenced by the supplied documentation include PojavLauncher, Amethyst-Android, Fold Craft Launcher, LWJGL, GL4ES, ANGLE, Mesa and OpenAL Soft. No license grant for those projects is implied by this repository.
