plugins { id("com.android.library"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.nova.n10.core"; compileSdk = 35; defaultConfig { minSdk = 24 } }
