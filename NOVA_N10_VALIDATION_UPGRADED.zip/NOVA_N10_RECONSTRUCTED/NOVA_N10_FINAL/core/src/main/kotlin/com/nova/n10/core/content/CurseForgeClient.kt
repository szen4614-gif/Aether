package com.nova.n10.core.content

import com.nova.n10.core.network.HttpArtifactClient
import java.net.URLEncoder
import org.json.JSONObject

/** Real CurseForge REST adapter. The API key is supplied by the application owner at runtime. */
class CurseForgeClient(private val apiKey:String, private val http:HttpArtifactClient=HttpArtifactClient("NOVA-N10/1.0 (CurseForge adapter)")) {
    init { require(apiKey.isNotBlank()) { "CurseForge API key is required" } }
    fun file(modId:Long,fileId:Long):String = get("https://api.curseforge.com/v1/mods/$modId/files/$fileId")
    fun search(gameId:Int,gameVersion:String,modLoaderType:Int?,query:String?=null):String {
        val q=buildString { append("https://api.curseforge.com/v1/mods/search?gameId=$gameId&gameVersion=${URLEncoder.encode(gameVersion,"UTF-8")}"); if(modLoaderType!=null) append("&modLoaderType=$modLoaderType"); if(!query.isNullOrBlank()) append("&searchFilter=${URLEncoder.encode(query,"UTF-8")}") }
        return get(q)
    }
    private fun get(url:String):String = http.open(url,"GET","application/json",null,mapOf("x-api-key" to apiKey,"Accept" to "application/json")).second.use{it.readBytes().toString(Charsets.UTF_8)}
}
