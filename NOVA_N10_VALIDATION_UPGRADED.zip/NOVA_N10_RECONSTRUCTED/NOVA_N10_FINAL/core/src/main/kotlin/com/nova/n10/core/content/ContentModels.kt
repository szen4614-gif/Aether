package com.nova.n10.core.content

enum class ContentType { MOD, MODPACK, SHADER, RESOURCE_PACK, WORLD, DATA_PACK }

data class ContentArtifact(
    val provider: String,
    val projectId: String,
    val versionId: String,
    val name: String,
    val type: ContentType,
    val minecraftVersions: List<String>,
    val loaders: List<String>,
    val downloadUrl: String?,
    val sha512: String?,
    val requiredDependencies: List<String> = emptyList(),
    val license: String? = null
)
