package com.nova.n10.core.security

import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path

/** Prevents lexical traversal and symlink escapes from a trusted root. */
object PathGuard {
    fun child(root: Path, relative: String): Path {
        require(relative.isNotBlank()) { "Relative path is empty" }
        require(!relative.contains('\u0000')) { "Path contains NUL" }
        val normalizedRoot = root.toAbsolutePath().normalize()
        val candidate = normalizedRoot.resolve(relative).normalize()
        require(candidate.startsWith(normalizedRoot)) { "Path escapes instance root" }
        if (Files.exists(candidate, LinkOption.NOFOLLOW_LINKS)) {
            val realRoot = normalizedRoot.toRealPath()
            val realCandidate = candidate.toRealPath()
            require(realCandidate.startsWith(realRoot)) { "Symlink escapes instance root" }
        }
        return candidate
    }
}
