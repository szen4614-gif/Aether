package com.nova.n10.core.runtime

import com.nova.n10.core.network.HttpArtifactClient
import org.json.JSONObject

/** Discovers real Android JRE release assets from a configured upstream repository. */
class GitHubRuntimeCatalog(
    private val owner:String = "PojavLauncherTeam",
    private val repo:String = "android-openjdk-build-multiarch",
    private val http:HttpArtifactClient = HttpArtifactClient("NOVA-N10/1.0 (runtime-catalog)")
) {
    data class Candidate(val id:String,val url:String,val assetName:String,val releaseTag:String)
    fun latest(javaMajor:Int, architecture:String):Candidate? {
        val text=http.openBytes("https://api.github.com/repos/$owner/$repo/releases?per_page=20",4*1024*1024,mapOf("Accept" to "application/vnd.github+json"))
        val releases=org.json.JSONArray(text.toString(Charsets.UTF_8))
        val archTokens=when(architecture){"arm64-v8a","aarch64"->listOf("aarch64","arm64","armv8");"x86_64"->listOf("x86_64","amd64");else->listOf(architecture)}
        for(i in 0 until releases.length()) {
            val r=releases.getJSONObject(i); val tag=r.optString("tag_name")
            val assets=r.optJSONArray("assets") ?: continue
            for(j in 0 until assets.length()) { val a=assets.getJSONObject(j); val n=a.optString("name"); val low=n.lowercase(); if(low.contains("jre$javaMajor") && archTokens.any{low.contains(it)}) return Candidate("$tag-$n",a.getString("browser_download_url"),n,tag) }
        }
        return null
    }
}
