package com.nova.n10.core.runtime

import java.nio.file.Files
import java.nio.file.Path

/** Builds the environment expected by an Android-hosted JVM payload. */
object AndroidLaunchEnvironment {
    fun build(runtimeRoot: Path, nativeDirectory: Path, gameDirectory: Path, extra: Map<String, String> = emptyMap()): Map<String, String> {
        require(Files.isDirectory(runtimeRoot)) { "Runtime root does not exist: $runtimeRoot" }
        require(Files.isDirectory(nativeDirectory)) { "Native directory does not exist: $nativeDirectory" }
        require(Files.isDirectory(gameDirectory)) { "Game directory does not exist: $gameDirectory" }
        val sep = java.io.File.pathSeparator
        val existing = System.getenv("LD_LIBRARY_PATH").orEmpty()
        val paths = listOf(nativeDirectory.toString(), runtimeRoot.resolve("lib").toString(), runtimeRoot.resolve("lib/server").toString(), existing)
            .filter { it.isNotBlank() }
            .joinToString(sep)
        return buildMap {
            put("JAVA_HOME", runtimeRoot.toString())
            put("HOME", gameDirectory.toString())
            put("USER_HOME", gameDirectory.toString())
            put("TMPDIR", gameDirectory.resolve(".tmp").toString())
            put("XDG_CONFIG_HOME", gameDirectory.resolve("config").toString())
            put("XDG_CACHE_HOME", gameDirectory.resolve("cache").toString())
            put("LD_LIBRARY_PATH", paths)
            putAll(extra)
        }
    }
}
