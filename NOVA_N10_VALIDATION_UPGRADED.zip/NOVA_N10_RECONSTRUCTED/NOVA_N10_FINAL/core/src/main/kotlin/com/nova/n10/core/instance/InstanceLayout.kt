package com.nova.n10.core.instance
import java.nio.file.Path

class InstanceLayout(private val root:Path){
 fun instance(id:String)=root.resolve("instances").resolve(id)
 fun versions(id:String)=instance(id).resolve("versions")
 fun mods(id:String)=instance(id).resolve("mods")
 fun shaderpacks(id:String)=instance(id).resolve("shaderpacks")
 fun resourcepacks(id:String)=instance(id).resolve("resourcepacks")
 fun saves(id:String)=instance(id).resolve("saves")
 fun config(id:String)=instance(id).resolve("config")
}
