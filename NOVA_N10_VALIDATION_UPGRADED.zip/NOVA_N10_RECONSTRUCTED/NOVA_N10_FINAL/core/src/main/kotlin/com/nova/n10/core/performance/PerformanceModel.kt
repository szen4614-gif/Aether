package com.nova.n10.core.performance

data class FrameSample(val frameId: Long, val startNs: Long, val endNs: Long) {
    val durationNs: Long get() = (endNs - startNs).coerceAtLeast(0)
}

data class PerformanceSnapshot(
    val producedFps: Double,
    val displayRefreshHz: Double?,
    val p50Ms: Double,
    val p95Ms: Double,
    val p99Ms: Double,
    val onePercentLowFps: Double?,
    val zeroPointOnePercentLowFps: Double?,
    val source: String = "N10 monotonic telemetry"
)
