package com.nova.n10.core.compatibility

enum class CompatibilityState { SUPPORTED, VALIDATED, EXPERIMENTAL, DEGRADED, FALLBACK, UNSUPPORTED, UNKNOWN }

data class CompatibilityCapability(val name: String, val state: CompatibilityState, val evidence: String? = null)

data class CompatibilityNode(val id: String, val version: String?, val capabilities: List<CompatibilityCapability> = emptyList())
