package com.nova.n10.core.runtime

data class LaunchPlan(
    val minecraftVersion: String,
    val javaMajor: Int,
    val mainClass: String,
    val classpath: List<String>,
    val jvmArgs: List<String>,
    val gameArgs: List<String>,
    val gameDirectory: String,
    val nativeDirectory: String
)
