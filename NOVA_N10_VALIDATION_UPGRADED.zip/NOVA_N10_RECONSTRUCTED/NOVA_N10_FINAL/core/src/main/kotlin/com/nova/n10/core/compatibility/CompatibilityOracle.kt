package com.nova.n10.core.compatibility

data class Capability(val key:String,val value:String)
data class Constraint(val key:String,val accepted:Set<String>,val hard:Boolean=true)
data class CompatibilityResult(val compatible:Boolean,val reasons:List<String>,val score:Double)
object CompatibilityOracle{
 fun evaluate(capabilities:List<Capability>,constraints:List<Constraint>):CompatibilityResult{ val m=capabilities.associate{it.key to it.value}; val bad=constraints.filter{it.key in m && m[it.key] !in it.accepted}; return CompatibilityResult(bad.none{it.hard},bad.map{"${it.key}=${m[it.key]} not in ${it.accepted}"},1.0-bad.size.toDouble()/maxOf(1,constraints.size)) }
}
