package com.nova.n10.core.runtime

data class JavaRuntime(val id:String,val major:Int,val executable:String,val arch:String,val source:String)
data class JavaRequirement(val minMajor:Int)
object JavaRuntimeSelector {
    fun select(requirement:JavaRequirement, runtimes:List<JavaRuntime>):JavaRuntime = runtimes.filter{it.major>=requirement.minMajor}.minByOrNull{it.major} ?: error("No compatible Java runtime >= ${requirement.minMajor}")
}
