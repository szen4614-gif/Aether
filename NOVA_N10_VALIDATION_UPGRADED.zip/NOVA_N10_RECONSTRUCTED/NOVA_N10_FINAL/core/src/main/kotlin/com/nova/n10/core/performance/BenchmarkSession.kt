package com.nova.n10.core.performance

import java.util.concurrent.TimeUnit

data class BenchmarkEnvironment(
    val device:String,
    val soc:String,
    val gpu:String,
    val ramBytes:Long,
    val android:String,
    val launcherVersion:String,
    val java:String,
    val minecraft:String,
    val renderer:String,
    val resolution:String,
    val refreshHz:Float,
    val renderDistance:Int,
    val shaders:String?,
    val resourcePack:String?,
    val world:String,
    val seed:String?,
    val camera:String,
    val temperatureStartC:Float?,
    val temperatureEndC:Float?,
    val durationSeconds:Int,
    val powerMode:String,
    val backgroundApps:String
)

data class BenchmarkSample(val timestampNs:Long,val cpuNs:Long,val gpuNs:Long?,val presented:Boolean,val allocations:Long,val gcCount:Long)
class BenchmarkSession(private val environment:BenchmarkEnvironment) {
    private val samples=ArrayList<BenchmarkSample>()
    fun add(sample:BenchmarkSample){samples += sample}
    fun durationSeconds():Double = if(samples.size<2) 0.0 else (samples.last().timestampNs-samples.first().timestampNs).toDouble()/TimeUnit.SECONDS.toNanos(1)
    fun frameTimesNs():List<Long> = samples.zipWithNext().map{it.second.timestampNs-it.first.timestampNs}.filter{it>0}
    fun presentedFps():Double { val f=samples.count{it.presented}; val d=durationSeconds(); return if(d>0) f/d else 0.0 }
    fun renderThroughputFps():Double { val d=durationSeconds(); return if(d>0) samples.size/d else 0.0 }
    fun environment():BenchmarkEnvironment=environment
}
