package com.nova.n10.core.auth

import com.nova.n10.core.network.HttpArtifactClient
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import org.json.JSONObject

/** Real Microsoft OAuth + Xbox Live + XSTS + Minecraft Services exchange. Requires a registered Microsoft public-client id. */
class MicrosoftAuthClient(
    private val clientId:String,
    private val redirectUri:String,
    private val http:HttpArtifactClient=HttpArtifactClient("NOVA-N10/1.0 (Microsoft auth)")
) {
    data class LoginRequest(val url:String,val state:String,val verifier:String)
    data class MinecraftSession(val accountId:String,val name:String,val uuid:String,val accessToken:String,val expiresAtEpochMs:Long)

    fun beginLogin(scopes:String="XboxLive.signin offline_access"):LoginRequest {
        val state=random(24); val verifier=random(48)
        val challenge=Base64.getUrlEncoder().withoutPadding().encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray()))
        val url="https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?client_id=${enc(clientId)}&response_type=code&redirect_uri=${enc(redirectUri)}&response_mode=query&scope=${enc(scopes)}&state=${enc(state)}&code_challenge=${enc(challenge)}&code_challenge_method=S256"
        return LoginRequest(url,state,verifier)
    }

    fun exchangeCode(code:String, verifier:String):MinecraftSession {
        val body="client_id=${enc(clientId)}&grant_type=authorization_code&code=${enc(code)}&redirect_uri=${enc(redirectUri)}&code_verifier=${enc(verifier)}"
        val token=postForm("https://login.microsoftonline.com/consumers/oauth2/v2.0/token",body)
        val msAccess=token.getString("access_token")
        val xbl=postJson("https://user.auth.xboxlive.com/user/authenticate", "{\"Properties\":{\"AuthMethod\":\"RPS\",\"SiteName\":\"user.auth.xboxlive.com\",\"RpsTicket\":\"d=${escape(msAccess)}\"},\"RelyingParty\":\"http://auth.xboxlive.com\",\"TokenType\":\"JWT\"}")
        val xblToken=xbl.getString("Token"); val userHash=xbl.getJSONObject("DisplayClaims").getJSONArray("xui").getJSONObject(0).getString("uhs")
        val xsts=postJson("https://xsts.auth.xboxlive.com/xsts/authorize", "{\"Properties\":{\"SandboxId\":\"RETAIL\",\"UserTokens\":[\"${escape(xblToken)}\"]},\"RelyingParty\":\"rp://api.minecraftservices.com/\",\"TokenType\":\"JWT\"}")
        val xstsToken=xsts.getString("Token")
        val mc=postJson("https://api.minecraftservices.com/authentication/login_with_xbox", "{\"identityToken\":\"XBL3.0 x=${escape(userHash)};${escape(xstsToken)}\"}")
        val mcToken=mc.getString("access_token")
        val entitlements=http.openBytes("https://api.minecraftservices.com/entitlements/mcstore",16*1024*1024,mapOf("Authorization" to "Bearer $mcToken")).toString(Charsets.UTF_8)
        if (!entitlements.contains("item_id")) error("Minecraft ownership could not be verified")
        val profile=http.openBytes("https://api.minecraftservices.com/minecraft/profile",16*1024*1024,mapOf("Authorization" to "Bearer $mcToken")).toString(Charsets.UTF_8)
        val p=JSONObject(profile); val id=p.getString("id"); val name=p.getString("name")
        return MinecraftSession(p.getString("id"),name,id,mcToken,System.currentTimeMillis()+token.optLong("expires_in",3600)*1000)
    }
    private fun postForm(url:String,body:String)=JSONObject(http.open(url,"POST","application/x-www-form-urlencoded",body.toByteArray()).second.readBytes().toString(Charsets.UTF_8))
    private fun postJson(url:String,body:String)=JSONObject(http.open(url, "POST", "application/json", body.toByteArray()).second.readBytes().toString(Charsets.UTF_8))
    private fun enc(v:String)=URLEncoder.encode(v,"UTF-8")
    private fun escape(v:String)=v.replace("\\","\\\\").replace("\"","\\\"")
    private fun random(n:Int)=ByteArray(n).also{SecureRandom().nextBytes(it)}.let{Base64.getUrlEncoder().withoutPadding().encodeToString(it)}
}
