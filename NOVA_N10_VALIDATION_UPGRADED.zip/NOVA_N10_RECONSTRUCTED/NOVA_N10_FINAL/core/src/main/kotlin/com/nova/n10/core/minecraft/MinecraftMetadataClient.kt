package com.nova.n10.core.minecraft

import com.nova.n10.core.network.HttpArtifactClient
import java.nio.charset.StandardCharsets

/** Fetches official Mojang launcher metadata. */
class MinecraftMetadataClient(private val http: HttpArtifactClient = HttpArtifactClient()) {
    private val manifests = listOf(
        "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json",
        "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json"
    )

    fun fetchManifest(): String {
        var last: Throwable? = null
        for (url in manifests) {
            try {
                return http.open(url).second.use { it.readBytes().toString(StandardCharsets.UTF_8) }
            } catch (t: Throwable) { last = t }
        }
        throw IllegalStateException("Unable to fetch Mojang version manifest", last)
    }

    fun fetchVersionMetadata(url: String): String =
        http.open(requireHttps(url)).second.use { it.readBytes().toString(StandardCharsets.UTF_8) }

    private fun requireHttps(url: String): String {
        require(url.startsWith("https://", ignoreCase = true)) { "Minecraft metadata URL must use HTTPS" }
        return url
    }
}
