package com.nova.n10.core.launcher

import com.nova.n10.core.runtime.LaunchPlan

/** Deterministic dependency graph for the real launch pipeline. */
data class LaunchNode(val id: String, val dependsOn: Set<String> = emptySet(), val action: String)

data class LaunchGraph(val nodes: List<LaunchNode>) {
    fun topologicalOrder(): List<LaunchNode> {
        val byId = nodes.associateBy { it.id }
        require(byId.size == nodes.size) { "Duplicate launch node id" }
        val missing = nodes.flatMap { it.dependsOn }.filter { it !in byId }.toSet()
        require(missing.isEmpty()) { "Missing launch dependencies: $missing" }

        val remaining = byId.keys.toMutableSet()
        val done = linkedSetOf<String>()
        val out = mutableListOf<LaunchNode>()
        while (remaining.isNotEmpty()) {
            val ready = remaining.filter { id -> byId.getValue(id).dependsOn.all(done::contains) }.sorted()
            require(ready.isNotEmpty()) { "Launch graph contains a cycle" }
            ready.forEach { id ->
                done += id
                remaining -= id
                out += byId.getValue(id)
            }
        }
        return out
    }
}

object LaunchGraphFactory {
    fun create(plan: LaunchPlan) = LaunchGraph(
        listOf(
            LaunchNode("instance", action = "resolve:instance"),
            LaunchNode("version", setOf("instance"), "resolve:version"),
            LaunchNode("artifacts", setOf("version"), "resolve:artifacts"),
            LaunchNode("java", setOf("version"), "resolve:java"),
            LaunchNode("natives", setOf("artifacts", "java"), "resolve:natives"),
            LaunchNode("auth", setOf("instance"), "resolve:auth"),
            LaunchNode("environment", setOf("natives", "auth"), "resolve:environment"),
            LaunchNode("renderer", setOf("environment"), "resolve:renderer"),
            LaunchNode("process", setOf("renderer"), "launch:${plan.mainClass}")
        )
    )
}
