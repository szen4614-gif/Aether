package com.nova.n10.core.apex

/** Measurement-gated experiment controller. It never accepts an unmeasured change. */
class ApexExperimentController {
    enum class Decision { ACCEPT, ROLLBACK, INCONCLUSIVE }

    data class Baseline(val medianFrameMs: Double, val p99FrameMs: Double, val thermalDeltaC: Double?)
    data class Trial(val medianFrameMs: Double, val p99FrameMs: Double, val thermalDeltaC: Double?)

    fun decide(baseline: Baseline, trial: Trial, minImprovementRatio: Double = 0.02): Decision {
        require(minImprovementRatio >= 0.0) { "Minimum improvement ratio must be non-negative" }
        val frameImproved = trial.medianFrameMs <= baseline.medianFrameMs * (1.0 - minImprovementRatio)
        val tailImproved = trial.p99FrameMs <= baseline.p99FrameMs * (1.0 - minImprovementRatio)
        val thermalRegressed = baseline.thermalDeltaC != null && trial.thermalDeltaC != null &&
            trial.thermalDeltaC > baseline.thermalDeltaC + 1.0
        return when {
            thermalRegressed -> Decision.ROLLBACK
            frameImproved && tailImproved -> Decision.ACCEPT
            else -> Decision.INCONCLUSIVE
        }
    }
}
