package com.nova.n10.core.content

enum class DependencyKind{REQUIRED,OPTIONAL,INCOMPATIBLE,EMBEDDED}
data class ContentRef(val source:String,val id:String,val versionId:String?,val type:ContentType,val gameVersions:Set<String>,val loaders:Set<String>,val sha512:String?=null)
data class ContentDependency(val from:String,val to:String,val kind:DependencyKind)
data class ContentGraph(val nodes:List<ContentRef>,val edges:List<ContentDependency>) {
    fun conflicts():List<ContentDependency> = edges.filter{it.kind==DependencyKind.INCOMPATIBLE && nodes.any(n ->n.id==it.from) && nodes.any(n ->n.id==it.to)}
}
