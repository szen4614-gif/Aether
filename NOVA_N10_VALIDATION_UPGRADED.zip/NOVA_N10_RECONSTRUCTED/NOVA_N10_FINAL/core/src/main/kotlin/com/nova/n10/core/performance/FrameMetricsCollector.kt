package com.nova.n10.core.performance

import kotlin.math.ceil

class FrameMetricsCollector(private val capacity: Int = 10_000) {
    private val durationsNs = ArrayDeque<Long>(capacity)
    private var presented = 0L
    private var produced = 0L

    fun recordProduced(durationNs: Long) {
        produced++
        add(durationNs)
    }

    fun recordPresented() { presented++ }

    fun snapshot(displayRefreshHz: Double?): PerformanceSnapshot {
        val sorted = durationsNs.toList().sorted()
        val p = { q: Double ->
            if (sorted.isEmpty()) 0.0
            else sorted[(ceil(q * sorted.lastIndex)).toInt()].toDouble() / 1_000_000.0
        }
        val fps = { fraction: Double ->
            val count = (sorted.size * fraction).toInt().coerceAtLeast(1).coerceAtMost(sorted.size)
            val worst = sorted.takeLast(count).average().coerceAtLeast(1.0)
            1000.0 / (worst / 1_000_000.0)
        }
        return PerformanceSnapshot(
            producedFps = if (sorted.isEmpty()) 0.0 else 1_000_000_000.0 / sorted.average().coerceAtLeast(1.0),
            displayRefreshHz = displayRefreshHz,
            p50Ms = p(0.50),
            p95Ms = p(0.95),
            p99Ms = p(0.99),
            onePercentLowFps = if (sorted.isEmpty()) null else fps(0.01),
            zeroPointOnePercentLowFps = if (sorted.isEmpty()) null else fps(0.001),
            source = "N10 frame-duration samples; presented=$presented produced=$produced"
        )
    }

    private fun add(value: Long) {
        durationsNs.addLast(value.coerceAtLeast(0))
        while (durationsNs.size > capacity) durationsNs.removeFirst()
    }
}
