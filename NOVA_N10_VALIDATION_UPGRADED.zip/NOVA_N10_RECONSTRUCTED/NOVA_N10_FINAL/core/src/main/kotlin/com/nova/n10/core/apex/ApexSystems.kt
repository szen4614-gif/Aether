package com.nova.n10.core.apex

enum class ApexMode { SAFE, EXTREME, EXPERIMENTAL }

enum class Bottleneck { CPU, GPU, JVM, IO, MEMORY, SYNC, PRESENT, DRIVER, THERMAL, UNKNOWN }

data class PerformanceGenome(
    val renderer: String,
    val javaMajor: Int,
    val heapMb: Int,
    val mode: ApexMode,
    val flags: Map<String, String> = emptyMap()
)

data class ExperimentResult(
    val genome: PerformanceGenome,
    val samples: Int,
    val medianFps: Double?,
    val p99FrameMs: Double?,
    val thermalDeltaC: Double?,
    val accepted: Boolean
)
