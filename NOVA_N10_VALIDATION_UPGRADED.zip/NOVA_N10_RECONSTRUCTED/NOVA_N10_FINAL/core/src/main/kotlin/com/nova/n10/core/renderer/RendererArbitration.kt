package com.nova.n10.core.renderer

data class RendererCandidate(val id:String,val api:String,val supported:Boolean,val score:Double,val reason:String,val validated:Boolean=false)
object RendererArbitration {
    fun choose(candidates:List<RendererCandidate>):RendererCandidate? = candidates.filter{it.supported}.maxWithOrNull(compareBy<RendererCandidate>{it.validated}.thenBy{it.score})
}
