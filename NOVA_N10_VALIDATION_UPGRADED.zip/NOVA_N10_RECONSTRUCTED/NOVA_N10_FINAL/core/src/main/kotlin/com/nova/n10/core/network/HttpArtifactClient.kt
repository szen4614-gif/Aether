package com.nova.n10.core.network

import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URI

/** Small dependency-free HTTP client used only for metadata/artifact transport. */
class HttpArtifactClient(private val userAgent: String = "NOVA-N10/1.0 (launcher)") {
    fun open(url: String, method: String, contentType: String, body: ByteArray? = null, headers: Map<String,String> = emptyMap()): Pair<Long, InputStream> {
        var current = URI(url)
        repeat(MAX_REDIRECTS + 1) { attempt ->
            require(current.scheme.equals("https", ignoreCase = true)) { "Only HTTPS URLs are allowed: $current" }
            val c=(current.toURL().openConnection() as HttpURLConnection).apply { instanceFollowRedirects=false; requestMethod=method; setRequestProperty("User-Agent",userAgent); setRequestProperty("Content-Type",contentType); setRequestProperty("Accept","application/json"); connectTimeout=15000; readTimeout=60000; useCaches=false }
            for ((k,v) in headers) c.setRequestProperty(k,v)
            if(body!=null){c.doOutput=true;c.outputStream.use{it.write(body)}}
            c.connect()
            when(c.responseCode){
                in 200..299 -> { val input=c.inputStream; return c.contentLengthLong to object: InputStream(){ override fun read()=input.read(); override fun read(b:ByteArray,off:Int,len:Int)=input.read(b,off,len); override fun close(){try{input.close()}finally{c.disconnect()}} } }
                301,302,303,307,308 -> { val location=c.getHeaderField("Location") ?: throw java.io.IOException("HTTP redirect without Location"); c.disconnect(); if(attempt==MAX_REDIRECTS) throw java.io.IOException("Too many redirects for $url"); current=current.resolve(location) }
                else -> { val code=c.responseCode; val error=c.errorStream?.bufferedReader()?.readText(); c.disconnect(); throw java.io.IOException("HTTP $code for $current ${error ?: ""}") }
            }
        }; throw java.io.IOException("Unreachable")
    }
    fun open(url: String): Pair<Long, InputStream> {
        var current = URI(url)
        repeat(MAX_REDIRECTS + 1) { attempt ->
            require(current.scheme.equals("https", ignoreCase = true)) { "Only HTTPS URLs are allowed: $current" }
            val c = (current.toURL().openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", userAgent)
                setRequestProperty("Accept", "application/json, application/octet-stream;q=0.9, */*;q=0.1")
                connectTimeout = 15_000
                readTimeout = 60_000
                useCaches = false
            }
            c.connect()
            when (c.responseCode) {
                in 200..299 -> {
                    val input = c.inputStream
                    return c.contentLengthLong to object : InputStream() {
                        override fun read(): Int = input.read()
                        override fun read(b: ByteArray, off: Int, len: Int): Int = input.read(b, off, len)
                        override fun close() { try { input.close() } finally { c.disconnect() } }
                    }
                }
                301, 302, 303, 307, 308 -> {
                    val location = c.getHeaderField("Location") ?: throw IOException("HTTP redirect without Location")
                    c.disconnect()
                    if (attempt == MAX_REDIRECTS) throw IOException("Too many redirects for $url")
                    current = current.resolve(location)
                }
                else -> {
                    val code = c.responseCode
                    c.disconnect()
                    throw IOException("HTTP $code for $current")
                }
            }
        }
        throw IOException("Unreachable")
    }

    fun openBytes(url: String, maxBytes: Long = 16L * 1024 * 1024, headers: Map<String,String> = emptyMap()): ByteArray {
        val (length, stream) = if(headers.isEmpty()) open(url) else open(url,"GET","application/json",null,headers)
        require(length < 0L || length <= maxBytes) { "Response exceeds configured limit" }
        stream.use {
            val out = java.io.ByteArrayOutputStream(if (length in 0..Int.MAX_VALUE) length.toInt() else 8192)
            val buffer = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val n = it.read(buffer)
                if (n < 0) break
                total += n
                require(total <= maxBytes) { "Response exceeds configured limit" }
                out.write(buffer, 0, n)
            }
            return out.toByteArray()
        }
    }

    companion object { private const val MAX_REDIRECTS = 5 }
}
