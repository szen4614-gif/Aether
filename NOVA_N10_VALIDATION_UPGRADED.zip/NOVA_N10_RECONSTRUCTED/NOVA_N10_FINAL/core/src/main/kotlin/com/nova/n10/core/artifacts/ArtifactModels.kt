package com.nova.n10.core.artifacts

data class ArtifactCoordinate(val group:String,val name:String,val version:String,val classifier:String?=null)
data class ArtifactRef(val id:String,val url:String,val path:String,val sha1:String?=null,val sha256:String?=null,val size:Long?=null)
data class ArtifactPlan(val artifacts:List<ArtifactRef>) { val totalBytes:Long=artifacts.mapNotNull{it.size}.sum() }
