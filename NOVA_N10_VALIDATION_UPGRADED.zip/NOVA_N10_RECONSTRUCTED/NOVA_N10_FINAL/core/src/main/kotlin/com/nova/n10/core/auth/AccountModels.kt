package com.nova.n10.core.auth

data class Account(val id:String,val displayName:String,val uuid:String?,val expiresAtEpochMs:Long?,val provider:String="microsoft")
data class SessionToken(val accessToken:String,val expiresAtEpochMs:Long)
interface AccountProvider { suspend fun beginLogin():String; suspend fun exchange(callback:String):Account; suspend fun refresh(accountId:String):Account }
