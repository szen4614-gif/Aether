package com.nova.n10.core.performance

data class PresentationMetrics(val producedFps:Double,val presentedFps:Double,val refreshHz:Double,val p50Ms:Double,val p95Ms:Double,val p99Ms:Double)
