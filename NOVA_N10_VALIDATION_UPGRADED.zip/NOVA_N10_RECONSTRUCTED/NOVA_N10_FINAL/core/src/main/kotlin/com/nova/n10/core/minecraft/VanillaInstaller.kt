package com.nova.n10.core.minecraft

import com.nova.n10.core.artifacts.ArtifactStore
import com.nova.n10.core.network.HttpArtifactClient
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.util.zip.ZipFile
import org.json.JSONObject

/** Downloads the official Minecraft client and libraries described by Mojang version metadata. */
class VanillaInstaller(private val store:ArtifactStore, private val http:HttpArtifactClient=HttpArtifactClient("NOVA-N10/1.0 (minecraft-installer)")) {
    data class InstalledVersion(val id:String,val clientJar:Path,val libraries:List<Path>,val mainClass:String)
    fun install(metadata:String, gameRoot:Path):InstalledVersion {
        val json=JSONObject(metadata); val id=json.getString("id"); val dir=gameRoot.resolve("versions").resolve(id); Files.createDirectories(dir)
        val client=json.getJSONObject("downloads").getJSONObject("client"); val clientPath=dir.resolve("$id.jar")
        downloadVerified(client.getString("url"),clientPath,client.optString("sha1",null))
        val libs=mutableListOf<Path>(); val arr=json.optJSONArray("libraries") ?: org.json.JSONArray()
        for(i in 0 until arr.length()) { val l=arr.getJSONObject(i); if(!allowed(l.optJSONObject("rules"))) continue; val a=l.optJSONObject("downloads")?.optJSONObject("artifact") ?: continue; val path=gameRoot.resolve("libraries").resolve(a.getString("path")); Files.createDirectories(path.parent); downloadVerified(a.getString("url"),path,a.optString("sha1",null)); libs += path }
        return InstalledVersion(id,clientPath,libs,json.getString("mainClass"))
    }
    private fun allowed(rules:JSONObject?):Boolean { if(rules==null) return true; var allow=false; for(i in 0 until rules.optJSONArray("rules").length()){ val r=rules.getJSONArray("rules").getJSONObject(i); val action=r.getString("action"); if(action=="allow") allow=true; if(action=="disallow") allow=false }; return allow }
    private fun downloadVerified(url:String,path:Path,sha1:String?) { if(Files.exists(path) && (sha1==null || digest(path).equals(sha1,true))) return; val tmp=path.resolveSibling(".${path.fileName}.part"); http.open(url).second.use{Files.copy(it,tmp,StandardCopyOption.REPLACE_EXISTING)}; if(sha1!=null && !digest(tmp).equals(sha1,true)){Files.deleteIfExists(tmp);error("SHA-1 mismatch for $url")}; Files.move(tmp,path,StandardCopyOption.REPLACE_EXISTING) }
    private fun digest(path:Path):String { val md=java.security.MessageDigest.getInstance("SHA-1"); Files.newInputStream(path).use{it.copyTo(object:java.io.OutputStream(){override fun write(b:Int){md.update(b.toByte())};override fun write(b:ByteArray,off:Int,len:Int){md.update(b,off,len)}})}; return md.digest().joinToString(""){ "%02x".format(it) } }
}
