package com.nova.n10.core.content

import com.nova.n10.core.network.HttpArtifactClient
import java.net.URLEncoder

class ModrinthClient(private val http:HttpArtifactClient=HttpArtifactClient("NOVA-N10/1.0 (launcher)")){
    fun projectVersions(project:String,gameVersion:String,loader:String):String {
        val url="https://api.modrinth.com/v2/project/${URLEncoder.encode(project,"UTF-8")}/version?game_versions=[%22${URLEncoder.encode(gameVersion,"UTF-8")}%22]&loaders=[%22${URLEncoder.encode(loader,"UTF-8")}%22]"
        return http.open(url).second.use{it.readBytes().decodeToString()}
    }
}
