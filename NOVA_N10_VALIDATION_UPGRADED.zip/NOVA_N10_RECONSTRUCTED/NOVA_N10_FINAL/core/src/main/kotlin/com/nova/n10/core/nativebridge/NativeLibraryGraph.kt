package com.nova.n10.core.nativebridge

data class NativeLibrary(val name:String,val abi:String,val path:String,val dependencies:Set<String>=emptySet(),val sha256:String?=null)
class NativeLibraryGraph(private val libs:List<NativeLibrary>){
    fun resolve(abi:String):List<NativeLibrary>{
        val selected=libs.filter{it.abi==abi}.associateBy{it.name}; val out=mutableListOf<NativeLibrary>(); val seen=mutableSetOf<String>()
        fun visit(n:String){if(!seen.add(n))return; val x=selected[n]?:error("Missing native library $n for $abi"); x.dependencies.forEach(::visit); out+=x}
        selected.keys.forEach(::visit); return out
    }
}
