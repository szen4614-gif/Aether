package com.nova.n10.core.artifacts

import java.io.InputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

class ArtifactStore(root: Path) {
    private val root: Path = root.toAbsolutePath().normalize()
    init { Files.createDirectories(root) }

    fun target(id: String): Path {
        require(id.isNotBlank()) { "Artifact id is empty" }
        require(id != "." && id != "..") { "Unsafe artifact id" }
        require(!id.contains('/') && !id.contains('\\') && !id.contains('\u0000')) { "Unsafe artifact id: $id" }
        return root.resolve(id).normalize().also {
            require(it.parent == root.toAbsolutePath().normalize()) { "Artifact path escaped store" }
        }
    }

    fun has(id: String, sha256: String? = null): Boolean {
        val p = target(id)
        if (!Files.isRegularFile(p)) return false
        return sha256 == null || digest(p, "SHA-256").equals(sha256, true)
    }

    fun put(id: String, input: InputStream, expectedSha256: String? = null): Path {
        val target = target(id)
        val tmp = target.resolveSibling(".${target.fileName}.part")
        Files.copy(input, tmp, StandardCopyOption.REPLACE_EXISTING)
        try {
            if (expectedSha256 != null && !digest(tmp, "SHA-256").equals(expectedSha256, true)) {
                throw IllegalArgumentException("SHA-256 mismatch for $id")
            }
            try {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
            } catch (_: AtomicMoveNotSupportedException) {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING)
            }
            return target
        } catch (t: Throwable) {
            Files.deleteIfExists(tmp)
            throw t
        }
    }

    private fun digest(path: Path, algorithm: String): String {
        val md = MessageDigest.getInstance(algorithm)
        Files.newInputStream(path).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                md.update(buffer, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
