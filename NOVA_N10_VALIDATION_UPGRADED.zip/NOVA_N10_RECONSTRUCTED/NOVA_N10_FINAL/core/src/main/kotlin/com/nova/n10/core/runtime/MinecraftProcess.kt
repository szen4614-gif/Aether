package com.nova.n10.core.runtime

import java.nio.file.Files
import java.nio.file.Path

/** Starts a real Java process. It does not emulate Minecraft or the JVM. */
class MinecraftProcess(private val runtime: JavaRuntime, private val runtimeRoot: Path? = null) {
    fun start(plan: LaunchPlan, extraEnv: Map<String, String> = emptyMap()): Process {
        val java = Path.of(runtime.executable).toAbsolutePath().normalize()
        require(Files.isRegularFile(java)) { "Java executable not found: $java" }
        require(Files.isExecutable(java)) { "Java executable is not executable: $java" }
        val gameDir = Path.of(plan.gameDirectory).toAbsolutePath().normalize()
        val nativeDir = Path.of(plan.nativeDirectory).toAbsolutePath().normalize()
        require(Files.isDirectory(gameDir)) { "Game directory not found: $gameDir" }
        require(Files.isDirectory(nativeDir)) { "Native directory not found: $nativeDir" }

        val command = buildList {
            add(java.toString())
            addAll(plan.jvmArgs)
            add("-Djava.library.path=${nativeDir}")
            add("-cp")
            add(plan.classpath.joinToString(java.io.File.pathSeparator))
            add(plan.mainClass)
            addAll(plan.gameArgs)
        }
        val pb = ProcessBuilder(command)
            .directory(gameDir.toFile())
            .redirectErrorStream(true)
        pb.environment()["N10_JAVA_RUNTIME"] = runtime.id
        pb.environment().putAll(
            if (runtimeRoot != null) AndroidLaunchEnvironment.build(runtimeRoot, nativeDir, gameDir, extraEnv)
            else extraEnv
        )
        return pb.start()
    }
}
