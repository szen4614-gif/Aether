package com.nova.n10.core.recovery

import java.security.MessageDigest

object CrashFingerprint {
    fun of(exitCode:Int,javaMajor:Int,renderer:String,minecraft:String,logTail:String):String {
        val raw="$exitCode|$javaMajor|$renderer|$minecraft|${logTail.takeLast(4096)}"; val d=MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()); return d.joinToString(""){ "%02x".format(it)}.take(20)
    }
}
