package com.nova.n10.core.runtime

import com.nova.n10.core.artifacts.ArtifactStore
import com.nova.n10.core.network.HttpArtifactClient
import java.io.BufferedInputStream
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/** Real runtime installation primitives. The runtime bytes themselves are external, signed artifacts. */
class RuntimeManager(private val store: ArtifactStore, private val http: HttpArtifactClient = HttpArtifactClient("NOVA-N10/1.0 (runtime-manager)")) {
    data class Artifact(val id:String,val url:String,val sha256:String?,val archive:String="zip")

    fun install(artifact: Artifact, destination: Path): JavaRuntime {
        Files.createDirectories(destination)
        val archive = store.target("runtime-${artifact.id}.${if (artifact.archive == "tar.gz") "tgz" else "zip"}")
        if (!store.has(archive.fileName.toString(), artifact.sha256)) {
            http.open(artifact.url).second.use { store.put(archive.fileName.toString(), it, artifact.sha256) }
        }
        when (artifact.archive) {
            "zip" -> extractZip(archive, destination)
            "tar.gz" -> extractTarGz(archive, destination)
            else -> throw UnsupportedOperationException("Unsupported runtime archive format: ${artifact.archive}")
        }
        val java = findJava(destination) ?: error("Installed runtime contains no executable java")
        java.toFile().setExecutable(true, false)
        val major = detectMajor(java)
        val arch = System.getProperty("os.arch")
        return JavaRuntime(artifact.id, major, java.toString(), arch, artifact.url)
    }

    private fun extractZip(zip:Path, destination:Path) {
        ZipInputStream(BufferedInputStream(Files.newInputStream(zip))).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                require(!e.name.startsWith("/") && !e.name.contains("..")) { "Unsafe runtime archive entry: ${e.name}" }
                val out = destination.resolve(e.name).normalize()
                require(out.startsWith(destination.toAbsolutePath().normalize())) { "Runtime archive escaped destination" }
                if (e.isDirectory) Files.createDirectories(out) else {
                    Files.createDirectories(out.parent)
                    Files.copy(zin, out, StandardCopyOption.REPLACE_EXISTING)
                }
            }
        }
    }


    private fun extractTarGz(archive:Path,destination:Path){
        GZIPInputStream(BufferedInputStream(Files.newInputStream(archive))).use{input->
            val header=ByteArray(512)
            while(true){
                var read=0; while(read<header.size){ val n=input.read(header,read,header.size-read); if(n<0) return; read+=n }
                if(header.all{it.toInt()==0}) return
                val name=header.copyOfRange(0,100).toString(Charsets.US_ASCII).trimEnd('\u0000',' ')
                val sizeText=header.copyOfRange(124,136).toString(Charsets.US_ASCII).trimEnd('\u0000',' ').trim()
                val size=sizeText.ifEmpty{"0"}.toLong(8)
                require(!name.startsWith("/") && !name.split('/').contains("..")){"Unsafe runtime archive entry: $name"}
                val out=destination.resolve(name).normalize(); require(out.startsWith(destination.toAbsolutePath().normalize()))
                val type=header[156].toInt().toChar()
                if(type=='5') Files.createDirectories(out) else { Files.createDirectories(out.parent); Files.newOutputStream(out).use{copyExactly(input,it,size)} }
                val pad=(512-(size%512))%512; var left=pad; while(left>0){ val n=input.skip(left); if(n<=0){ if(input.read()<0) return; left-- } else left-=n }
            }
        }
    }
    private fun copyExactly(input:InputStream,out:java.io.OutputStream,size:Long){ var left=size; val b=ByteArray(64*1024); while(left>0){ val n=input.read(b,0,minOf(b.size,left.toInt())); if(n<0) error("Truncated tar entry"); out.write(b,0,n); left-=n } }

    private fun findJava(root:Path):Path? = Files.walk(root).use { s -> s.filter { Files.isRegularFile(it) && (it.fileName.toString()=="java" || it.fileName.toString()=="java.exe") }.findFirst().orElse(null) }

    private fun detectMajor(java:Path):Int {
        val p=ProcessBuilder(java.toString(),"-version").redirectErrorStream(true).start()
        val text=p.inputStream.bufferedReader().use{it.readText()}; p.waitFor()
        val m=Regex("version \\\"(\\d+)(?:\\.(\\d+))?").find(text) ?: error("Unable to detect Java version: $text")
        return m.groupValues[1].toInt()
    }
}
