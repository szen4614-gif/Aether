package com.nova.n10.core.storage

import java.nio.file.*

class AtomicJsonStore(private val root:Path){ init{Files.createDirectories(root)}; fun write(name:String,json:String){val target=root.resolve(name); val tmp=target.resolveSibling(".$name.part"); Files.writeString(tmp,json); Files.move(tmp,target,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE)}; fun read(name:String):String?=root.resolve(name).takeIf(Files::isRegularFile)?.let(Files::readString)}
