package com.nova.n10.core.security

import java.nio.file.Files
import kotlin.test.Test
import kotlin.test.assertFailsWith
import kotlin.test.assertEquals

class PathGuardTest {
    @Test fun rejectsTraversal() {
        val root = Files.createTempDirectory("n10-root")
        assertFailsWith<IllegalArgumentException> { PathGuard.child(root, "../escape") }
    }

    @Test fun acceptsNestedChild() {
        val root = Files.createTempDirectory("n10-root")
        assertEquals(root.resolve("instances/a").normalize().toAbsolutePath(), PathGuard.child(root, "instances/a"))
    }
}
