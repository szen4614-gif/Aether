package com.nova.n10.core

import com.nova.n10.core.apex.ApexExperimentController
import com.nova.n10.core.performance.FrameMetricsCollector
import kotlin.test.Test
import kotlin.test.assertEquals

class PerformanceAndApexTest {
    @Test fun metricsDistinguishProducedFromPresented() {
        val c = FrameMetricsCollector()
        repeat(100) { c.recordProduced(16_666_667) }
        repeat(60) { c.recordPresented() }
        val s = c.snapshot(60.0)
        assertEquals(60.0, s.displayRefreshHz)
        assert(s.producedFps > 59.0 && s.producedFps < 61.0)
        assert(s.onePercentLowFps != null)
    }

    @Test fun apexRollsBackOnThermalRegression() {
        val c = ApexExperimentController()
        val d = c.decide(
            ApexExperimentController.Baseline(16.0, 20.0, 3.0),
            ApexExperimentController.Trial(14.0, 17.0, 5.0)
        )
        assertEquals(ApexExperimentController.Decision.ROLLBACK, d)
    }
}
