package com.nova.n10.core

import com.nova.n10.core.performance.FrameSample
import kotlin.test.Test
import kotlin.test.assertEquals

class PerformanceModelTest {
    @Test fun frameDurationNeverNegative() {
        assertEquals(0, FrameSample(1, 20, 10).durationNs)
    }
}
