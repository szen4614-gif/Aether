package com.nova.n10.core
import com.nova.n10.core.launcher.*
import com.nova.n10.core.runtime.LaunchPlan
import kotlin.test.Test
import kotlin.test.assertEquals
class LaunchGraphTest { @Test fun ordersDependencies(){ val p=LaunchPlan("java", listOf(), "java -version"); val ids=LaunchGraphFactory.create(p).topologicalOrder().map{it.id}; assertEquals(listOf("instance","version","artifacts","java","natives","auth","environment","renderer","process"),ids) } }
