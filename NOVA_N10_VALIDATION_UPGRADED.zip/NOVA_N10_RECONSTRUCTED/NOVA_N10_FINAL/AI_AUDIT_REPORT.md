# NOVA N10 — AI Audit Report

Date: 2026-09-16

## Scope
Compared and consolidated:
1. `NOVA_N10_TOTAL_RECONSTRUCTED.zip` (current)
2. `NOVA_N10_FIRST_TEST-1.zip`
3. `N10_APEX_Renderer_FINAL_Forge_1.20.1.zip`
4. `NOVA_N10_AI_HANDOFF.md`

The handoff explicitly requires real software treatment, build attempts, code-vs-documentation auditing, and truthful status labels. No end-to-end Minecraft launch is allowed to be claimed before real validation.

## Findings — highest impact
### 1. Current Kotlin source had duplicate type declarations
`ContentType` and `Capability` existed twice in the same package namespace. This was a concrete compile blocker. The declarations were consolidated into `ContentModels.kt` and `Compatibility.kt` (`CompatibilityCapability`).

### 2. Current Android build was not reproducible locally
The project had no Gradle wrapper. The audit environment had Java 21 but no `gradle` executable, and downloading Gradle from `services.gradle.org` failed at DNS resolution. CI was changed to provision Gradle 8.9 explicitly instead of silently assuming a wrapper exists.

### 3. Some documentation overstated implementation status
Several areas were marked `IMPLEMENTED` even though they were contract/model layers only, such as renderer arbitration and input-related claims. The consolidated matrix now uses the requested evidence-oriented states and distinguishes implementation from device validation.

### 4. Artifact and path security needed hardening
Artifact IDs could contain unsafe path syntax, and HTTP transport followed redirects automatically without an explicit HTTPS policy. These were hardened. `PathGuard` now checks both normalized lexical containment and real-path containment for existing paths.

### 5. The APEX Forge package contains a real native foundation but is not a complete Minecraft renderer replacement
The native C++ core, frame stream and visibility primitives compile in isolation. The Forge adapter hooks the render lifecycle. Its own status file explicitly says that a full chunk renderer replacement, full Vulkan presentation path and broad mod compatibility are not complete. The Forge adapter therefore remains a reference/integration surface, not the Android launcher renderer.

### 6. N10 First contains the strongest reusable visual reference code
The CPU visual pipeline (bilinear/edge-aware scaling, temporal accumulation, denoise, sharpen, lighting, semantic mask model, model registry, capture manifest) builds and its bundled test passes. It has been consolidated into the current Android native target as a reusable reference path. Neural models, GPU backends and production-grade replay remain unimplemented/external.

## Verification performed
### N10 First
CMake configure: PASS
C++ build: PASS
CTest: PASS
Bundled N10 test: PASS

### APEX Forge native
CMake configure: PASS
C++ shared-library build: PASS with Vulkan discovery disabled

### NOVA N10 Android Gradle build
NOT-VALIDATED. The environment had no Gradle executable or wrapper and could not resolve the Gradle distribution host.

## 16 KB page size
The current project already used the linker flags recommended for pre-r28 NDKs. The build is now pinned to NDK r28. Android's current guidance says r28+ aligns shared libraries for 16 KB by default, while runtime code must still avoid hard-coded 4 KB assumptions and APK/ELF alignment must be checked. The project therefore remains `NOT-VALIDATED` until the actual APK and a 16 KB environment are tested.

## Tests added
- Launch graph deterministic ordering/cycle handling
- Path traversal/safe child path
- Frame metrics produced-vs-presented model
- APEX thermal rollback decision
- Static duplicate Kotlin declaration check

## Remaining limitations
- no real Microsoft OAuth/Xbox/Minecraft login
- no bundled real Java runtime payload
- no real Android Minecraft renderer backend
- no physical-device launch validation
- no 16 KB physical-device validation
- no sustained thermal/ADPF measurements
- no complete safe ZIP/content extraction implementation yet

## Consolidation outcome
The goal was not to append all three trees. The current tree now keeps the launcher architecture, merges the useful N10 visual reference code, and uses the APEX Forge package as an evidence-backed reference for native frame/visibility/command-stream integration while keeping Forge-specific lifecycle code outside the Android core.

## APEX code consolidation detail
The APEX native core, frame-stream abstraction and visibility/LOD primitives from the supplied Forge package are now present in the current Android native target. Forge-specific Java lifecycle classes are intentionally not copied into the launcher core. This preserves the useful native architecture without coupling the Android launcher to Forge classes.

## Deep research upgrade — 2026-09-16

### Android 16 KB
Android documentation confirms that 16 KB devices are supported and recommends 16 KB-aligned ELF segments plus APK `zipalign -P 16`. Android 16 can run some 4 KB-aligned apps in compatibility mode, but 16 KB alignment remains the recommended target. The project now pins NDK r28, keeps 16 KB linker flags, and adds APK/device validation tooling. Physical 16 KB execution remains a validation gate, not something the source tree can fake.

### Thermal / ADPF
The Android NDK exposes `AThermal_getCurrentThermalStatus`, thermal headroom/forecast, and `APerformanceHint` sessions. N10 now has native bridges for these APIs. They are advisory system interfaces, not arbitrary CPU/GPU schedulers. The implementation therefore records capability and reports work duration instead of claiming frequency control.

### Java runtime
Research against the PojavLauncher ecosystem confirmed that Android Minecraft launchers use Android-specific OpenJDK builds and custom LWJGL/native integration. N10 now implements a real artifact catalog/installer/process boundary, with safe extraction and hash verification. The runtime bytes remain an external signed payload because embedding an invented JRE would be false.

### Microsoft authentication
Microsoft's current mobile guidance supports OAuth authorization-code + PKCE. N10 now implements PKCE/state generation and the established Microsoft/Xbox Live/XSTS/Minecraft Services exchange pipeline. A real Microsoft app registration/client ID and a user account with Minecraft entitlement remain required for live validation.

### Renderer
LWJGL provides low-level Java bindings for Vulkan/OpenGL/OpenGL ES, but it is not itself an Android Minecraft launcher or a complete Android GLFW bridge. N10 therefore adds real Vulkan/EGL capability probing and backend arbitration without pretending that a capability probe is a Minecraft renderer. Android's Vulkan loader is provided by the platform on Vulkan-capable devices.

### Content
Modrinth exposes loader/game-version/dependency metadata; CurseForge exposes file hashes, game versions, dependencies and loader metadata through its REST API. N10 now has real adapter code for both sources, while API keys/terms and third-party content licenses remain external operational requirements.


### Verification performed in this environment
- Kotlin syntax compilation of new runtime/network/auth adapters: PASS (using an isolated JSON stub only for syntax checking; Android Gradle compilation not available).
- Native host CMake build of APEX + visual core: PASS.
- Declaration audit: PASS.
- Runtime HTTPS boundary smoke test: PASS.
- Android Gradle/APK build: NOT-EXECUTED because this environment has no Android SDK/Gradle distribution.
- Physical Android, 16 KB, thermal, ADPF and Minecraft end-to-end: NOT-VALIDATED.


## Validation-gate upgrade — 2026-09-16

The project now contains executable CI/device gates for the previously unvalidated areas. This is intentionally different from claiming that those gates have already passed.

- Android APK build: CI pipeline implemented; this model environment still has no Android SDK/Gradle installation capable of executing the build.
- 16 KB: Android 15 16 KB emulator workflow and device evidence collector added.
- Physical Android: self-hosted runner workflow added.
- Thermal/ADPF: native probes are exercised by instrumentation/device diagnostics.
- Minecraft Java: real JVM process supervisor and end-to-end device harness added.
- LWJGL: integration boundary documented; real Android-compatible LWJGL payload remains a required component and is never fabricated.
- FPS/latency: device evidence collector is in place; no benchmark values are asserted until a real run produces them.

This follows Android's current 16 KB guidance and the architecture used by Android Minecraft launchers that provision Android-specific JRE/LWJGL components.
