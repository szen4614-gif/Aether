#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
files=[p for p in root.rglob('*') if p.is_file() and '.git' not in p.parts]
print(f"files={len(files)}")
for marker in ("TODO", "FAKE", "MOCK", "PLACEHOLDER"):
    hits=[]
    for p in files:
        try:
            if marker.lower() in p.read_text(errors='ignore').lower(): hits.append(str(p.relative_to(root)))
        except Exception: pass
    print(marker, len(hits))
