#!/usr/bin/env bash
set -euo pipefail
adb get-state >/dev/null
echo "PAGE_SIZE=$(adb shell getconf PAGE_SIZE | tr -d '\r')"
adb shell getprop ro.product.cpu.abi
adb shell getprop ro.build.version.release
adb shell dumpsys thermalservice | head -80 || true
