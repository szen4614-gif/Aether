#!/usr/bin/env bash
set -euo pipefail
# Requires a real Android device/emulator with the NOVA APK installed and a
# real Android Java runtime + LWJGL payload provisioned by the runtime manager.
ADB="${ADB:-adb}"
PACKAGE="${PACKAGE:-com.nova.n10}"
WAIT="${WAIT_SECONDS:-30}"
OUT="${OUT:-minecraft-e2e}"
mkdir -p "$OUT"

"$ADB" wait-for-device
"$ADB" shell am force-stop "$PACKAGE" || true
"$ADB" logcat -c
"$ADB" shell monkey -p "$PACKAGE" 1 >/dev/null
sleep "$WAIT"
"$ADB" logcat -d -v threadtime > "$OUT/logcat.txt"
"$ADB" shell pidof "$PACKAGE" > "$OUT/launcher_pid.txt" || true
"$ADB" shell dumpsys thermalservice > "$OUT/thermal.txt" || true
"$ADB" shell dumpsys gfxinfo "$PACKAGE" > "$OUT/gfxinfo.txt" || true

if grep -Eiq 'Minecraft|LWJGL|OpenGL|Vulkan|GLFW|java.lang|SIGSEGV|FATAL EXCEPTION' "$OUT/logcat.txt"; then
  echo 'Minecraft/LWJGL launch evidence collected; inspect logcat for successful game window.'
else
  echo 'No Minecraft/LWJGL launch evidence found.' >&2
  exit 2
fi
