#!/usr/bin/env python3
from pathlib import Path
import re
from collections import defaultdict

root = Path(__file__).resolve().parents[1] / "core" / "src" / "main" / "kotlin"
seen = defaultdict(list)
pat = re.compile(r"^(?:data class|class|object|enum class|interface)\s+([A-Za-z_][A-Za-z0-9_]*)", re.M)
for p in root.rglob("*.kt"):
    for name in pat.findall(p.read_text(errors="ignore")):
        seen[name].append(str(p.relative_to(root)))
dup = {k: v for k, v in seen.items() if len(v) > 1}
if dup:
    for name, files in dup.items():
        print(f"duplicate declaration: {name}: {files}")
    raise SystemExit(1)
print(f"Kotlin declaration check: PASS ({len(seen)} declarations)")
