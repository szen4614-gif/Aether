#!/usr/bin/env bash
set -euo pipefail
ADB="${ADB:-adb}"
PACKAGE="${PACKAGE:-com.nova.n10}"
OUT="${OUT:-device-validation}"
mkdir -p "$OUT"

"$ADB" wait-for-device
"$ADB" shell getconf PAGE_SIZE | tee "$OUT/page_size.txt"
"$ADB" shell getprop ro.build.version.sdk | tee "$OUT/sdk.txt"
"$ADB" shell getprop ro.product.cpu.abi | tee "$OUT/abi.txt"
"$ADB" shell getprop ro.hardware | tee "$OUT/hardware.txt"
"$ADB" shell dumpsys SurfaceFlinger | grep -Ei 'refresh|display' | head -80 | tee "$OUT/display.txt" || true
"$ADB" logcat -c
"$ADB" shell am force-stop "$PACKAGE" || true
"$ADB" shell monkey -p "$PACKAGE" 1
sleep "${STARTUP_WAIT_SECONDS:-8}"
"$ADB" shell pidof "$PACKAGE" | tee "$OUT/pid.txt"
"$ADB" logcat -d -v threadtime > "$OUT/logcat.txt"
"$ADB" shell dumpsys thermalservice > "$OUT/thermalservice.txt" || true
"$ADB" shell dumpsys gfxinfo "$PACKAGE" > "$OUT/gfxinfo.txt" || true
"$ADB" shell dumpsys meminfo "$PACKAGE" > "$OUT/meminfo.txt" || true

if grep -q '^16384$' "$OUT/page_size.txt"; then
  echo 'PAGE_SIZE=16384' > "$OUT/result.txt"
else
  echo "PAGE_SIZE=$(tr -d '\n' < "$OUT/page_size.txt")" > "$OUT/result.txt"
fi
