#!/usr/bin/env bash
set -euo pipefail
APK="${1:-app/build/outputs/apk/debug/app-debug.apk}"
test -s "$APK"
unzip -l "$APK" | grep -E 'lib/(arm64-v8a|x86_64)/libn10\.so' >/dev/null
echo "APK native library validation: PASS"
