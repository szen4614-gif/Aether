# Native layer

Contains contracts for JNI, ANativeWindow, page-size-aware allocation, renderer bridges and native diagnostics. Actual renderer implementations must be tested on supported devices.
