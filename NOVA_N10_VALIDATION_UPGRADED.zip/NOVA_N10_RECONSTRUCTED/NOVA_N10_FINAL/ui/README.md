# N10 UI

Planned screens: Home, Instances, Content Hub, Downloads, Performance Lab, Diagnostics, Settings. The current bootstrap intentionally keeps UI minimal while the real runtime/content integrations are connected.
