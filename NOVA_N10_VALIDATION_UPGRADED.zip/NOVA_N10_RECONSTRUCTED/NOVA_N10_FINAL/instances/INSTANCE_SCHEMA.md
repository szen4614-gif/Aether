# Instance schema

Each instance owns `game/`, `mods/`, `config/`, `resourcepacks/`, `shaderpacks/`, `logs/`, `cache/`, `snapshots/` and a manifest containing Minecraft version, loader, Java major, artifact hashes and N10 profile ID. Never mix mutable world data between instances.
