# HYPER_RENDER

HyperRender is a backend-neutral optimization contract for state shadowing, resource pools, batching and submission policy. It must never claim a backend exists until native implementation is connected.
