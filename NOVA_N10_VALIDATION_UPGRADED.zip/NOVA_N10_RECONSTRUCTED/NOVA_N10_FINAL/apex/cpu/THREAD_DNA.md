# THREAD_DNA

Thread DNA classifies workload roles and exposes bounded policy hints. It prefers Android performance-hint mechanisms over hard CPU affinity.
