# EXPERIMENT_ENGINE

Experiment Engine executes controlled A/B configurations, stores provenance, rejects inconclusive tests and supports rollback.
