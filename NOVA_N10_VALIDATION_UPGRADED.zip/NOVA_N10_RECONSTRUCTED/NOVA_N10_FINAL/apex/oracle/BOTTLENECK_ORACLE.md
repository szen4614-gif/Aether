# BOTTLENECK_ORACLE

Bottleneck Oracle classifies bottlenecks only when multiple measurements support the classification; otherwise UNKNOWN.
