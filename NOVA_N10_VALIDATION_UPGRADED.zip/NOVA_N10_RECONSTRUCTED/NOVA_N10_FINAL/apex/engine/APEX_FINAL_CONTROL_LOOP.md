# APEX Final Control Loop

Observe → classify bottleneck → propose one mutation → warm-up → benchmark → compare against baseline → accept only with confidence → persist Known Good Profile → rollback on regression.

APEX never claims an optimization is effective without measurements. Thermal controls use gradual quality/workload changes. Renderer selection is capability + benchmark based. JVM tuning starts from VM ergonomics.
