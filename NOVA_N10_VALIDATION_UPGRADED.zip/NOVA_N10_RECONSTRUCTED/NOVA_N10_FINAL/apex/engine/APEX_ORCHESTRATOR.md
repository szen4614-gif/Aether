# APEX_ORCHESTRATOR

Central state machine: DETECT → CALIBRATE → WARMUP → RUN → MONITOR → ADAPT → RECOVER. It never applies experimental mutations without a reversible checkpoint.
