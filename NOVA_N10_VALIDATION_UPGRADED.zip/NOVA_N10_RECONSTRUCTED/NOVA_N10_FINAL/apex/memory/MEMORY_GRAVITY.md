# MEMORY_GRAVITY

Memory Gravity scores resources by reuse frequency, size, rebuild cost and pressure. Eviction is reversible for rebuildable resources and never silently targets saves.
