# FRAME_FABRIC

Frame Fabric gives every observable frame a monotonic ID and stage timestamps. Frame Genome stores a compact signature for later differential analysis.
