# CONTENT_INTELLIGENCE

Content Intelligence joins provider metadata, dependency graphs, licenses and local benchmark evidence. Provider claims and local measurements remain separate.
