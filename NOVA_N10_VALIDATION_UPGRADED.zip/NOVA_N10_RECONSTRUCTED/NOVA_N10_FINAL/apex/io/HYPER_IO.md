# HYPER_IO

HyperIO classifies artifact I/O, supports resumable downloads and content-addressed caches, and defers noncritical writes during gameplay.
