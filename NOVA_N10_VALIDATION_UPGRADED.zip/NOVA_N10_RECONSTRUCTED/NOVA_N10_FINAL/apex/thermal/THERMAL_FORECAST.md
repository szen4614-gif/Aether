# THERMAL_FORECAST

Thermal Forecast tracks temperature/load history and predicts degradation. It uses hysteresis and sustainable-performance targets.
