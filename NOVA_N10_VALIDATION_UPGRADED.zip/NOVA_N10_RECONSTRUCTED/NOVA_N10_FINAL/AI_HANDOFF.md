
## 2026-09-16 audit addendum
- Consolidated `N10 First` CPU visual reference code into the current Android native target.
- Consolidated APEX as a measurement-first architecture; Forge lifecycle integration remains a separate reference/integration package.
- Fixed duplicate Kotlin declarations in the reconstructed tree.
- Hardened artifact/path/network boundaries.
- Added performance metrics and APEX experiment decision tests.
- Android Gradle build remains `NOT-VALIDATED` until a Gradle 8.9 environment is available; no build success is claimed from static inspection alone.
