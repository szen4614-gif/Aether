# Research → Implementation Decisions

## 2026-09-16 findings incorporated
1. Android 15+ 16 KB page-size compatibility: AGP 8.5.1+ / NDK r28+ baseline, ELF and ZIP alignment checks, no hard-coded 4096 assumptions.
2. Vulkan: explicit synchronization and presentation timing; no assumption that acquire/present blocking behavior is uniform.
3. Android game performance: ADPF thermal/performance hints and frame pacing are inputs to APEX, not magic FPS boosters.
4. Java 25: runtime selection is version-driven; JVM ergonomics are respected before experimental tuning.
5. Real Android launchers require custom OpenJDK/JRE payloads, LWJGL/LWJGLX/GLFW bridging, renderer backends, audio and input.
6. Modrinth provides project-version/dependency metadata; the Content Hub therefore uses graph resolution and source provenance.
7. Current Minecraft 26.1 requires Java 25; the version resolver reads the version metadata rather than hard-coding this rule.

## Sources
- Android 16 KB page sizes: https://developer.android.com/guide/practices/page-sizes
- Android Vulkan native engine support/frame pacing: https://developer.android.com/games/develop/vulkan/native-engine-support
- Oracle Java 25 GC ergonomics: https://docs.oracle.com/en/java/javase/25/gctuning/ergonomics.html
- Minecraft Java 26.1: https://www.minecraft.net/en-us/article/minecraft-java-edition-26-1
- PojavLauncher: https://github.com/PojavLauncherTeam/PojavLauncher
- Fold Craft Launcher: https://github.com/FCL-Team/FoldCraftLauncher
- Amethyst: https://github.com/AngelAuraMC/Amethyst-Android
- Modrinth API: https://docs.modrinth.com/api/

# Deep Research — Implementation Decisions

## Sources
- Android 16 KB page-size guidance: https://developer.android.com/guide/practices/page-sizes
- Android Performance Hint Manager: https://developer.android.com/ndk/reference/group/a-performance-hint
- Android Thermal NDK: https://developer.android.com/ndk/reference/group/thermal
- Microsoft OAuth authorization-code/PKCE: https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-auth-code-flow
- LWJGL: https://www.lwjgl.org/
- Vulkan loader: https://docs.vulkan.org/guide/latest/loader.html
- PojavLauncher build/JRE architecture: https://github.com/PojavLauncherTeam/PojavLauncher
- Android OpenJDK builds: https://github.com/PojavLauncherTeam/android-openjdk-build-multiarch
- Modrinth API: https://docs.modrinth.com/api/
- CurseForge REST API: https://docs.curseforge.com/rest-api/

## Result
The research changed the implementation rather than only the documentation: native Android thermal/ADPF bridges, renderer capability probing, runtime artifact discovery/installation, Microsoft authentication protocol code, vanilla Minecraft artifact installation, CurseForge adapter, benchmark environment model, CI 16 KB verification and device validation tooling were added.

The research did **not** justify claiming that an Android-compatible LWJGL payload, a Minecraft renderer, a JRE binary, or physical-device benchmark results already exist in this repository. Those remain evidence/payload gates.
