# Research index

Key external areas that informed the architecture: Android 16 KB page-size compatibility; Android performance tooling (Perfetto, AGI, ADPF); Frame Rate API; Vulkan/GLES/translation backends; OpenJDK/Minecraft runtime evolution; Modrinth/CurseForge/Planet Minecraft content metadata; Fabric/Forge/NeoForge/Quilt ecosystem; Sodium/Lithium/C2ME/Iris compatibility boundaries.

External systems are not copied into N10. They are integration targets with explicit licensing and compatibility boundaries.
