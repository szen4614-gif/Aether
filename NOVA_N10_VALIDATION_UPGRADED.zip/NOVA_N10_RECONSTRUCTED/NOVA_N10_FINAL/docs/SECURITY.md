# NOVA N10 — Security

## Implemented hardening
- Artifact IDs reject path separators, NUL, `.` and `..`.
- Artifact writes use a temporary file and atomic move when the filesystem supports it, with a non-atomic fallback.
- Artifact SHA-256 can be verified before commit.
- URL transport is HTTPS-only and redirects are manually bounded.
- HTTP response bodies are closed together with their connection.
- PathGuard performs lexical containment and, for existing paths, real-path containment to detect symlink escapes.

## Remaining high-risk external surfaces
- Microsoft/Xbox/Minecraft authentication is not implemented in this repository.
- Third-party Java/JRE, LWJGL and renderer binaries are external dependencies and require provenance/license verification.
- Mod/resource-pack archives still need a dedicated safe ZIP extractor with entry count, uncompressed-size and symlink policy before production use.
- Content-provider adapters must continue to respect API credentials, rate limits, licenses and attribution.

## Status
No security claim here should be interpreted as a full penetration test. Static review and unit tests are the current evidence level.


## Runtime/auth hardening
Runtime archives are extracted with traversal checks and artifacts are hash-verified. Microsoft OAuth uses PKCE and state; tokens are never hard-coded. The client requires a configured Microsoft public-client registration.
