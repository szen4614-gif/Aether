# NOVA N10 status — post validation-infrastructure upgrade

## Implemented in code

- Android Gradle build configuration and CI build pipeline.
- Native NDK/CMake build with arm64-v8a and x86_64 targets.
- 16 KB ELF linker configuration and APK ZIP-alignment validation.
- Native page-size detection.
- Vulkan/GLES capability probes.
- Thermal NDK and ADPF probes.
- Real Java process construction and supervision boundary.
- Runtime archive installation with SHA-256 and path traversal protection.
- Mojang version metadata/client/library download primitives.
- Microsoft OAuth/Xbox/XSTS/Minecraft Services integration primitives.
- Modrinth/CurseForge adapters.
- Device validation instrumentation tests.
- 16 KB emulator CI job.
- Self-hosted physical-device validation workflow.
- Self-hosted Minecraft end-to-end workflow.

## Validation gates

| Gate | Current status |
|---|---|
| Android APK build | IMPLEMENTED IN CI / NOT-EXECUTED IN THIS MODEL ENVIRONMENT |
| Android physical device | VALIDATION HARNESS IMPLEMENTED / NOT-VALIDATED |
| Minecraft Java end-to-end | LAUNCH PIPELINE IMPLEMENTED / NOT-VALIDATED |
| LWJGL Android real | INTEGRATION BOUNDARY IMPLEMENTED / NOT-VALIDATED WITH REAL PAYLOAD |
| 16 KB device | CI VALIDATION IMPLEMENTED / NOT-VALIDATED ON PHYSICAL DEVICE |
| Thermal/ADPF hardware | NATIVE INTEGRATION IMPLEMENTED / NOT-VALIDATED ON TARGET HARDWARE |
| FPS/latency hardware | COLLECTION INFRASTRUCTURE IMPLEMENTED / NOT-VALIDATED |

A validation harness is not a validation result. CI or a real device must produce evidence before the status can be promoted.
