# Real Launcher Gate

The APK is not considered a real Minecraft launcher until all gates below are validated on hardware.

- [ ] Microsoft OAuth + Minecraft services session works with a user-owned account.
- [ ] Official version metadata resolves.
- [ ] All required libraries/assets/natives download and verify.
- [ ] Correct Java runtime is selected.
- [ ] LWJGL/GLFW Android bridge is loaded.
- [ ] Surface lifecycle survives pause/resume.
- [ ] Touch/mouse/keyboard/gamepad input reaches Minecraft.
- [ ] Audio backend works.
- [ ] At least one real renderer backend launches Minecraft.
- [ ] Crash logs and exit codes are captured.
- [ ] Instance isolation and save protection are validated.
- [ ] 4 KB and 16 KB native environments are tested.
- [ ] Thermal/performance telemetry works on real hardware.
- [ ] Mod loader installation and dependency resolution are tested.
- [ ] Content-source licensing/provenance is preserved.
- [ ] 30–60 minute sustained gameplay test passes without unrecoverable corruption.

Until these pass, status remains `NOT-VALIDATED` even if the project compiles.

## Software implementation status after deep research

- [x] Microsoft OAuth PKCE protocol implementation.
- [x] Minecraft Services token/profile/entitlement request implementation.
- [x] Mojang vanilla metadata/client/library installation implementation.
- [x] Android-compatible runtime artifact discovery and verified installation boundary.
- [x] Java process supervision boundary.
- [x] Vulkan/EGL capability probing.
- [x] Thermal NDK integration.
- [x] ADPF integration.
- [x] Benchmark environment/session model.
- [x] CurseForge REST adapter.
- [x] 16 KB APK verification tooling.
- [x] 16 KB device validation tooling.

The unchecked items below are **evidence gates**, not missing source-code placeholders. They require a configured account, actual Android-compatible runtime/LWJGL payloads and physical/emulated Android execution.
