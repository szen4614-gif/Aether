# N10 System Catalog

## Core launcher
Instance Manager · Version Resolver · Artifact Store · Download Transactions · Native Library Graph · Java Runtime Manager · Launch Graph · Account/Session Manager · Crash Fingerprint · Recovery/Last-Known-Good · Backup/Restore · Update/Rollback.

## Android bridge
Surface lifecycle · Input Fabric · Audio Bridge · Storage/SAF abstraction · page-size checks · ABI selection · process supervision.

## Graphics
Renderer Arbitration · Vulkan contract · GLES contract · translation backend contracts · pipeline cache contract · presentation timing · frame telemetry.

## APEX
Temporal Frame Fabric · Frame Genome · Bottleneck Oracle · Thread DNA · Memory Gravity · HyperIO · Thermal Forecast · Experiment Engine · AutoRollback · Performance DNA · Sustainable Performance Controller.

## Content
Multi-source hub · Modrinth adapter · CurseForge adapter boundary · dependency graph · compatibility graph · license/provenance · performance DNA · mod interaction graph · safe updates · snapshots.
