# Validation promotion policy

A source implementation may be marked `IMPLEMENTED` when the code path exists, is buildable/testable and has no fake implementation.

A device-dependent capability may only be promoted to `VALIDATED` after the corresponding evidence is captured.

Therefore:

- `IMPLEMENTED` = code exists and the project can exercise it.
- `CI-VALIDATED` = automated build/test evidence exists.
- `DEVICE-VALIDATED` = real Android device/emulator evidence exists.
- `E2E-VALIDATED` = Minecraft Java itself launched and rendered through the intended stack.

No status promotion is allowed merely because a workflow file exists.
