# Build and validation

## Local/CI toolchain

- JDK 17
- Gradle 8.9
- AGP 8.7.3
- Android SDK 35
- Build Tools 35.0.0
- NDK 28.0.13004108
- CMake 3.22.1
- arm64-v8a + x86_64

## Build

```bash
gradle --no-daemon testDebugUnitTest assembleDebug
```

The repository intentionally uses `gradle/actions/setup-gradle` in CI so the build does not depend on an untracked local Gradle installation.

## 16 KB verification

```bash
$ANDROID_HOME/build-tools/35.0.0/zipalign -c -P 16 -v 4 app/build/outputs/apk/debug/app-debug.apk
adb shell getconf PAGE_SIZE
```

The second command must return `16384` on a 16 KB environment.

## Emulator

The CI installs the Android 15 experimental 16 KB Google APIs x86_64 system image:

`system-images;android-35;google_apis_ps16k;x86_64`

and runs `connectedDebugAndroidTest` after verifying `PAGE_SIZE=16384`.

## Physical device

A self-hosted runner labelled `android,n10` can execute `tools/run_device_validation.sh` and upload evidence.

## Minecraft end-to-end

A separate self-hosted runner labelled `android,n10,minecraft` executes `tools/run_minecraft_e2e.sh`. It must have a real Android JRE, matching LWJGL/GLFW native payload, Minecraft files and the required authentication state. The workflow never downloads or invents a fake game/runtime.
