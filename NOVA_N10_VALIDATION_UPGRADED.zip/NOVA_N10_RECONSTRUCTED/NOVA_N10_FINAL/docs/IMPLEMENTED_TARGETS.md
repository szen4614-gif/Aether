# NOVA N10 — Implementation Upgrade

This release moves several former external/scaffold boundaries into real executable integration code.

## Implemented in software

- Android native renderer capability probe (Vulkan loader + EGL/GLES).
- Android page-size query and 16 KiB-aware native build flags.
- Android Thermal NDK integration when supported by API/device.
- ADPF/Performance Hint session integration when supported.
- Real Microsoft OAuth PKCE + Xbox Live/XSTS/Minecraft Services exchange pipeline. A Microsoft public-client registration is configuration, not a fake implementation.
- Real runtime artifact download, SHA-256 verification, safe extraction and Java executable discovery.
- Real Minecraft vanilla client/library installation from Mojang version metadata with SHA-1 verification.
- Real Java process launch boundary from an installed Android-compatible runtime.
- CI toolchain provisioning and APK 16 KiB alignment check.

## Still requiring external payloads or physical validation

The code is implemented, but these cannot truthfully be marked device-validated in this environment:

- Android-compatible JRE payloads.
- Android LWJGL/custom GLFW/native bridge payloads.
- Actual Minecraft renderer execution through LWJGL on a physical Android device.
- Microsoft app registration/client ID and live account entitlement.
- CurseForge API key/service access.
- 16 KiB physical/emulator execution.
- Thermal/ADPF measurements on real hardware.
- Sustained FPS/latency benchmarks on real hardware.

`IMPLEMENTED` here means the software path exists and is testable. `VALIDATED` remains reserved for execution evidence.
