# NOVA N10 device validation

This project now contains executable validation harnesses, but a validation result is only promoted after a real run.

## 16 KB

Use an Android 15+ 16 KB emulator image or a physical 16 KB device. The validation must report `adb shell getconf PAGE_SIZE = 16384`, install the APK, launch it, and retain logcat/gfxinfo/thermal evidence.

## Thermal / ADPF

The native layer probes Thermal NDK and Performance Hint Manager. Availability is device/API dependent. A test is valid only when the device reports the feature and the workload sends actual durations through the ADPF session.

## Minecraft Java end-to-end

The test requires:

- real Android JRE;
- real Minecraft client and libraries;
- real LWJGL/GLFW Android integration;
- a valid Minecraft account for online authentication, or an explicitly supported local/offline profile where legally and technically appropriate;
- a physical or emulator Android environment capable of the selected renderer.

The test must launch the real game process and capture evidence of the Minecraft window/render loop. Merely starting the launcher APK is not an end-to-end result.

## Hardware FPS / latency

Collect at least 60 seconds after a defined warm-up and report presented frames separately from render throughput. Record frame-time percentiles, 1%/0.1% lows, refresh rate, CPU/GPU, RAM, thermal state and input/present latency.
