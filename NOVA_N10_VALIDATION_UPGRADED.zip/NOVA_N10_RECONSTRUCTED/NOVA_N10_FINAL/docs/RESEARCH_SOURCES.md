# Research sources used by the validation upgrade

- Android 16 KB page-size compatibility: https://developer.android.com/guide/practices/page-sizes
- PojavLauncher build/runtime model: https://github.com/PojavLauncherTeam/PojavLauncher
- Pojav Android OpenJDK build artifacts: https://github.com/TeamPojavLauncher/pojav-android-openjdk-build-multiarch
- Pojav Android JRE 17 historical release: https://github.com/PojavLauncherTeam/android-openjdk-build-multiarch/releases/tag/jre17-ec28559
- Current TeamPojavLauncher organization and renderer/runtime ecosystem: https://github.com/TeamPojavLauncher
- Amethyst Android successor architecture: https://github.com/AngelAuraMC/Amethyst-Android
- LWJGL: https://www.lwjgl.org/

Research conclusion:

1. A real Android Minecraft Java stack requires an Android-specific JRE plus a compatible LWJGL/GLFW/native backend; ordinary desktop Java/LWJGL artifacts are not sufficient.
2. 16 KB support requires both native ELF alignment and APK packaging validation, followed by runtime testing on a 16 KB environment.
3. The most maintainable N10 architecture is to keep JRE/LWJGL/translation layers as verified component payloads behind a native-runtime contract instead of copying another launcher wholesale.
4. Physical-device performance, thermal behavior and true Minecraft presentation cannot be established from static source analysis; they require device evidence.
