# Architecture

```text
Android UI/Activity
      |
      +-- N10 Core lifecycle
      +-- Instance/Artifact manager
      +-- Content Hub
      +-- Compatibility Graph
      |
      v
APEX Orchestrator
  |-- Frame Fabric / Frame Genome
  |-- Thread DNA / Deadline Scheduler
  |-- HyperRender contracts
  |-- HyperIO / Cache
  |-- Memory Gravity
  |-- Thermal Forecast
  |-- Bottleneck Oracle
  |-- Experiment Engine / AutoTuner
  |
  v
Native bridge / renderer backend contracts
  |
  v
Minecraft Java process + JVM + LWJGL + native dependencies
```

APEX is an external execution/performance layer. It does not require modifying Minecraft classes to operate. Features that inherently require game-internal hooks are marked external/experimental rather than being disguised as launcher-only features.
