# NOVA N10 — Final Consolidated Architecture

```text
Android UI / lifecycle
        |
        v
Launch orchestration (Kotlin)
  |-- instance + metadata
  |-- artifact store + integrity
  |-- Java runtime selection (real payload external)
  |-- native-library dependency graph
  |-- auth boundary (external)
  |-- renderer arbitration boundary
  |-- recovery/diagnostics
        |
        v
Android NDK bridge
        |
        +--> APEX frame/performance primitives
        +--> N10 visual CPU reference pipeline
        +--> future Vulkan/GLES/translation backends
        |
        v
Real Minecraft Java process (external payload + runtime + renderer)
```

## Consolidation decisions
- The N10 First CPU visual reference is merged into the Android native target as a reusable reference path, without claiming neural or vendor-quality reconstruction.
- The Forge APEX adapter remains a separate integration/reference package because Forge/Minecraft lifecycle APIs do not belong in the Android launcher core.
- APEX concepts are represented as measurement-first core services; names alone never imply implementation.
- Launcher/runtime/renderer/Minecraft remain separate boundaries so external payloads cannot be mistaken for built-in functionality.

### Native consolidation boundary
`app/src/main/cpp/apex/` contains the consolidated APEX native core, frame stream and visibility primitives. The Forge adapter's Java event hooks remain outside this module because they depend on Minecraft/Forge APIs unavailable to the launcher process.
