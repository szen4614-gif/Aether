# Implementation matrix — validation gates

| System | Code state | Validation state | Evidence required for promotion |
|---|---|---|---|
| Android APK build | IMPLEMENTED | NOT-EXECUTED HERE | CI successful APK artifact |
| Android runtime process | IMPLEMENTED | NOT-VALIDATED | Real Android process + logs |
| JRE provisioning | IMPLEMENTED | EXTERNAL PAYLOAD | Verified Android JRE + `java -version` on device |
| LWJGL bridge | INTEGRATION CONTRACT | NOT-VALIDATED | Real LWJGL native/JAR payload and Minecraft window |
| Minecraft metadata/install | IMPLEMENTED | NOT-VALIDATED | Real version installed + hashes |
| Minecraft launch | IMPLEMENTED PROCESS BOUNDARY | NOT-VALIDATED | Real Minecraft process and render loop |
| 16 KB | IMPLEMENTED | CI + DEVICE GATE | CI emulator + physical device evidence |
| Thermal | IMPLEMENTED | NOT-VALIDATED | Real thermal status/headroom samples |
| ADPF | IMPLEMENTED | NOT-VALIDATED | Real session + reported work durations |
| FPS/latency | IMPLEMENTED COLLECTION | NOT-VALIDATED | Hardware run with presentation metrics |
