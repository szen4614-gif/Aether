# N10 Content Hub

The launcher can aggregate metadata from compatible public providers such as Modrinth, CurseForge and Planet Minecraft, subject to each provider's API terms, rate limits, licenses and distribution permissions.

N10 stores provider provenance and does not assume that a file may be redistributed merely because it can be downloaded. Content is installed into an isolated instance after version/loader/dependency checks and cryptographic verification where the provider exposes hashes.

Content types: mods, modpacks, shaders, resource packs, data packs, worlds/maps.

Adapters are intentionally interfaces/contracts until credentials, endpoints, terms and real network clients are integrated.
