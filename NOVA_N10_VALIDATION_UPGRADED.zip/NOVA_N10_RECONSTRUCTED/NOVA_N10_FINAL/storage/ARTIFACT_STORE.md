# Artifact store

Content-addressed artifacts use cryptographic hashes and immutable objects. Instances reference artifacts instead of duplicating identical files. Garbage collection may delete only objects proven unused and rebuildable.
