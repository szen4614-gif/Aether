package com.nova.n10

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class N10DeviceValidationTest {
    @Test fun nativeCoreLoadsAndReportsPageSize() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        N10Native.bootstrap()
        val page = N10Native.pageSize()
        assertTrue("Unexpected page size: $page", page == 4096 || page == 16384)
        assertTrue("Native library must be loadable", context.packageName == "com.nova.n10")
    }

    @Test fun sixteenKbEnvironmentIsDetectedWhenPresent() {
        val page = N10Native.pageSize()
        assumeTrue("This test is for a 16 KB environment", page == 16384)
        assertTrue(N10Diagnostics.capture().pageSize16K)
    }

    @Test fun rendererAndPerformanceProbesDoNotCrash() {
        N10Native.bootstrap()
        val d = N10Diagnostics.capture()
        assertTrue(d.pageSize == 4096 || d.pageSize == 16384)
        // Vulkan/GLES/ADPF may legitimately be unavailable on a device/emulator.
        assertTrue(d.rendererCapabilities >= 0)
    }
}
