#include <unistd.h>
#include <cstdint>
extern "C" long n10_runtime_page_size(){ return sysconf(_SC_PAGESIZE); }
extern "C" bool n10_is_supported_page_size(){ const long p=sysconf(_SC_PAGESIZE); return p==4096 || p==16384; }
