#include "n10_visibility.h"

namespace n10::apex {

bool sphere_distance_visible(float distance, float max_distance) noexcept {
    return distance <= max_distance;
}

VisibilityResult classify(const Aabb&, float distance, float max_distance) noexcept {
    VisibilityResult r;
    r.visible = sphere_distance_visible(distance, max_distance);
    if (!r.visible) return r;

    if (distance < max_distance * 0.25f) r.lod = 0;
    else if (distance < max_distance * 0.60f) r.lod = 1;
    else r.lod = 2;
    return r;
}

} // namespace n10::apex
