#include "n10_frame_stream.h"
#include <cstring>

namespace n10::apex {

void FrameStream::reset() {
    bytes_.clear();
}

void FrameStream::push(CommandType type, const void* payload, std::uint16_t size) {
    CommandHeader h{type, size};
    const auto old = bytes_.size();
    bytes_.resize(old + sizeof(h) + size);
    std::memcpy(bytes_.data() + old, &h, sizeof(h));
    if (size && payload) {
        std::memcpy(bytes_.data() + old + sizeof(h), payload, size);
    }
}

void FrameStream::end() {
    push(CommandType::End, nullptr, 0);
}

} // namespace n10::apex
