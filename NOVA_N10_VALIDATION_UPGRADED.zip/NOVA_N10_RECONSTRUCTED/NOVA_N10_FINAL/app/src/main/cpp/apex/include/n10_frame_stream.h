#pragma once
#include <cstdint>
#include <vector>

namespace n10::apex {

enum class CommandType : std::uint16_t {
    SetCamera = 1,
    SetViewport = 2,
    BindMaterial = 3,
    DrawIndexed = 4,
    DrawIndexedIndirect = 5,
    Dispatch = 6,
    End = 0xFFFF
};

struct CommandHeader {
    CommandType type{};
    std::uint16_t size = 0;
};
static_assert(sizeof(CommandHeader) == 4, "FrameStream command header must remain 4 bytes");

class FrameStream final {
public:
    void reset();
    void push(CommandType type, const void* payload, std::uint16_t size);
    void end();
    const std::vector<std::uint8_t>& bytes() const noexcept { return bytes_; }
    std::size_t size() const noexcept { return bytes_.size(); }

private:
    std::vector<std::uint8_t> bytes_;
};

} // namespace n10::apex
