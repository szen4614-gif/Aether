#pragma once
#include <cstdint>

namespace n10::apex {

struct Aabb {
    float min_x, min_y, min_z;
    float max_x, max_y, max_z;
};

struct VisibilityResult {
    bool visible = true;
    std::uint8_t lod = 0;
};

bool sphere_distance_visible(float distance, float max_distance) noexcept;
VisibilityResult classify(const Aabb& bounds, float distance, float max_distance) noexcept;

} // namespace n10::apex
