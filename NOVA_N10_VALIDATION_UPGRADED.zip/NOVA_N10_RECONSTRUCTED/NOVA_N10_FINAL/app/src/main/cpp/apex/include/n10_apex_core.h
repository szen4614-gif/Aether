#pragma once
#include <cstdint>
#include <string>

namespace n10::apex {

enum class Backend : std::uint8_t {
    Auto = 0,
    Vulkan = 1,
    GLES = 2,
    Compatibility = 3
};

struct DeviceProfile {
    std::string gpu_name;
    std::string driver;
    std::uint32_t api_major = 0;
    std::uint32_t api_minor = 0;
    std::uint64_t dedicated_memory_mb = 0;
    bool vulkan = false;
    bool indirect_draw = false;
    bool descriptor_indexing = false;
    bool dynamic_rendering = false;
};

struct FrameInfo {
    std::uint64_t frame_id = 0;
    std::uint32_t width = 0;
    std::uint32_t height = 0;
    float delta_seconds = 0.0f;
};

struct FrameStats {
    std::uint64_t frames = 0;
    std::uint64_t submitted_draws = 0;
    std::uint64_t culled_draws = 0;
    std::uint64_t chunk_rebuilds = 0;
    std::uint64_t uploads = 0;
};

class Core final {
public:
    static Core& instance();

    void initialize();
    void begin_frame(const FrameInfo& frame);
    void end_frame();

    const DeviceProfile& device() const noexcept;
    const FrameStats& stats() const noexcept;

    void set_backend(Backend backend) noexcept;
    Backend backend() const noexcept;

private:
    Core() = default;
    DeviceProfile device_{};
    FrameStats stats_{};
    FrameInfo current_{};
    Backend backend_ = Backend::Auto;
    bool initialized_ = false;
};

} // namespace n10::apex
