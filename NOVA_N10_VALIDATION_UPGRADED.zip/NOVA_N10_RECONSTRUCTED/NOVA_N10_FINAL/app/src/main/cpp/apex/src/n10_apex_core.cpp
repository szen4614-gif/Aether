#include "n10_apex_core.h"
#include <cstdlib>
#include <cstring>

namespace n10::apex {

Core& Core::instance() {
    static Core core;
    return core;
}

void Core::initialize() {
    if (initialized_) return;

    const char* backend = std::getenv("N10_APEX_BACKEND");
    if (backend) {
        if (std::strcmp(backend, "vulkan") == 0) backend_ = Backend::Vulkan;
        else if (std::strcmp(backend, "gles") == 0) backend_ = Backend::GLES;
        else if (std::strcmp(backend, "compatibility") == 0) backend_ = Backend::Compatibility;
    }

    device_.gpu_name = "Unknown GPU";
    device_.driver = "Unknown driver";
    initialized_ = true;
}

void Core::begin_frame(const FrameInfo& frame) {
    if (!initialized_) initialize();
    current_ = frame;
    ++stats_.frames;
}

void Core::end_frame() {}

const DeviceProfile& Core::device() const noexcept { return device_; }
const FrameStats& Core::stats() const noexcept { return stats_; }

void Core::set_backend(Backend backend) noexcept { backend_ = backend; }
Backend Core::backend() const noexcept { return backend_; }

} // namespace n10::apex
