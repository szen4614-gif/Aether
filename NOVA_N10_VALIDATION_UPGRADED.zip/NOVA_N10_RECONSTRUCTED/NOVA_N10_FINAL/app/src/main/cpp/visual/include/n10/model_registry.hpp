#pragma once
#include <string>
#include <vector>
namespace n10 {
struct ModelDescriptor {
  std::string id, version, precision, inputSchema, outputSchema, provenance, license;
  std::vector<std::string> backends, targets;
  double memoryMB=0.0, latencyTargetMs=0.0;
  bool neural=false;
};
class ModelRegistry {
public:
  void add(ModelDescriptor model);
  const ModelDescriptor* find(const std::string& id) const;
  const std::vector<ModelDescriptor>& all() const { return models_; }
private: std::vector<ModelDescriptor> models_;
};
}
