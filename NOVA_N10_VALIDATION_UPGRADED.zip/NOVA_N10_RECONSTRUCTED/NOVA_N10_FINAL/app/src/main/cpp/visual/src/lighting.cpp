#include "n10/n10.hpp"
namespace n10 {
// Reserved for future GPU/ML lighting. The CPU prototype intentionally keeps
// this deterministic and dependency-free; no vendor-specific neural weights are embedded.
}
