#include "n10/n10.hpp"
namespace n10 {
Image temporalReconstruct(const Image& cur,const Image& hist,const Image& motion,const Image& reactive,float hw){if(!cur.valid()||!hist.valid()||cur.width!=hist.width||cur.height!=hist.height)return cur;Image o=cur;for(uint32_t y=0;y<cur.height;y++)for(uint32_t x=0;x<cur.width;x++){auto c=cur.at(x,y);auto h=hist.at(x,y);float rw=reactive.valid()?std::clamp(reactive.at(std::min(x,reactive.width-1u),std::min(y,reactive.height-1u)).r,0.f,1.f):0.f;float w=std::clamp(hw*(1-rw),0.f,0.95f);c.r=c.r*(1-w)+h.r*w;c.g=c.g*(1-w)+h.g*w;c.b=c.b*(1-w)+h.b*w;o.at(x,y)=c;}return o;}
}
