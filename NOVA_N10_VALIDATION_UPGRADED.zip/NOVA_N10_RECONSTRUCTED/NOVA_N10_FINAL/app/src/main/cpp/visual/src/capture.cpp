#include "n10/capture.hpp"
#include <fstream>
namespace n10 { bool writeCaptureManifest(const std::string& path,const CaptureMetadata& m,const FrameInput& f){ std::ofstream out(path); if(!out) return false; out<<"{\n  \"runtime\":\""<<m.runtimeVersion<<"\",\n  \"backend\":\""<<m.backend<<"\",\n  \"model\":\""<<m.modelId<<"\",\n  \"frameIndex\":"<<m.frameIndex<<",\n  \"width\":"<<f.color.width<<",\n  \"height\":"<<f.color.height<<"\n}\n"; return true; } }
