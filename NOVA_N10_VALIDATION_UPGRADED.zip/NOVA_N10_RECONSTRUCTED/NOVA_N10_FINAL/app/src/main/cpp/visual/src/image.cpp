#include "n10/n10.hpp"
namespace n10 {
Image resizeBilinear(const Image& in,uint32_t ow,uint32_t oh){
 Image out(ow,oh); if(!in.valid()||!ow||!oh) return out;
 for(uint32_t y=0;y<oh;y++){float sy=(y+0.5f)*in.height/oh-0.5f; int y0=int(std::floor(sy)); float fy=sy-y0; y0=std::clamp(y0,0,int(in.height)-1); int y1=std::min(y0+1,int(in.height)-1);
  for(uint32_t x=0;x<ow;x++){float sx=(x+0.5f)*in.width/ow-0.5f; int x0=int(std::floor(sx)); float fx=sx-x0; x0=std::clamp(x0,0,int(in.width)-1); int x1=std::min(x0+1,int(in.width)-1);
   auto a=in.at(x0,y0),b=in.at(x1,y0),c=in.at(x0,y1),d=in.at(x1,y1); Vec4 p;
   auto mix=[](float a,float b,float t){return a+(b-a)*t;};
   p.r=mix(mix(a.r,b.r,fx),mix(c.r,d.r,fx),fy); p.g=mix(mix(a.g,b.g,fx),mix(c.g,d.g,fx),fy); p.b=mix(mix(a.b,b.b,fx),mix(c.b,d.b,fx),fy); p.a=mix(mix(a.a,b.a,fx),mix(c.a,d.a,fx),fy); out.at(x,y)=p;
  }} return out;
}
Image edgeAwareUpscale(const Image& in,const Image& depth,uint32_t ow,uint32_t oh,float sharp){
 Image out=resizeBilinear(in,ow,oh); if(!out.valid()) return out;
 for(uint32_t y=1;y+1<oh;y++) for(uint32_t x=1;x+1<ow;x++){
  auto p=out.at(x,y); auto l=out.at(x-1,y),r=out.at(x+1,y),u=out.at(x,y-1),d=out.at(x,y+1);
  float edge=(std::abs(l.r-r.r)+std::abs(l.g-r.g)+std::abs(l.b-r.b)+std::abs(u.r-d.r)+std::abs(u.g-d.g)+std::abs(u.b-d.b))/6.0f;
  float k=std::clamp(sharp*(1.0f-edge),0.0f,0.35f); p.r+=k*(p.r-(l.r+r.r+u.r+d.r)*0.25f); p.g+=k*(p.g-(l.g+r.g+u.g+d.g)*0.25f); p.b+=k*(p.b-(l.b+r.b+u.b+d.b)*0.25f); out.at(x,y)=p;
 } return out;
}
}
