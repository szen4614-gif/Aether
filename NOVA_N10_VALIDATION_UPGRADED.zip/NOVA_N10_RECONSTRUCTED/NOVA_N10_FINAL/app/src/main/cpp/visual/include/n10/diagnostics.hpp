#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace n10 {
struct StageTiming { std::string name; double milliseconds=0.0; };
struct Diagnostics { std::vector<StageTiming> stages; uint64_t fallbackCount=0; uint64_t artifactCount=0; float confidence=0.0f; void clear(){stages.clear();fallbackCount=artifactCount=0;confidence=0;} };
}
