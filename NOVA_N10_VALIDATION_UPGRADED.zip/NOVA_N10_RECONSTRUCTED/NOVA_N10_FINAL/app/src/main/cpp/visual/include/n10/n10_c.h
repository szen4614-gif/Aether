#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct N10Context N10Context;
typedef struct { uint32_t width,height; float* rgba; } N10ImageF32;
typedef struct { uint32_t width,height; const float* rgba; } N10ConstImageF32;
typedef struct { uint32_t width,height; const float* rgba; } N10ConstAuxF32;

typedef struct {
  uint32_t output_width, output_height;
  int quality; int temporal; int sharpen; int denoise; int hdr; float sharpness;
} N10Config;

typedef struct {
  int cpu,gpu,npu,hybrid,temporal,depth,motion,layers,hdr,frame_interpolation,ray_tracing;
} N10Capabilities;

N10Context* n10_create(const N10Config* cfg);
void n10_destroy(N10Context* ctx);
N10Capabilities n10_capabilities(const N10Context* ctx);
int n10_process_rgba32f(N10Context* ctx, N10ConstImageF32 color, N10ConstAuxF32 depth, N10ConstAuxF32 motion, N10ConstAuxF32 reactive, N10ImageF32 output);
void n10_reset_history(N10Context* ctx);
const char* n10_version(void);
#ifdef __cplusplus
}
#endif
