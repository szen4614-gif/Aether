#include "n10/n10.hpp"
#include "n10/n10_c.h"
#include <chrono>
namespace n10 {
Engine::Engine(){} Engine::~Engine(){}
Capabilities Engine::capabilities() const { Capabilities c; c.gpu=false;c.npu=false;c.hybrid=false;c.frameInterpolation=false;return c; }
void Engine::setOutput(OutputConfig c){out_=c;} void Engine::setLighting(LightingConfig c){light_=c;} void Engine::setPower(PowerConfig c){power_=c;}
void Engine::resetHistory(){history_=Image{};hasHistory_=false;historyFrame_=0;}
Image Engine::process(const FrameInput& in, FrameStats* stats){auto t0=std::chrono::high_resolution_clock::now();uint32_t ow=out_.width?out_.width:in.color.width,oh=out_.height?out_.height:in.color.height;auto a=edgeAwareUpscale(in.color,in.depth,ow,oh,out_.sharpness);auto t1=std::chrono::high_resolution_clock::now();if(out_.temporal&&hasHistory_&&history_.width==ow&&history_.height==oh)a=temporalReconstruct(a,history_,in.motion,in.reactive,0.88f);auto t2=std::chrono::high_resolution_clock::now();a=applyLayerModel(a,in.layers);a=applyLighting(a,light_);if(out_.denoise)a=applyDenoise(a,0.08f);if(out_.sharpen)a=applySharpen(a,out_.sharpness);auto t3=std::chrono::high_resolution_clock::now();history_=a;hasHistory_=true;historyFrame_=in.frameIndex;lastStats_.upscaleMs=std::chrono::duration<double,std::milli>(t1-t0).count();lastStats_.temporalMs=std::chrono::duration<double,std::milli>(t2-t1).count();lastStats_.lightingMs=std::chrono::duration<double,std::milli>(t3-t2).count();lastStats_.totalMs=std::chrono::duration<double,std::milli>(t3-t0).count();lastStats_.estimatedQuality=0.75f;lastStats_.stability=hasHistory_?0.9f:0.4f;lastStats_.usedFallback=true;if(stats)*stats=lastStats_;return a;}
}

struct N10Context { n10::Engine e; };
extern "C" N10Context* n10_create(const N10Config* cfg){auto* c=new N10Context();if(cfg){n10::OutputConfig o;o.width=cfg->output_width;o.height=cfg->output_height;o.temporal=cfg->temporal!=0;o.sharpen=cfg->sharpen!=0;o.denoise=cfg->denoise!=0;o.hdr=cfg->hdr!=0;o.sharpness=cfg->sharpness;c->e.setOutput(o);}return c;}
extern "C" void n10_destroy(N10Context* c){delete c;}
extern "C" N10Capabilities n10_capabilities(const N10Context* c){N10Capabilities x{};if(!c)return x;auto k=c->e.capabilities();x.cpu=k.cpu;x.gpu=k.gpu;x.npu=k.npu;x.hybrid=k.hybrid;x.temporal=k.temporal;x.depth=k.depth;x.motion=k.motion;x.layers=k.layers;x.hdr=k.hdr;x.frame_interpolation=k.frameInterpolation;x.ray_tracing=k.rayTracing;return x;}
static n10::Image wrap(const float* p,uint32_t w,uint32_t h){n10::Image i(w,h);if(p)for(size_t k=0;k<i.pixels.size();k++){i.pixels[k]={p[k*4],p[k*4+1],p[k*4+2],p[k*4+3]};}return i;}
extern "C" int n10_process_rgba32f(N10Context* c,N10ConstImageF32 color,N10ConstAuxF32 depth,N10ConstAuxF32 motion,N10ConstAuxF32 reactive,N10ImageF32 output){if(!c||!color.rgba||!output.rgba||!color.width||!color.height)return -1;n10::FrameInput f;f.color=wrap(color.rgba,color.width,color.height);if(depth.rgba)f.depth=wrap(depth.rgba,depth.width,depth.height);if(motion.rgba)f.motion=wrap(motion.rgba,motion.width,motion.height);if(reactive.rgba)f.reactive=wrap(reactive.rgba,reactive.width,reactive.height);auto r=c->e.process(f);if(output.width!=r.width||output.height!=r.height)return -2;for(size_t k=0;k<r.pixels.size();k++){output.rgba[k*4]=r.pixels[k].r;output.rgba[k*4+1]=r.pixels[k].g;output.rgba[k*4+2]=r.pixels[k].b;output.rgba[k*4+3]=r.pixels[k].a;}return 0;}
extern "C" void n10_reset_history(N10Context* c){if(c)c->e.resetHistory();}
extern "C" const char* n10_version(void){return "N10 0.1.0-prototype";}
