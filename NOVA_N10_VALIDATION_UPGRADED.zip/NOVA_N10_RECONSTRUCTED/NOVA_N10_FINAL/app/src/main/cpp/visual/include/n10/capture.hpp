#pragma once
#include "n10.hpp"
#include <string>
namespace n10 {
struct CaptureMetadata { std::string runtimeVersion; std::string backend; std::string modelId; uint64_t frameIndex=0; };
bool writeCaptureManifest(const std::string& path, const CaptureMetadata& meta, const FrameInput& frame);
}
