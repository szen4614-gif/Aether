#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <array>
#include <cmath>
#include <algorithm>
#include <memory>

namespace n10 {

enum class Status { Specified, Prototype, Implemented, Built, Executed, Tested, Benchmarked, Verified, Experimental, Partial, Unavailable, NotImplemented };

enum class Compute { Auto, CPU, GPU, NPU, Hybrid };

enum class Quality { Native, UltraQuality, Quality, Balanced, Performance, UltraPerformance };

enum class ColorModel { LinearScRGB, HDR10, BT2020PQ, SRGB, ACEScg };

enum class LayerKind { BaseColor, SkinCore, HairCore, FabricCore, MetalCore, GlassCore, DirtCore, DustCore, WetnessCore, MicroSurface, EmissionCore, Custom };

struct Vec2 { float x=0, y=0; };
struct Vec3 { float x=0, y=0, z=0; };
struct Vec4 { float r=0, g=0, b=0, a=1; };

struct Image {
  uint32_t width=0, height=0;
  std::vector<Vec4> pixels;
  Image() = default;
  Image(uint32_t w, uint32_t h) : width(w), height(h), pixels(size_t(w)*h) {}
  Vec4& at(uint32_t x, uint32_t y) { return pixels[size_t(y)*width+x]; }
  const Vec4& at(uint32_t x, uint32_t y) const { return pixels[size_t(y)*width+x]; }
  bool valid() const { return width && height && pixels.size()==size_t(width)*height; }
};

struct Layer {
  LayerKind kind = LayerKind::BaseColor;
  std::string name;
  Image mask;
  float weight = 1.0f;
};

struct FrameInput {
  Image color;
  Image depth;
  Image motion;
  Image reactive;
  Image transparency;
  std::vector<Layer> layers;
  Vec2 jitter{};
  float exposure = 1.0f;
  uint64_t frameIndex = 0;
  ColorModel colorModel = ColorModel::LinearScRGB;
};

struct OutputConfig {
  uint32_t width=0, height=0;
  Quality quality = Quality::Quality;
  bool temporal=true;
  bool sharpen=true;
  bool denoise=true;
  bool hdr=true;
  bool frameInterpolation=false;
  float sharpness=0.15f;
};

struct LightingConfig {
  float exposure=1.0f;
  float contrast=1.0f;
  float saturation=1.0f;
  float bloom=0.0f;
  float ambient=1.0f;
  float specular=1.0f;
  float skinSubsurface=0.15f;
  float hairSpecular=0.25f;
};

struct PowerConfig {
  Compute compute=Compute::Auto;
  float targetFrameMs=16.67f;
  float thermalBudget=1.0f;
  float powerBudgetWatts=0.0f;
};

struct FrameStats {
  double upscaleMs=0, temporalMs=0, lightingMs=0, totalMs=0;
  float estimatedQuality=0;
  float stability=0;
  bool usedFallback=true;
};

struct Capabilities {
  bool cpu=true;
  bool gpu=false;
  bool npu=false;
  bool hybrid=false;
  bool temporal=true;
  bool depth=true;
  bool motion=true;
  bool layers=true;
  bool hdr=true;
  bool frameInterpolation=false;
  bool rayTracing=false;
};

class Engine {
public:
  Engine();
  ~Engine();
  Capabilities capabilities() const;
  void setOutput(OutputConfig cfg);
  void setLighting(LightingConfig cfg);
  void setPower(PowerConfig cfg);
  void resetHistory();
  Image process(const FrameInput& in, FrameStats* stats=nullptr);
  const FrameStats& lastStats() const { return lastStats_; }
private:
  OutputConfig out_{}; LightingConfig light_{}; PowerConfig power_{};
  Image history_; uint64_t historyFrame_=0; bool hasHistory_=false;
  FrameStats lastStats_{};
};

// Public, implementation-neutral building blocks.
Image resizeBilinear(const Image&, uint32_t, uint32_t);
Image edgeAwareUpscale(const Image&, const Image& depth, uint32_t, uint32_t, float sharpness);
Image temporalReconstruct(const Image& current, const Image& history, const Image& motion, const Image& reactive, float historyWeight);
Image applyLighting(const Image&, const LightingConfig&);
Image applySharpen(const Image&, float);
Image applyDenoise(const Image&, float);
Image applyLayerModel(const Image&, const std::vector<Layer>&);

} // namespace n10
