#include "n10/n10.hpp"
namespace n10 {
// Filter registry extension point. Concrete filters live in color.cpp for the prototype.
}
