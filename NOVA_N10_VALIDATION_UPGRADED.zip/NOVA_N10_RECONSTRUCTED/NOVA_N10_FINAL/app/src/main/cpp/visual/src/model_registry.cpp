#include "n10/model_registry.hpp"
namespace n10 { void ModelRegistry::add(ModelDescriptor m){ models_.push_back(std::move(m)); } const ModelDescriptor* ModelRegistry::find(const std::string& id) const { for(const auto& m:models_) if(m.id==id) return &m; return nullptr; } }
