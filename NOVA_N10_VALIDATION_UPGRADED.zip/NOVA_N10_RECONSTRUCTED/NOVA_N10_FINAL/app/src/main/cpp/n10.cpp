#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <atomic>
#include <chrono>
#include <vector>
#include <cmath>
#include <cstdint>
#include <unistd.h>
#if defined(__ANDROID__)
#include <android/thermal.h>
#include <android/performance_hint.h>
#include <vulkan/vulkan.h>
#include <EGL/egl.h>
#endif
#define LOG_TAG "N10"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
static ANativeWindow* g_window=nullptr; static std::atomic<uint64_t> g_frame_id{0}; static std::atomic<bool> g_running{false};
#if defined(__ANDROID__)
static APerformanceHintManager* g_phm=nullptr; static APerformanceHintSession* g_phs=nullptr;
#endif
extern "C" JNIEXPORT void JNICALL Java_com_nova_n10_N10Native_bootstrap(JNIEnv*,jclass){g_running=true;LOGI("N10 native core ready");}
extern "C" JNIEXPORT void JNICALL Java_com_nova_n10_N10Native_onSurfaceCreated(JNIEnv* e,jclass,jobject s){if(g_window){ANativeWindow_release(g_window);g_window=nullptr;}if(s)g_window=ANativeWindow_fromSurface(e,s);}
extern "C" JNIEXPORT void JNICALL Java_com_nova_n10_N10Native_onSurfaceChanged(JNIEnv*,jclass,jobject,jint w,jint h){LOGI("surface %dx%d",w,h);}
extern "C" JNIEXPORT void JNICALL Java_com_nova_n10_N10Native_onSurfaceDestroyed(JNIEnv*,jclass){if(g_window){ANativeWindow_release(g_window);g_window=nullptr;}}
extern "C" JNIEXPORT jlong JNICALL Java_com_nova_n10_N10Native_markFrame(JNIEnv*,jclass){return g_running ? (jlong)g_frame_id.fetch_add(1)+1 : 0;}
extern "C" JNIEXPORT jlong JNICALL Java_com_nova_n10_N10Native_monotonicNanos(JNIEnv*,jclass){return (jlong)std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
extern "C" JNIEXPORT jint JNICALL Java_com_nova_n10_N10Native_pageSize(JNIEnv*,jclass){return (jint)sysconf(_SC_PAGESIZE);}
extern "C" JNIEXPORT jint JNICALL Java_com_nova_n10_N10Native_rendererCapabilities(JNIEnv*,jclass){
#if defined(__ANDROID__)
 int caps=0; EGLDisplay d=eglGetDisplay(EGL_DEFAULT_DISPLAY); if(d!=EGL_NO_DISPLAY && eglInitialize(d,nullptr,nullptr)) caps|=2; if(d!=EGL_NO_DISPLAY) eglTerminate(d); uint32_t v=0; if(vkEnumerateInstanceVersion(&v)==VK_SUCCESS) caps|=1; return caps;
#else
 return 0;
#endif
}
extern "C" JNIEXPORT jint JNICALL Java_com_nova_n10_N10Native_thermalStatus(JNIEnv*,jclass){
#if defined(__ANDROID__) && __ANDROID_API__>=30
 auto* m=AThermal_acquireManager(); if(!m)return -1; int s=AThermal_getCurrentThermalStatus(m); AThermal_releaseManager(m); return s;
#else
 return -1;
#endif
}
extern "C" JNIEXPORT jfloat JNICALL Java_com_nova_n10_N10Native_thermalHeadroom(JNIEnv*,jclass,jint seconds){
#if defined(__ANDROID__) && __ANDROID_API__>=30
 auto* m=AThermal_acquireManager(); if(!m)return NAN; float h=AThermal_getThermalHeadroom(m,seconds); AThermal_releaseManager(m); return h;
#else
 return -1.0f;
#endif
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_nova_n10_N10Native_performanceHintAvailable(JNIEnv*,jclass){
#if defined(__ANDROID__) && __ANDROID_API__>=31
 if(!g_phm)g_phm=APerformanceHint_getManager(); return g_phm!=nullptr && APerformanceHint_isFeatureSupported(g_phm,APERF_HINT_SESSIONS);
#else
 return false;
#endif
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_nova_n10_N10Native_startPerformanceSession(JNIEnv* e,jclass,jlongArray ids,jlong target){
#if defined(__ANDROID__) && __ANDROID_API__>=31
 if(!g_phm)g_phm=APerformanceHint_getManager(); if(!g_phm)return false; jsize n=e->GetArrayLength(ids); auto* vals=e->GetLongArrayElements(ids,nullptr); std::vector<int32_t> tids; for(jsize i=0;i<n;i++)tids.push_back((int32_t)vals[i]); e->ReleaseLongArrayElements(ids,vals,JNI_ABORT); g_phs=APerformanceHint_createSession(g_phm,tids.data(),tids.size(),target); return g_phs!=nullptr;
#else
 return false;
#endif
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_nova_n10_N10Native_reportPerformanceWork(JNIEnv*,jclass,jlong actual){
#if defined(__ANDROID__) && __ANDROID_API__>=31
 return g_phs && APerformanceHint_reportActualWorkDuration(g_phs,(int64_t)actual)==0;
#else
 return false;
#endif
}
extern "C" JNIEXPORT void JNICALL Java_com_nova_n10_N10Native_stopPerformanceSession(JNIEnv*,jclass){
#if defined(__ANDROID__) && __ANDROID_API__>=31
 if(g_phs){APerformanceHint_closeSession(g_phs);g_phs=nullptr;}
#endif
}
