package com.nova.n10;

import android.view.Surface;

public final class N10Native {
    static { System.loadLibrary("n10"); }
    public static native void bootstrap();
    public static native void onSurfaceCreated(Surface surface);
    public static native void onSurfaceChanged(Surface surface,int width,int height);
    public static native void onSurfaceDestroyed();
    public static native long markFrame();
    public static native long monotonicNanos();
    public static native int pageSize();
    public static native int rendererCapabilities();
    public static native int thermalStatus();
    public static native float thermalHeadroom(int forecastSeconds);
    public static native boolean performanceHintAvailable();
    public static native boolean startPerformanceSession(long[] threadIds,long targetDurationNanos);
    public static native boolean reportPerformanceWork(long actualDurationNanos);
    public static native void stopPerformanceSession();
}
