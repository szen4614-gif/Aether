package com.nova.n10

import android.app.Activity
import android.os.Bundle
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.LinearLayout
import android.widget.TextView
import com.nova.n10.core.N10Bootstrap

class N10Activity : Activity(), SurfaceHolder.Callback {
    private lateinit var status: TextView
    private lateinit var surface: SurfaceView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        surface = SurfaceView(this).also { it.holder.addCallback(this) }
        status = TextView(this).apply {
            text = "NOVA N10\n${N10Bootstrap.status()}\n120 Hz is not an FPS ceiling."
            textSize = 17f
            setPadding(24, 24, 24, 24)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status, LinearLayout.LayoutParams(-1, -2))
            addView(surface, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)
        N10Native.bootstrap()
        status.post { status.text = "NOVA N10\n${N10Bootstrap.status()}\n" + N10Diagnostics.capture().let { d -> "pageSize=${d.pageSize}\nVulkan=${d.vulkan} GLES=${d.gles}\nthermal=${d.thermalStatus} headroom=${d.thermalHeadroom}\nADPF=${d.adpf}" } }
    }

    override fun surfaceCreated(holder: SurfaceHolder) = N10Native.onSurfaceCreated(holder.surface)
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = N10Native.onSurfaceChanged(holder.surface, width, height)
    override fun surfaceDestroyed(holder: SurfaceHolder) = N10Native.onSurfaceDestroyed()
}
