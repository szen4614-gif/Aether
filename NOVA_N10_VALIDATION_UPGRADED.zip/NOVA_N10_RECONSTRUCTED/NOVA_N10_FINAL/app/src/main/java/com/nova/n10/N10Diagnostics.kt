package com.nova.n10

data class N10Diagnostics(val pageSize:Int,val rendererCapabilities:Int,val thermalStatus:Int,val thermalHeadroom:Float,val adpf:Boolean) {
    val pageSize16K:Boolean get()=pageSize==16384
    val vulkan:Boolean get()=rendererCapabilities and 1 != 0
    val gles:Boolean get()=rendererCapabilities and 2 != 0
    companion object { fun capture()=N10Diagnostics(N10Native.pageSize(),N10Native.rendererCapabilities(),N10Native.thermalStatus(),N10Native.thermalHeadroom(10),N10Native.performanceHintAvailable()) }
}
