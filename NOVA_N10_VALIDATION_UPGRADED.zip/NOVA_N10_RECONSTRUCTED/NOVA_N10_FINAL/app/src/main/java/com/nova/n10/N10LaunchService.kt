package com.nova.n10

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.Build
import com.nova.n10.core.runtime.JavaRuntime
import com.nova.n10.core.runtime.LaunchPlan
import com.nova.n10.core.runtime.MinecraftProcess
import java.nio.file.Path
import kotlin.concurrent.thread

/** Real JVM process supervision boundary. Payloads must be provisioned and verified first. */
class N10LaunchService : Service() {
    private var process: Process? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        process?.destroy()
        val executable = intent.getStringExtra(EXTRA_JAVA) ?: return fail(startId, "Missing Java executable")
        val runtimeId = intent.getStringExtra(EXTRA_RUNTIME_ID) ?: "external-runtime"
        val runtimeRoot = intent.getStringExtra(EXTRA_RUNTIME_ROOT)?.let(Path::of)
        val gameDirectory = intent.getStringExtra(EXTRA_GAME_DIR)?.let(Path::of)
            ?: return fail(startId, "Missing game directory")
        val nativeDirectory = intent.getStringExtra(EXTRA_NATIVE_DIR)?.let(Path::of)
            ?: return fail(startId, "Missing native directory")
        val mainClass = intent.getStringExtra(EXTRA_MAIN_CLASS)
            ?: return fail(startId, "Missing Minecraft main class")
        val classpath = intent.getStringArrayListExtra(EXTRA_CLASSPATH) ?: arrayListOf()
        val jvmArgs = intent.getStringArrayListExtra(EXTRA_JVM_ARGS) ?: arrayListOf()
        val gameArgs = intent.getStringArrayListExtra(EXTRA_GAME_ARGS) ?: arrayListOf()

        return try {
            val runtime = JavaRuntime(runtimeId, intent.getIntExtra(EXTRA_JAVA_MAJOR, 17), executable, Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown", "external")
            val plan = LaunchPlan(intent.getStringExtra(EXTRA_MC_VERSION) ?: "unknown", runtime.major, mainClass, classpath, jvmArgs, gameArgs, gameDirectory.toString(), nativeDirectory.toString())
            process = MinecraftProcess(runtime, runtimeRoot).start(plan)
            val p = process!!
            thread(name = "n10-process-watcher", isDaemon = true) {
                val code = p.waitFor()
                android.util.Log.i(TAG, "Minecraft JVM exited with code=$code")
                stopSelf(startId)
            }
            START_STICKY
        } catch (t: Throwable) {
            android.util.Log.e(TAG, "Minecraft launch failed", t)
            fail(startId, t.message ?: t.javaClass.simpleName)
        }
    }

    override fun onDestroy() {
        process?.let { if (it.isAlive) it.destroy() }
        process = null
        super.onDestroy()
    }

    private fun fail(startId: Int, reason: String): Int {
        android.util.Log.e(TAG, "Launch rejected: $reason")
        stopSelf(startId)
        return START_NOT_STICKY
    }

    companion object {
        private const val TAG = "N10LaunchService"
        const val EXTRA_JAVA = "java"
        const val EXTRA_RUNTIME_ID = "runtimeId"
        const val EXTRA_RUNTIME_ROOT = "runtimeRoot"
        const val EXTRA_GAME_DIR = "gameDirectory"
        const val EXTRA_NATIVE_DIR = "nativeDirectory"
        const val EXTRA_MAIN_CLASS = "mainClass"
        const val EXTRA_CLASSPATH = "classpath"
        const val EXTRA_JVM_ARGS = "jvmArgs"
        const val EXTRA_GAME_ARGS = "gameArgs"
        const val EXTRA_MC_VERSION = "minecraftVersion"
        const val EXTRA_JAVA_MAJOR = "javaMajor"
    }
}
