# Telemetry schema

Every benchmark record should include: device/ABI/Android API; runtime Java; Minecraft version; loader/modpack hash; renderer/driver; resolution; refresh rate; produced FPS; presented FPS; frame-time percentiles; CPU/GPU time; queue/present stalls; GC; allocations; memory/RSS; thermal headroom; battery/power mode; timestamp; benchmark seed/world/camera; configuration hash.
