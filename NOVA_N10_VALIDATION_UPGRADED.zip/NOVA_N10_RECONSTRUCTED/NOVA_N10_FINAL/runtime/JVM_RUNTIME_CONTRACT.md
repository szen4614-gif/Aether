# JVM runtime contract

A runtime provider must supply a verified JVM distribution compatible with the selected Minecraft version/loader/ABI. The launcher constructs the real process command, classpath, natives directory and game directory. No JVM binary is bundled by this repository.
