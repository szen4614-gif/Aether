# Runtime / LWJGL component provisioning

NOVA N10 does not invent or redistribute a Java runtime or LWJGL binary. The launcher consumes real, architecture-matched components and verifies their hashes before installation.

## Reference integration

Pojav/Amethyst demonstrate the Android-specific packaging model: architecture-specific JREs, Android-compatible LWJGL/GLFW integration, and per-version native components. Pojav's documented build downloads JRE artifacts and builds its GLFW/LWJGL bridge before the launcher APK. NOVA N10 keeps that dependency boundary explicit instead of copying an entire launcher.

## Required payloads for Minecraft end-to-end

- Android JRE 17 for Minecraft 1.17+ (arm64-v8a for normal 64-bit Android phones)
- Java 8 for legacy versions when required
- LWJGL version matching the Minecraft version
- Android GLFW/window bridge compatible with the selected LWJGL
- OpenGL ES/Vulkan translation backend where the selected Minecraft/LWJGL stack needs one
- OpenAL/audio backend for versions/mods that require it

## Provisioning contract

1. Acquire component from a documented upstream source.
2. Record exact version, architecture, source URL and license.
3. Verify SHA-256 before extraction.
4. Extract into the private N10 component directory.
5. Verify required executables/shared libraries.
6. Reject an ABI mismatch.
7. Record the component manifest in the instance.

The runtime manager already implements the secure archive boundary. This file deliberately does not embed third-party binaries.
