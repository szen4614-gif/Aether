# Telemetry

Telemetry levels: OFF, LOW, MEDIUM, FULL, TRACE. Hot paths use bounded/preallocated structures where practical. Trace mode is explicitly allowed to perturb performance and is not used for final benchmark claims.
