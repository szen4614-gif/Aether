# N10 rebuild rules

Treat the original ZIP as raw material. Do not infer that a directory exists because a README says it exists. Do not claim real Minecraft execution until real artifacts, runtime, classpath, natives, surface and process lifecycle have been validated on a device/emulator.

For every integration record one of: IMPLEMENTED / PARTIAL / SCAFFOLD / EXPERIMENTAL / EXTERNAL-DEPENDENCY / NOT-IMPLEMENTED.

Never fabricate benchmark values. Never report display refresh as Minecraft FPS. Never silently rewrite worlds or saves. Never silently disable user mods. Never download untrusted binaries without verification.

Before shipping a performance optimization, run controlled A/B tests and record the exact environment, workload, configuration, result and confidence.
