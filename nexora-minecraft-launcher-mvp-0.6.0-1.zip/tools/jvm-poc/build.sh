#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/app/src/main/assets/poc"
BUILD="$ROOT/.build/jvm-poc"
rm -rf "$BUILD"
mkdir -p "$BUILD/classes" "$OUT"
javac --release 17 -d "$BUILD/classes" "$ROOT/tools/jvm-poc/HelloWorld.java"
jar --create --file "$OUT/java-poc.jar" -C "$BUILD/classes" .
printf 'Built %s\n' "$OUT/java-poc.jar"
