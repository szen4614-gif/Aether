#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BUILD="$ROOT/.build/android-java-verification-poc"
OUT="$ROOT/android-java-verification/src/main/assets/poc/java-poc.jar"
rm -rf "$BUILD"; mkdir -p "$BUILD/classes" "$(dirname "$OUT")"
javac --release 17 -d "$BUILD/classes" "$ROOT/tools/jvm-poc/HelloWorld.java"
jar --create --file "$OUT" -C "$BUILD/classes" .
printf 'Built %s\n' "$OUT"
