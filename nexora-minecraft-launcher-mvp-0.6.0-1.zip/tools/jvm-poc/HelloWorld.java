package com.nexora.poc;

public final class HelloWorld {
    static {
        String nativePath = System.getProperty("nexora.poc.native.path");
        if (nativePath != null && !nativePath.isEmpty()) System.load(nativePath);
        else { String nativeName = System.getProperty("nexora.poc.native", "nexora_poc_native"); System.loadLibrary(nativeName); }
    }

    private static native int nativeRoundTrip(int value);

    public static void main(String[] args) {
        if (Boolean.getBoolean("nexora.poc.throw")) throw new IllegalStateException("NEXORA_INJECTED_JAVA_EXCEPTION");
        System.out.println("NEXORA_JAVA_STDOUT: HelloWorld.main executed");
        System.err.println("NEXORA_JAVA_STDERR: stderr channel executed");
        int value = Boolean.getBoolean("nexora.poc.failRoundTrip") ? 43 : nativeRoundTrip(41);
        System.setProperty("nexora.jni.result", Integer.toString(value));
        System.out.println("NEXORA_JNI_RESULT: " + value);
        if (value != 42) {
            throw new IllegalStateException("JNI round-trip failed: " + value);
        }
    }
}
