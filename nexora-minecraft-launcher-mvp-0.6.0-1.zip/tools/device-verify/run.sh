#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/.build/device-verify"; REPORT="$OUT/report.md"; LOG="$OUT/logcat.txt"
ARCHIVE="${NEXORA_RUNTIME_ARCHIVE:-$ROOT/.build/runtime/jre17-android-arm64.tar.xz}"
RUNTIME_HOME="${NEXORA_RUNTIME_HOME:-$ROOT/.build/runtime/jre17-android-arm64}"
APK="$ROOT/android-java-verification/build/outputs/apk/debug/android-java-verification-debug.apk"; PKG=com.nexora.verification
mkdir -p "$OUT"; : > "$LOG"
add(){ printf '| %s | %s | %s |\n' "$1" "$2" "${3//|/\\|}" >> "$REPORT"; }
final=NOT_VERIFIED
integrity_ok=false
build_ok=false
{
 echo '# ANDROID_JAVA_POC — device verification'; echo; echo "Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"; echo
 echo '| Check | Result | Detail |'; echo '|---|---|---|'
} > "$REPORT"

# 1. Runtime acquisition is explicit and cryptographic.
if [[ ! -d "$RUNTIME_HOME" && -f "$ARCHIVE" ]]; then
  EXPECTED=e162c860fe05ee4a4e4af7606437419879f6c748386a7b09fa77d10db6a64091
  ACTUAL=$(sha256sum "$ARCHIVE" 2>/dev/null | awk '{print $1}')
  if [[ "$EXPECTED" == "$ACTUAL" ]]; then
    rm -rf "$RUNTIME_HOME"; mkdir -p "$RUNTIME_HOME"; tar -xJf "$ARCHIVE" -C "$RUNTIME_HOME"
    children=("$RUNTIME_HOME"/*); if [[ ${#children[@]} -eq 1 && -d "${children[0]}" ]]; then tmp="${RUNTIME_HOME}.tmp"; mv "$RUNTIME_HOME" "$tmp"; mkdir -p "$RUNTIME_HOME"; cp -a "$tmp"/* "$RUNTIME_HOME"/; rm -rf "$tmp"; fi
    add RUNTIME_ACQUIRED PASS "$ARCHIVE"
    add RUNTIME_INTEGRITY_VERIFIED PASS "$ACTUAL"; integrity_ok=true
  else add RUNTIME_INTEGRITY_VERIFIED FAIL "expected=$EXPECTED actual=$ACTUAL"; echo 'FINAL = FAIL' >> "$REPORT"; cat "$REPORT"; exit 2; fi
elif [[ -d "$RUNTIME_HOME" ]]; then
  add RUNTIME_ACQUIRED PASS "$RUNTIME_HOME (pre-provisioned)"
  if [[ -f "$ARCHIVE" ]]; then ACTUAL=$(sha256sum "$ARCHIVE" | awk '{print $1}'); if [[ "$ACTUAL" == e162c860fe05ee4a4e4af7606437419879f6c748386a7b09fa77d10db6a64091 ]]; then add RUNTIME_INTEGRITY_VERIFIED PASS "$ACTUAL"; integrity_ok=true; else add RUNTIME_INTEGRITY_VERIFIED FAIL "archive hash mismatch"; fi; else add RUNTIME_INTEGRITY_VERIFIED NOT_VERIFIED 'archive unavailable; supplied directory only'; fi
else add RUNTIME_ACQUIRED NOT_VERIFIED 'runtime archive/directory unavailable'; fi

# 2. Build the APK only after native runtime preparation. This is the Android-correct model: .so in APK, JRE data provisioned later.
if [[ -d "$RUNTIME_HOME" ]]; then
  if "$ROOT/tools/runtime-inspect/prepare-apk-runtime.sh" "$RUNTIME_HOME" > "$OUT/native-prepare.txt" 2>&1; then add RUNTIME_STRUCTURE_VERIFIED PASS 'native ELF set prepared for APK'; else add RUNTIME_STRUCTURE_VERIFIED FAIL "$(tail -1 "$OUT/native-prepare.txt")"; fi
else
  rm -rf "$ROOT/android-java-verification/src/main/jniLibs/arm64-v8a"; mkdir -p "$ROOT/android-java-verification/src/main/jniLibs/arm64-v8a"
  add RUNTIME_STRUCTURE_VERIFIED NOT_VERIFIED 'runtime absent; no JVM native library packaged'
fi

if command -v gradle >/dev/null 2>&1; then
  if gradle --version >/dev/null 2>&1 && gradle -p "$ROOT" :android-java-verification:testDebugUnitTest :android-java-verification:assembleDebug --stacktrace >/dev/null; then add APK_BUILD PASS 'verification APK'; build_ok=true; else add APK_BUILD FAIL 'Gradle build failed'; fi
else add APK_BUILD NOT_VERIFIED 'Gradle unavailable'; fi

if command -v adb >/dev/null 2>&1; then add ADB_TOOL PASS 'adb available'; else add ADB_TOOL NOT_VERIFIED 'adb unavailable'; fi
if [[ -f "$APK" ]]; then add APK_PRESENT PASS "$APK"; else add APK_PRESENT NOT_VERIFIED 'APK absent'; fi

if command -v adb >/dev/null 2>&1 && [[ -f "$APK" ]] && [[ "$build_ok" == true ]] && [[ "$integrity_ok" == true ]]; then
  DEV=$(adb devices | awk 'NR>1 && $2=="device"{print $1;exit}')
  if [[ -n "$DEV" ]]; then add DEVICE_CONNECTED PASS "$DEV"; else add DEVICE_CONNECTED NOT_VERIFIED 'no authorized device'; fi
  if [[ -n "$DEV" ]]; then
    ABI=$(adb shell getprop ro.product.cpu.abilist | tr -d '\r'); add ABI "$([[ "$ABI" == *arm64-v8a* ]] && echo PASS || echo FAIL)" "$ABI"
    if [[ "$ABI" == *arm64-v8a* ]] && adb install -r "$APK" >/dev/null; then
      add APK_INSTALL PASS installed
      # Only JRE data is provisioned after installation. Native runtime .so files
      # are already inside the APK/nativeLibraryDir; they are never copied into
      # writable app-private storage.
      adb shell run-as "$PKG" rm -rf files/verification-runtime
      adb shell run-as "$PKG" mkdir -p files/verification-runtime
      rm -rf "$OUT/runtime-data"; mkdir -p "$OUT/runtime-data"
      cp -a "$RUNTIME_HOME"/. "$OUT/runtime-data"/
      find "$OUT/runtime-data" -type f -name '*.so' -delete
      adb push "$OUT/runtime-data/." /data/local/tmp/nexora-runtime-data >/dev/null 2>&1
      adb shell run-as "$PKG" sh -c 'cp -R /data/local/tmp/nexora-runtime-data/. files/verification-runtime/'
      adb shell rm -rf /data/local/tmp/nexora-runtime-data
      add RUNTIME_DATA_PROVISION PASS 'JRE data only; native .so remain APK packaged'
      adb logcat -c >/dev/null 2>&1 || true
      adb shell am force-stop "$PKG" >/dev/null 2>&1 || true
      adb shell am start -n "$PKG/.VerificationActivity" --ez RUN_POC true >/dev/null 2>&1
      sleep "${NEXORA_POC_WAIT_SECONDS:-8}"
      adb logcat -d -s NEXORA_VERIFY:I NEXORA_VERIFY:E AndroidRuntime:E '*:S' > "$LOG" 2>&1 || true
      for key in RUNTIME_FOUND RUNTIME_NATIVE_LOADABLE JVM_LOAD JNI_CreateJavaVM JVM_INIT FindClass JAVA_EXEC JNI_ROUNDTRIP JVM_SHUTDOWN; do grep -q "${key}=PASS" "$LOG" && add "$key" PASS 'device evidence' || add "$key" NOT_VERIFIED 'marker absent'; done
      if grep -q 'FINAL=PASS' "$LOG"; then add ANDROID_JAVA_POC PASS 'device reported FINAL=PASS'; final=PASS; elif grep -q 'FINAL=EXPECTED_FAILURE' "$LOG"; then add ANDROID_JAVA_POC FAIL 'unexpected expected-failure marker in normal run'; else add ANDROID_JAVA_POC NOT_VERIFIED 'FINAL=PASS not observed'; fi
      echo; echo '## Logcat'; echo '```text'; cat "$LOG"; echo '```' >> "$REPORT"
    else add APK_INSTALL FAIL 'install or ABI check failed'; fi
  fi
else add EXECUTION NOT_VERIFIED 'requires successful APK build + verified runtime archive + ADB + ARM64 device'; fi

echo "FINAL = $final" >> "$REPORT"; cat "$REPORT"; [[ "$final" == PASS ]] && exit 0 || exit 2
