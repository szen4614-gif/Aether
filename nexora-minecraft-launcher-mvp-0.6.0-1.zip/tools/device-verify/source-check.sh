#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; CPP="$ROOT/android-java-verification/src/main/cpp/verification_bridge.cpp"; fail=0
check(){ grep -Eq "$1" "$CPP" && echo "PASS $2" || { echo "FAIL $2"; fail=1; }; }
check 'using CreateJvmFn = jint \(\*\)\(JavaVM \*\*, void \*\*, void \*\);' 'JNI_CreateJavaVM ABI signature'
check 'JavaVM\* vm=nullptr; JNIEnv\* jni=nullptr;' 'JavaVM and JNIEnv state'
check 'vmArgs.version=JNI_VERSION_1_8;' 'VM init version'
check 'g_vm=vm;' 'active VM state'
check 'vm->DestroyJavaVM\(\)' 'shutdown call'
check 'closeHandles\(\);' 'native handle cleanup'
check 'std::lock_guard<std::mutex> lock\(g_mutex\);' 'concurrency serialization'
exit "$fail"
