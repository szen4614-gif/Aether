#!/usr/bin/env bash
set -u
PKG=com.nexora.verification
ADB="${ADB:-adb}"
DEV="$($ADB devices | awk 'NR>1 && $2=="device"{print $1;exit}')"
[[ -n "$DEV" ]] || { echo 'DEVICE=NOT VERIFIED'; exit 2; }
for mode in 1 2 3 4 5; do
  $ADB logcat -c >/dev/null 2>&1 || true
  $ADB shell am force-stop "$PKG" >/dev/null 2>&1 || true
  $ADB shell am start -n "$PKG/.VerificationActivity" --ez RUN_POC true --ei FAULT_MODE "$mode" >/dev/null 2>&1
  sleep "${NEXORA_FAILURE_WAIT_SECONDS:-5}"
  log=$($ADB logcat -d -s NEXORA_VERIFY:I NEXORA_VERIFY:E '*:S' 2>/dev/null)
  if grep -q 'FINAL=EXPECTED_FAILURE:' <<< "$log"; then echo "FAULT_MODE=$mode EXPECTED_FAILURE=PASS"; else echo "FAULT_MODE=$mode EXPECTED_FAILURE=NOT_VERIFIED"; fi
done
