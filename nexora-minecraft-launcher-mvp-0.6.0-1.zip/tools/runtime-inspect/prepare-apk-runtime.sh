#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
INPUT="${1:-${NEXORA_RUNTIME_HOME:-$ROOT/.build/runtime/jre17-android-arm64}}"
DEST="$ROOT/android-java-verification/src/main/jniLibs/arm64-v8a"
MANIFEST="$ROOT/android-java-verification/src/main/jniLibs/runtime-native-manifest.txt"
READELF="$(command -v llvm-readelf || command -v readelf || true)"
if [[ ! -d "$INPUT" ]]; then echo "RUNTIME_HOME_MISSING=$INPUT"; exit 2; fi
if [[ -z "$READELF" ]]; then echo 'READ_ELF=NOT_VERIFIED'; exit 2; fi
JVM=""
for p in "$INPUT/lib/server/libjvm.so" "$INPUT/lib/aarch64/server/libjvm.so" "$INPUT/lib/libjvm.so"; do [[ -f "$p" ]] && JVM="$p" && break; done
[[ -n "$JVM" ]] || { echo 'LIBJVM=FAIL:not found'; exit 3; }
rm -rf "$DEST"; mkdir -p "$DEST"
declare -A names=()
while IFS= read -r -d '' so; do
  base="$(basename "$so")"
  [[ -z "${names[$base]+x}" ]] || { echo "DUPLICATE_SONAME_FILE=$base"; exit 4; }
  names[$base]="$so"
  machine="$($READELF -h "$so" | sed -n 's/^ *Machine: *//p' | head -1)"
  [[ "$machine" == *AArch64* || "$machine" == *ARM64* ]] || { echo "ABI_FAIL=$so:$machine"; exit 5; }
  cp -f "$so" "$DEST/$base"
done < <(find "$INPUT" -type f -name '*.so' -print0 | sort -z)
needed="$($READELF -d "$JVM" | sed -n 's/.*Shared library: \[\([^]]*\)\].*/\1/p' | sort -u)"
while IFS= read -r dep; do
  [[ -z "$dep" ]] && continue
  [[ -f "$DEST/$dep" ]] || { echo "DT_NEEDED_MISSING=$dep"; exit 6; }
done <<< "$needed"
{
 echo 'NEXORA_RUNTIME_NATIVE_LAYOUT=APK_JNILIBS_ARM64'
 echo "LIBJVM_SOURCE=$JVM"
 echo "LIBJVM_DEST=$DEST/$(basename "$JVM")"
 echo 'NATIVE_LIBRARY_COUNT='"$(find "$DEST" -maxdepth 1 -name '*.so' | wc -l | tr -d ' ')"
 echo 'LIBJVM_DT_NEEDED='
 echo "$needed"
 echo 'LIBJVM_DYNAMIC='; "$READELF" -d "$JVM" | grep -E 'NEEDED|SONAME|RPATH|RUNPATH' || true
} > "$MANIFEST"
echo "NATIVE_PREPARE=PASS"
echo "DEST=$DEST"
cat "$MANIFEST"
