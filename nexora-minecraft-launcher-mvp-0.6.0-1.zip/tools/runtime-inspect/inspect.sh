#!/usr/bin/env bash
set -u
ROOT="${1:?usage: inspect.sh <runtime-home> [archive] [report]}"
ARCHIVE="${2:-}"
REPORT="${3:-$PWD/docs/RUNTIME_VERIFICATION_REPORT.md}"
mkdir -p "$(dirname "$REPORT")"
READELF="$(command -v llvm-readelf || command -v readelf || true)"
NM="$(command -v llvm-nm || command -v nm || true)"
SHA="$(command -v sha256sum || true)"
JVM=""
for p in "$ROOT/lib/server/libjvm.so" "$ROOT/lib/aarch64/server/libjvm.so" "$ROOT/lib/libjvm.so"; do if [[ -f "$p" ]]; then JVM="$p"; break; fi; done
{
 echo '# Runtime Verification Report'; echo; echo "Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"; echo
 echo '## Evidence ledger';
 if [[ -d "$ROOT" ]]; then echo 'RUNTIME_ACQUIRED = PASS'; else echo 'RUNTIME_ACQUIRED = NOT VERIFIED'; fi
 if [[ -n "$ARCHIVE" && -f "$ARCHIVE" && -n "$SHA" ]]; then echo "RUNTIME_INTEGRITY_VERIFIED = $( $SHA "$ARCHIVE" | awk '{print $1}' )"; else echo 'RUNTIME_INTEGRITY_VERIFIED = NOT VERIFIED'; fi
 if [[ -n "$JVM" ]]; then echo 'RUNTIME_STRUCTURE_VERIFIED = PASS (libjvm present; ELF checks below)'; else echo 'RUNTIME_STRUCTURE_VERIFIED = NOT VERIFIED'; fi
 echo 'RUNTIME_NATIVE_LOADABLE = NOT VERIFIED (requires Android linker)'; echo 'JVM_INITIALIZED = NOT VERIFIED'; echo 'JAVA_EXECUTED = NOT VERIFIED'; echo 'JNI_EXECUTED = NOT VERIFIED'; echo 'JVM_SHUTDOWN = NOT VERIFIED'; echo 'ANDROID_JAVA_POC = NOT VERIFIED'; echo
 echo '## Candidate'; echo '- Runtime: jre17-android-arm64'; echo "- Runtime home: $ROOT"
 if [[ -n "$ARCHIVE" && -f "$ARCHIVE" && -n "$SHA" ]]; then echo "- Archive SHA-256: $($SHA "$ARCHIVE" | awk '{print $1}')"; fi
 if [[ ! -d "$ROOT" ]]; then echo; echo 'FINAL=NOT VERIFIED'; exit 0; fi
 if [[ -z "$JVM" ]]; then echo '- libjvm: FAIL — not found'; echo; echo 'FINAL=FAIL'; exit 0; fi
 echo; echo '## libjvm'; echo "- path: $JVM"
 [[ -n "$SHA" ]] && echo "- libjvm SHA-256: $($SHA "$JVM" | awk '{print $1}')"
 if [[ -n "$READELF" ]]; then
   echo '### ELF / ABI'; echo '```text'; "$READELF" -h "$JVM" | grep -E 'Class:|Machine:|Type:|OS/ABI:' || true; echo '```'
   machine=$("$READELF" -h "$JVM" | sed -n 's/^ *Machine: *//p' | head -1)
   [[ "$machine" == *AArch64* || "$machine" == *ARM64* ]] && echo 'ABI_CHECK=PASS:AArch64' || echo "ABI_CHECK=FAIL:$machine"
   echo; echo '### DT_NEEDED / SONAME / RPATH / RUNPATH'; echo '```text'; "$READELF" -d "$JVM" | grep -E 'NEEDED|SONAME|RPATH|RUNPATH' || true; echo '```'
   echo '### libjvm dependencies'; deps=$("$READELF" -d "$JVM" | sed -n 's/.*Shared library: \[\([^]]*\)\].*//p' | sort -u); if [[ -n "$deps" ]]; then while IFS= read -r dep; do [[ -z "$dep" ]] && continue; if find "$ROOT" -type f -name "$dep" -print -quit | grep -q .; then echo "DEPENDENCY=PASS:$dep"; else echo "DEPENDENCY=FAIL:$dep"; fi; done <<< "$deps"; else echo 'DEPENDENCY=NOT_VERIFIED:DT_NEEDED unavailable'; fi
 else echo 'ELF_CHECK=NOT_VERIFIED:readelf unavailable'; fi
 echo; echo '### JNI_CreateJavaVM'; if [[ -n "$NM" ]]; then "$NM" -D "$JVM" 2>/dev/null | grep 'JNI_CreateJavaVM' || echo 'JNI_CreateJavaVM=FAIL:not found'; else echo 'JNI_CreateJavaVM=NOT_VERIFIED:nm unavailable'; fi
 echo; echo '## Android loading model';
 echo '- Native runtime .so files: APK `lib/arm64-v8a/` / ApplicationInfo.nativeLibraryDir.'
 echo '- Runtime data: app-private `files/verification-runtime`.'
 echo '- Writable app-private `.so` execution is NOT used.'
 echo '- Android linker load remains an execution gate.'
 echo; echo '## Final'; echo 'FINAL=NOT VERIFIED (device execution required)'
} > "$REPORT"
cat "$REPORT"
