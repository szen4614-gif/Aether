#!/usr/bin/env bash
set -euo pipefail
URL='https://github.com/AngelAuraMC/angelauramc-openjdk-build/releases/download/download/jre17-android-arm64.tar.xz'
EXPECTED='e162c860fe05ee4a4e4af7606437419879f6c748386a7b09fa77d10db6a64091'
OUT="${1:-.build/runtime/jre17-android-arm64.tar.xz}"
ROOT="${2:-.build/runtime/jre17}"
mkdir -p "$(dirname "$OUT")"
if [[ ! -f "$OUT" ]]; then
  command -v curl >/dev/null 2>&1 || { echo 'DOWNLOAD=NOT VERIFIED:curl unavailable'; exit 3; }
  curl -fL --retry 3 -o "$OUT" "$URL"
fi
ACTUAL="$(sha256sum "$OUT" | awk '{print $1}')"
printf 'EXPECTED_SHA256=%s\nACTUAL_SHA256=%s\n' "$EXPECTED" "$ACTUAL"
if [[ "$ACTUAL" != "$EXPECTED" ]]; then echo 'RUNTIME=FAIL:hash mismatch'; exit 4; fi
echo 'RUNTIME=PASS:archive hash'
rm -rf "$ROOT"; mkdir -p "$ROOT"
tar -xJf "$OUT" -C "$ROOT" --strip-components=1
"$(dirname "$0")/inspect.sh" "$ROOT" "$(cd "$(dirname "$0")/../.." && pwd)/docs/RUNTIME_VERIFICATION_REPORT.md"
