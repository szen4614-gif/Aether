# NEXORA Status — 0.6

Evidence rule: SOURCE → BUILD → EXECUTION → FUNCTIONAL. Only FUNCTIONAL=PASS promotes a milestone to PASS.

| Milestone | SOURCE | BUILD | EXECUTION | FUNCTIONAL | Overall |
|---|---|---|---|---|---|
| ANDROID_JAVA_POC | PASS | NOT VERIFIED | NOT VERIFIED | NOT VERIFIED | NOT VERIFIED |
| JNI_POC | PASS | NOT VERIFIED | NOT VERIFIED | NOT VERIFIED | NOT VERIFIED |
| ANDROID_LWJGL_POC | PASS (prepared) | NOT STARTED | NOT VERIFIED | NOT VERIFIED | NOT VERIFIED |
| VANILLA_1_20_4_BOOT | PASS (preparation) | NOT VERIFIED | NOT VERIFIED | NOT VERIFIED | NOT VERIFIED |

## ANDROID_JAVA_POC evidence chain

```text
RUNTIME_ACQUIRED
    ↓
RUNTIME_INTEGRITY_VERIFIED
    ↓
RUNTIME_STRUCTURE_VERIFIED
    ↓
RUNTIME_NATIVE_LOADABLE
    ↓
JVM_INITIALIZED
    ↓
JAVA_EXECUTED
    ↓
JNI_EXECUTED
    ↓
JVM_SHUTDOWN
    ↓
ANDROID_JAVA_POC
```

Only the final functional gate can promote `ANDROID_JAVA_POC` to PASS.

## Runtime loading decision

- MODE_A: native runtime `.so` files packaged in APK `lib/arm64-v8a/`; selected for the POC.
- MODE_B: JRE data provisioned after installation while native `.so` files remain APK-packaged; supported hybrid form.
- Fully post-install native `.so` runtime under writable `files/` is not used as the POC execution model.

## 0.6 concrete artifacts

- `android-java-verification/` is a separate disposable Android application.
- `tools/device-verify/run.sh` is the single device gate.
- `tools/device-verify/failure-matrix.sh` exercises expected failure classifications on a device.
- `tools/runtime-inspect/inspect.sh` produces evidence from the actual runtime files.
- `tools/runtime-inspect/fetch-and-verify.sh` verifies the candidate archive before extraction/inspection.

## Current environment

No Android SDK/NDK/ADB or ARM64 device is available in this session. Therefore BUILD/EXECUTION/FUNCTIONAL remain NOT VERIFIED here. Host C++ syntax checks and JAR generation are SOURCE-level/build-artifact checks only; they do not promote the Android milestone.
