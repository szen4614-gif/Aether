# NEXORA bootstrap workstream

The NEXORA source specification requires research first, then architecture, language, type/memory, compiler, runtime, systems, AI, game, media, mobile, tooling, ecosystem, security, testing and bootstrap. It explicitly defines the bootstrap sequence:

```text
Compiler 0 → Minimal NEXORA → Compiler 1 → Self-hosting Compiler → NEXORA Compiler
```

For this launcher repository the safe strategy is:

1. Keep Kotlin as the temporary host implementation.
2. Define stable service interfaces in the launcher.
3. Build Compiler 0 separately with a minimal lexer/parser/AST/type checker/CLI/test suite.
4. Add only proven NEXORA capabilities required by launcher modules.
5. Produce an ARM64-compatible NEXORA runtime/toolchain.
6. Port one leaf module at a time, keeping Kotlin fallback until tests pass.
7. Only then consider NEXORA the production implementation language for launcher modules.
