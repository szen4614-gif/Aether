# Device Verification — 0.6

## Single command

```text
./tools/device-verify/run.sh
```

It attempts, in order: prerequisites/build, ADB/device discovery, runtime acquisition/verification if the archive is present, APK install, runtime provisioning, log clearing, POC launch, logcat collection, marker extraction, and final classification.

`FINAL=PASS` is emitted only when the verification APK itself reports `FINAL=PASS`. Missing infrastructure results in `FINAL=NOT VERIFIED`; observed execution failures are reported as FAIL/expected-failure markers rather than being upgraded to PASS.

## Failure matrix

After a runtime and APK are installed:

```text
./tools/device-verify/failure-matrix.sh
```

The POC supports deterministic fault modes for missing class, missing main, Java exception, shutdown-failure classification injection, and JNI round-trip failure. These are test paths, not evidence that a real JVM naturally produced those faults.

## What does not count

Desktop compilation, host clang syntax checks, existence of a `.so`, a known public hash, third-party documentation, or execution on a non-ARM64 architecture cannot promote `ANDROID_JAVA_POC`.
