# Android Runtime Loading Model — 0.6

## Decision

The verification APK uses a **hybrid runtime model**:

```text
APK
├── lib/arm64-v8a/*.so        <- executable native code, including OpenJDK 17 libjvm + dependencies
└── app code

app-private files/verification-runtime/
├── release
├── lib/modules
├── conf/
├── legal/
├── bin/ and other non-.so runtime data
└── other JRE resources
```

The POC does **not** copy JRE `.so` files into writable app-private storage.

## Why

Android's API-29 security model removed direct execution of files from the writable app home and states that applications should load binary code embedded in the APK. Therefore a writable `files/verification-runtime/lib/.../*.so` tree is not the foundation of this POC.

The Android application native-library directory is exposed as `ApplicationInfo.nativeLibraryDir`. The verification APK packages the runtime native libraries under `lib/arm64-v8a/`; the bridge loads `libjvm.so` from that directory with `dlopen`.

The JRE's non-native data is different: it is ordinary runtime data and can be provisioned after installation into the app's private files directory.

## MODE_A — native libraries packaged in APK

```text
runtime archive
      |
      +-- .so files --> android-java-verification/src/main/jniLibs/arm64-v8a/
      |
      +-- non-.so data --> files/verification-runtime/ on device
```

This is the required POC mode.

The preparation tool verifies that the native files are AArch64 and that the `DT_NEEDED` entries of `libjvm.so` exist in the APK native set. It records SONAME/RPATH/RUNPATH rather than assuming that those fields are harmless.

Actual Android linker loading remains an execution gate. ELF inspection is not evidence that Android accepted the libraries.

## MODE_B — runtime provisioned after installation

A fully post-install runtime containing `libjvm.so` and its native dependencies under `files/verification-runtime` is **not the selected Android POC model**.

The supported interpretation of MODE_B is therefore:

```text
native code: APK
JRE data:    provisioned after installation
```

This retains runtime update flexibility without depending on executable native code being copied into writable application storage.

## Linker implications

`LD_LIBRARY_PATH` is configured to include `ApplicationInfo.nativeLibraryDir` before `dlopen(libjvm.so)`.

The bridge uses the absolute path to the packaged `libjvm.so` and `RTLD_NOW | RTLD_GLOBAL` so that its exported JVM entry point and loaded dependency set are available to the subsequent JNI lifecycle.

`DT_NEEDED`, SONAME, RPATH and RUNPATH are inspected from the actual binary. No desktop assumption is treated as proof of Android compatibility.

If a runtime requires an ELF layout that cannot be represented by the APK native-library directory, the preparation step must fail instead of silently copying the files into `files/`.

## Invocation API boundary

This document intentionally separates two gates:

### Problem A — native loading

```text
APK nativeLibraryDir
        |
        +--> libjli.so / libjava.so / libnet.so / libnio.so / libverify.so / ...
        |
        +--> libjvm.so
        |
        +--> Android linker accepts dependency graph
```

### Problem B — JVM execution

```text
JNI_CreateJavaVM
        |
        +--> JNIEnv
        +--> FindClass
        +--> GetStaticMethodID(main)
        +--> HelloWorld.main()
        +--> Java -> native -> 41 -> 42 -> Java
        +--> DestroyJavaVM
```

A PASS in A never implies a PASS in B.

## Lifecycle rule

The verification app performs one JVM lifecycle per Android process. After `DestroyJavaVM`, the native JVM library is intentionally not `dlclose`d and the bridge rejects a second JVM run in the same process.

This avoids treating repeated JVM creation/unloading as supported when the Invocation API explicitly does not support multiple VMs in one process.

To repeat the experiment, restart the verification process.
