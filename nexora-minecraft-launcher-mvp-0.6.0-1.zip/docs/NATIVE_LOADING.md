# Native Loading — 0.4

## Runtime model

NEXORA distinguishes three native categories:

1. **NEXORA-owned Android libraries** — built by NDK and packaged in the APK. These use Android's normal native-library packaging and `System.loadLibrary`/JNI boundary.
2. **Runtime JVM libraries** — supplied by the selected Android OpenJDK runtime. These are not treated as ordinary Android app libraries; they are validated and loaded by the JVM backend.
3. **Minecraft/LWJGL natives** — downloaded from the legitimate version metadata, validated, extracted and selected by OS/ABI/classifier. They are never assumed to be Android-compatible merely because their classifier says `linux`.

## Current JVM loader behavior

The POC loader:

- searches known Android OpenJDK layouts instead of assuming one path;
- prepares `LD_LIBRARY_PATH` with `lib/jli` and `lib`;
- preloads present helper libraries with `RTLD_GLOBAL`;
- loads `libjvm.so` with `RTLD_NOW | RTLD_GLOBAL`;
- resolves `JNI_CreateJavaVM` explicitly;
- reports each load result;
- destroys the JVM before unloading its handles.

This is deliberately diagnostic. It is not yet declared universally compatible with Android linker namespaces.

## Runtime validation commands

A device/debug environment must record:

```text
readelf -h lib/server/libjvm.so
readelf -d lib/server/libjvm.so
readelf -Ws lib/server/libjvm.so | grep JNI_CreateJavaVM
readelf -d lib/*.so
```

Where `readelf` is unavailable, use `llvm-readelf` from the NDK.

The result must record:

- ELF machine;
- ELF class;
- `DT_NEEDED` entries;
- SONAME/RPATH/RUNPATH;
- JNI export;
- helper library presence;
- actual linker errors.

## Security requirements

Before loading a downloaded runtime/native artifact:

- HTTPS only;
- allowlisted source;
- declared digest verified;
- archive size limit;
- ZIP/TAR traversal checks;
- symlink/hardlink policy;
- no executable path outside the runtime sandbox;
- ABI validation;
- ELF validation;
- no native load before validation.
