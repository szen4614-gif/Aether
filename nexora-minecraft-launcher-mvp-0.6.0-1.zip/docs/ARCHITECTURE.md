# Architecture — MVP

```text
Android UI
   ↓
Launcher services
   ├── InstanceRepository
   ├── OfflineAccountManager
   ├── VersionManager
   ├── JavaRuntimeManager
   ├── DownloadManager
   ├── Diagnostics
   ├── Performance
   ├── Input model
   └── Security policies
        ↓
Android filesystem / future SAF adapters
```

## Module contract

Minecraft execution is intentionally separated from UI. A future `MinecraftProcessManager` must receive a fully validated instance manifest, selected Java runtime, JVM arguments, classpath and environment, then report lifecycle/log events back to the core. It must never download or execute arbitrary content without validation and explicit user intent.

## NEXORA boundary

The NEXORA documents define a language that is still a specification/roadmap, not a compiler/runtime available in this repository. The launcher therefore does not fabricate a NEXORA API. When Compiler 0 reaches a stable Android/ARM64 target, individual modules can migrate behind interfaces and be validated module-by-module.
