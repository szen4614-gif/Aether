# JVM Android Research — 0.4

Date: 2026-09-08
Target: Android ARM64, Minecraft Java 1.20.4, Java 17

## 1. Explicit evidence boundary

`NativeJvmBridge` is a JVM embedding POC, not a JVM implementation.

The following are different evidence states:

```text
DISCOVERED
INTEGRITY_VERIFIED
STRUCTURE_VERIFIED
NATIVE_LOADABLE
JVM_INITIALIZED
JAVA_EXECUTED
LWJGL_INITIALIZED
MINECRAFT_COMPATIBLE
```

A source file, runtime.properties flag, or successful `dlopen()` does not advance all states.

## 2. Runtime candidates

### Candidate A — current Amethyst Android OpenJDK 17 ARM64

Source/build family: `AngelAuraMC/angelauramc-openjdk-build`.

The public project is an Android OpenJDK build/packaging project derived from the earlier PojavLauncher mobile OpenJDK work. Its 17/21 branch documents Android `aarch64-linux-android`, Java 17/21 targets and Android NDK r27b. The public release center currently publishes `jre17-android-arm64.tar.xz` with a SHA-256 digest and a size of about 25.7 MB.

NEXORA decision: **SELECTED CANDIDATE FOR THE FIRST DEVICE POC**, not yet verified by NEXORA.

Exact candidate recorded:

```text
artifact: jre17-android-arm64.tar.xz
release: download
sha256: e162c860fe05ee4a4e4af7606437419879f6c748386a7b09fa77d10db6a64091
reported size: 25.7 MB
Java major: 17
ABI: arm64-v8a / aarch64
```

The artifact must be acquired and inspected before NEXORA marks it `INTEGRITY_VERIFIED` or `STRUCTURE_VERIFIED`.

### Candidate B — older Pojav Android JRE 17

Public Pojav logs show Android ARM64 JRE17 layouts with `lib/libjli.so`, `lib/server/libjvm.so`, `libverify.so`, `libjava.so`, `libnet.so`, `libnio.so`, and other helper libraries being loaded with a native loader. This proves that the general strategy has existed in production software, but it does not prove that the same binary works in NEXORA or on the target device.

NEXORA decision: evidence/reference only; do not copy implementation.

### Candidate C — Java 21/25 Android runtimes

Current Amethyst runtime distribution includes ARM64 Java 21 and Java 25 builds. They are useful for future Minecraft versions, but are not the first target because Minecraft 1.20.4 is a Java 17 target and the first proof should minimize runtime variables.

NEXORA decision: keep behind `RuntimeProvider`; do not block 1.20.4 on them.

## 3. Why not ProcessBuilder(runtime/bin/java)

Android 10 removed execute permission for files in the writable app home directory. Android documentation explicitly recommends loading binary code embedded in the APK rather than executing binaries from writable app home.

Therefore NEXORA does **not** treat `filesDir/runtimes/.../bin/java` as an executable process strategy.

The Android backend is an embedded JVM strategy:

```text
Android APK
  -> NEXORA native bridge (.so packaged in APK)
  -> selected Android OpenJDK shared libraries
  -> JNI_CreateJavaVM
  -> Java main()
```

The exact behavior of loading a downloaded runtime's `.so` from private app storage remains a device-validation item. Public Pojav/Amethyst evidence shows this pattern has been used, but NEXORA will not convert that evidence into a PASS without hardware verification.

## 4. JVM invocation/threading

The JNI Invocation API documents:

- `JNI_CreateJavaVM` initializes a JVM and returns a `JNIEnv` for the creating thread;
- `JNIEnv` is thread-local;
- other native threads must use `AttachCurrentThread` before JNI calls;
- attached native threads must detach before terminating;
- `DestroyJavaVM` waits for non-daemon threads and therefore must be treated as a lifecycle operation, not a simple free().

NEXORA therefore gives JVM ownership to the Android execution backend. UI, download, logging, render and JVM execution are separate concerns.

## 5. What is still NOT proven

The current environment cannot build the Android APK or acquire the selected ARM64 runtime artifact for ELF inspection. Consequently the following remain `NOT VERIFIED ON DEVICE`:

- exact `DT_NEEDED` list of the selected artifact;
- exact linker namespace behavior on the target Android build;
- `JNI_CreateJavaVM` execution on ARM64 hardware;
- Java class execution inside the embedded VM;
- runtime stdout/stderr capture on device;
- JVM destruction after Java execution;
- JNI round-trip;
- LWJGL/Surface initialization;
- Minecraft 1.20.4 compatibility.

This is intentional. No PASS is claimed for any of those states.
