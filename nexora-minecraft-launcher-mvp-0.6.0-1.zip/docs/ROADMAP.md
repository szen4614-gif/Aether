# Roadmap

1. **Core MVP (current):** Android shell, storage, instances, local accounts, logging, diagnostics, security primitives.
2. **Minecraft bootstrap:** official version metadata, artifact manifests, SHA-1 validation, library resolution, Java runtime contracts, process lifecycle.
3. **Modding:** loader installers, mod metadata/dependency model, resource packs, shaders, modpacks.
4. **Content:** authorized APIs, search/cache, browser isolation, downloads.
5. **Mobile input:** touch overlay, editor, gamepad, keyboard/mouse bridge.
6. **Performance:** measured startup/RAM/I/O benchmarks and hardware profiles.
7. **Security:** stronger sandboxing, secure token storage, ZIP bomb limits, signed update verification.
8. **Stabilization:** device matrix, regression suite, crash analysis, release validation.

Every stage follows: specification → implementation → build → test → correction → validation → next module.

## 0.6

Disposable Android Java verification APK, runtime binary inspection, deterministic device gate, failure matrix, and four-level evidence ledger.
