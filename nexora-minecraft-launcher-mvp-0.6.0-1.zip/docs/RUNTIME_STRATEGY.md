# Runtime Strategy — 0.4

## Decision summary

NEXORA will not implement a JVM from scratch.

For Minecraft 1.20.4, the first candidate is an existing Android OpenJDK 17 ARM64 runtime built for the mobile OpenJDK lineage used by current Android Minecraft Java launchers. The candidate is selected for the POC, but it is not yet certified by NEXORA.

## Strategy comparison

| Strategy | Android compatibility | Size | Update | Security | ARM64 | JNI | LWJGL | Decision |
|---|---|---:|---|---|---|---|---|---|
| Runtime embedded entirely in APK | High for packaged native code; runtime-specific layout still matters | High | APK release | Strongest provenance if signed with app | Good | Good | Possible | Keep as supported distribution option |
| Runtime packaged as APK assets, extracted privately | Common for large data; does not make `bin/java` executable | Medium/high | Independent from APK | Requires hash/signature and safe extraction | Good | Possible | Possible | Useful packaging option |
| Downloaded JRE into private app storage + native `dlopen` | Android 10+ blocks direct exec from writable app home; `dlopen` behavior must be proven for the selected runtime/device | Lower initial APK | Excellent | Requires pinned digest, safe extraction and native validation | Good | Good if runtime is Android-built | Possible | **POC strategy** |
| Native libraries only in APK `lib/<abi>` | Strong Android support | Medium | APK-coupled | Strong | Excellent | Excellent | Good | Preferred for NEXORA-owned bridge/native helpers |
| Full JVM integrated into native layer | Technically possible but increases maintenance and fork burden | High | Difficult | Large attack/maintenance surface | Good | Good | Possible | Reject for now |
| Desktop Linux JRE | Not a supported Android runtime target | Varies | Poor | Unsafe/unknown compatibility | Sometimes | Unknown | Poor | Reject |

Android's native-library packaging model is explicitly ABI-based under `/lib/<abi>/`, with libraries copied to the app's `nativeLibraryDir`. Android also provides `System.loadLibrary` for app-native libraries.

## Candidate choice

`jre17-android-arm64.tar.xz` from the current Amethyst OpenJDK build distribution is the first external candidate.

Reasons:

1. Java 17 matches the selected Minecraft 1.20.4 target.
2. ARM64 Android is an explicit build target.
3. The project is actively publishing current ARM64 JRE artifacts.
4. The release publishes a SHA-256 digest.
5. Public launcher evidence demonstrates the expected Android JRE layout and native loading pattern.

This is a **candidate decision**, not a verification result.

## License decision

OpenJDK 17 upstream is GPL-2.0 with the Classpath Exception. LWJGL 3 is BSD-3-Clause. The exact license/notice set of the selected binary distribution must be archived before redistribution.

NEXORA will not copy Pojav/Amethyst source code. Public implementations are used only as interoperability evidence and architectural reference.
