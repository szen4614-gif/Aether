# ANDROID_JAVA_POC — 0.6

## Purpose

A separate, disposable verification APK answers one narrow question:

`Android APK → native bridge → Android OpenJDK 17 ARM64 → JNI_CreateJavaVM → FindClass → HelloWorld.main → Java/native 41→42 → DestroyJavaVM`

The verification app is intentionally separate from the production launcher and does not establish Minecraft compatibility.

## Evidence levels

- SOURCE: source is present and reviewed.
- BUILD: Android APK is actually built with the Android toolchain.
- EXECUTION: the APK and runtime execute on a real ARM64 Android device.
- FUNCTIONAL: the complete chain reports PASS with device log evidence.

Only FUNCTIONAL=PASS promotes `ANDROID_JAVA_POC` to PASS.

## Required UI/log evidence

The app reports runtime presence, ABI, Java major, deterministic runtime tree hash, `libjvm.so`, runtime loading, `JNI_CreateJavaVM`, `FindClass`, `main`, JNI 41→42, `DestroyJavaVM`, and final status.

stdout/stderr are retained by the existing Java probe, but functional proof is not dependent on stdout: explicit `NEXORA_VERIFY` Android log markers are the authoritative device evidence channel.

## Runtime placement for the verification APK

`tools/device-verify/run.sh` provisions an extracted runtime into the APK's private `files/verification-runtime` directory using `run-as` on a debug build.

The runtime archive is never treated as verified merely because a public hash is known. The actual bytes must be acquired and hashed locally.
