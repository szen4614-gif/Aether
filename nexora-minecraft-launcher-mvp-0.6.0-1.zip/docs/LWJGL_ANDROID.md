# LWJGL Android — 0.4

## Evidence

Upstream LWJGL 3 provides bindings for OpenGL, OpenGL ES, Vulkan, GLFW and other native APIs and is BSD-3-Clause licensed. It also has an Android example project.

Android Minecraft launchers publicly demonstrate that vanilla Minecraft requires an Android-specific graphics/input bridge rather than blindly using desktop GLFW/native artifacts.

## 1.20.4 target

Public launcher logs for Minecraft 1.20.4 show the LWJGL 3.3.2 family in the desktop dependency graph. NEXORA will obtain the exact 1.20.4 manifest from Mojang metadata and treat that manifest as authoritative for artifact versions.

The important point is that desktop `natives-linux` are not automatically Android ARM64 natives. The resolver now models native classifiers as first-class artifacts so this incompatibility can be detected instead of silently ignored.

## Graphics decision

No Vulkan-first assumption.

POC C will first establish:

```text
Android Surface
  -> EGL / required Android graphics bridge
  -> OpenGL ES capability
  -> LWJGL-compatible native entry points
  -> minimal render
```

If the exact Minecraft/LWJGL stack requires another backend, that becomes an explicit architecture decision after evidence.

## Do not copy existing launchers

Pojav/Amethyst have used multiple graphics stacks over time, including GLFW stubs and newer real-GLFW/native backends. Those are evidence that the compatibility layer is a real engineering problem, not a license to copy their implementation.

NEXORA will define its own `GraphicsBridge`, `SurfaceBridge` and native-loader interfaces.
