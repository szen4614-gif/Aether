# Architecture decisions

## ADR-001 — Existing Android OpenJDK, not a new JVM

**Decision:** integrate an existing Android OpenJDK/JVM build behind `RuntimeProvider`. The first candidate is Java 17 ARM64 from the current Amethyst OpenJDK build distribution.

**Constraint:** candidate selection is not runtime verification. The exact binary must pass integrity, ELF, native dependency, JVM initialization and Java execution gates.

## ADR-002 — JVM initialization is not Java execution

**Decision:** the project records `JVM_INITIALIZED` and `JAVA_EXECUTED` as separate evidence states. The 0.4 POC explicitly calls a Java `main()` and captures its streams before destroying the VM.

## ADR-003 — Android JVM backend, not ProcessBuilder

**Decision:** Android uses `AndroidJvmBackend` + `NativeJvmBridge`. Desktop execution remains a separate process backend.

**Why:** Android 10+ removed execute permission for files in the writable app home. Directly executing `filesDir/runtimes/.../bin/java` is therefore not the primary strategy.

## ADR-004 — Native runtime loading is runtime-specific

**Decision:** do not hard-code one JRE layout as universal. The loader searches known layouts and records helper-library/symbol results. The final runtime contract will be based on the selected artifact's actual ELF `DT_NEEDED`, export table and device linker behavior.

## ADR-005 — Runtime evidence states are independent

```text
DISCOVERED
INTEGRITY_VERIFIED
STRUCTURE_VERIFIED
NATIVE_LOADABLE
JVM_INITIALIZED
JAVA_EXECUTED
LWJGL_INITIALIZED
MINECRAFT_COMPATIBLE
```

A state only advances with evidence for that state.

## ADR-006 — POC order

```text
A: Java
↓
B: JNI/native
↓
C: LWJGL/Surface
↓
D: Minecraft 1.20.4
```

## ADR-007 — First Vanilla target

**Decision:** `TARGET_VERSION=1.20.4`.

**Why:** Java 17 reduces first-boot compatibility variables compared with immediately targeting newer Java 21/25 versions.

## ADR-008 — Native artifacts are first-class

Libraries now model JAR artifacts, native classifiers, OS, architecture, rules and extraction exclusions. A `linux` native artifact is not automatically treated as Android-compatible. ELF/ABI validation is required.

## ADR-009 — Graphics backend is evidence-driven

No Vulkan-first implementation. POC C will establish the exact graphics path required by the selected LWJGL/Minecraft stack and target device.

## ADR-010 — Do not copy Pojav/Amethyst

Public Pojav/Amethyst source and runtime projects are used as evidence of feasibility and compatibility constraints. NEXORA maintains its own interfaces, loader, lifecycle and documentation. External code is not copied without a component-level license decision.

## 0.5 — Evidence-first execution gate

### Problem
The previous native bridge could initialize a JVM, but repository presence was being too close to a functional interpretation.

### Alternatives
1. Continue expanding launcher abstractions before hardware execution.
2. Stop at desktop/native compilation.
3. Build a minimal Android Java/JNI gate and refuse PASS without device evidence.

### Evidence
JNI Invocation API defines `JNI_CreateJavaVM`, per-thread `JNIEnv`, `AttachCurrentThread`, `DetachCurrentThread`, and `DestroyJavaVM`. Android-native library loading has platform-specific constraints. Public Android Java launchers demonstrate that Android JREs and native libraries require dedicated runtime/native-loading handling.

### Decision
Use independent evidence gates:
`INTEGRITY_VERIFIED → STRUCTURE_VERIFIED → NATIVE_LOADABLE → JVM_INITIALIZED → JAVA_EXECUTED → LWJGL_INITIALIZED → MINECRAFT_COMPATIBLE`.

### Consequences
A working source implementation can remain `NOT VERIFIED`. Hardware evidence becomes a required artifact rather than an assumption.

### Risks
The embedded JVM may expose Android linker, namespace, filesystem, signal, thread, or lifecycle issues that cannot be reproduced in the current host environment.

## 0.6 — verification app is a separate executable gate

The Android Java verification experiment is isolated in `:android-java-verification`. This reduces the surface needed to answer the binary question "can this Android ARM64 OpenJDK execute Java through JNI?" without coupling the result to launcher UI or Minecraft preparation. The production launcher remains independently gated.
