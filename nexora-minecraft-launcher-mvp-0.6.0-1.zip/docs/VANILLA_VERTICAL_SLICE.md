# Vanilla Vertical Slice — 0.2 direction

## Objective

Prove the shortest real path from Mojang metadata to a prepared Vanilla Minecraft Java launch on Android ARM64. The project must not claim a launch until an ARM64 Android device has actually executed the process and produced evidence.

## Implemented in this cycle

- Version index/version manifest data models and parsers.
- Official Mojang metadata endpoint is fixed to `piston-meta.mojang.com`.
- Manifest SHA-1 validation.
- Library/client artifact resolution from manifest metadata.
- Generic integrity verifier where the manifest declares an algorithm.
- HTTPS download staging with partial-file recovery, size limits and host/redirect allowlisting.
- Java runtime inspection and required-major selection model.
- Classpath and JVM/game argument construction.
- Process/log/exit-code abstraction.
- Explicit launch-state/failure model.
- Offline account provider separated from future Microsoft provider.

## Not yet proven

- A complete Minecraft asset download/extraction run.
- Native library/classifier extraction and Android-compatible LWJGL bridge.
- Execution of a downloaded JRE on modern Android.
- Actual Minecraft process creation on Android ARM64.
- LWJGL/OpenGL ES/Vulkan rendering.
- Touch-to-Java input bridge.

## Acceptance gate

The Vanilla milestone remains **not complete** until all of these have evidence from a real ARM64 Android run:

- [ ] version index resolved
- [ ] version manifest resolved and hash checked
- [ ] libraries/assets/client downloaded and validated
- [ ] compatible Java runtime found and executed
- [ ] instance prepared
- [ ] classpath built
- [ ] JVM/game arguments built
- [ ] process started
- [ ] stdout/stderr captured
- [ ] process termination detected
- [ ] crash diagnosis generated
- [ ] Minecraft reaches a real Java game state

## Android execution decision

Android 10+ blocks direct execution of files from the writable app home directory. Therefore a generic `ProcessBuilder(runtime/bin/java)` implementation is not considered sufficient for the Android target. citeturn0search0

Existing Android Java-launcher research shows that a viable architecture requires a mobile OpenJDK/JVM plus native integration, and that ARM64 JREs and Java 8/17/21 variants have been used in real launchers. This is evidence of feasibility, not a guarantee for NEXORA. citeturn1search0turn4search0

The native execution/graphics bridge is therefore the next blocking implementation, rather than pretending that desktop-style process execution is already portable to Android.

## Graphics/input decision

Minecraft remains Java Edition. Touch is an input adapter. The Android-facing native layer should own lifecycle, SurfaceView/native window and input events, while the Java game continues to run through its JVM/LWJGL environment. Android recommends GameActivity for new C/C++ intensive applications and provides native lifecycle/input/window integration. citeturn0search2turn0search3

OpenGL ES remains relevant for compatibility; Vulkan is the preferred modern low-level Android graphics API, but neither is declared a Minecraft/LWJGL compatibility guarantee without device testing. citeturn0search9turn0search10
