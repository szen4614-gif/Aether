# Runtime Verification Report — 0.6

## Candidate

`jre17-android-arm64.tar.xz`

Expected acquisition SHA-256:
`e162c860fe05ee4a4e4af7606437419879f6c748386a7b09fa77d10db6a64091`

This digest is an acquisition target only. It is not evidence that the binary was acquired in this session.

## Evidence ledger

| Gate | State | Evidence required |
|---|---|---|
| RUNTIME_ACQUIRED | NOT VERIFIED | actual archive/directory present |
| RUNTIME_INTEGRITY_VERIFIED | NOT VERIFIED | SHA-256 computed from supplied archive |
| RUNTIME_STRUCTURE_VERIFIED | NOT VERIFIED | actual ELF/ABI/DT_NEEDED/SONAME/RPATH/RUNPATH inspection |
| RUNTIME_NATIVE_LOADABLE | NOT VERIFIED | actual Android linker `dlopen` success |
| JVM_INITIALIZED | NOT VERIFIED | actual `JNI_CreateJavaVM` result |
| JAVA_EXECUTED | NOT VERIFIED | actual `FindClass` + `main` result |
| JNI_EXECUTED | NOT VERIFIED | actual Java → Android ARM64 `.so` → 41 → 42 → Java |
| JVM_SHUTDOWN | NOT VERIFIED | actual `DestroyJavaVM == JNI_OK` |
| ANDROID_JAVA_POC | NOT VERIFIED | all previous functional gates PASS |

## Binary evidence to collect

The inspection tooling records from the actual supplied files:

- archive SHA-256;
- `libjvm.so` SHA-256;
- ELF class/machine/OS ABI/type;
- `DT_NEEDED`;
- SONAME;
- RPATH;
- RUNPATH;
- presence of every `DT_NEEDED` dependency in the runtime native set;
- `JNI_CreateJavaVM` exported symbol;
- complete native `.so` inventory.

It does not convert those checks into Android execution evidence.

## Android loading model

The POC uses:

- native OpenJDK `.so` files packaged in APK `lib/arm64-v8a/`;
- JRE non-native data provisioned to `files/verification-runtime` after installation;
- `ApplicationInfo.nativeLibraryDir` as the native library location;
- `dlopen` for `libjvm.so`;
- the Invocation API only after native loading succeeds.

Writable app-private storage is not used as the source of executable JRE `.so` files.

## Reproduction

```text
./tools/runtime-inspect/inspect.sh <runtime-home> <archive> docs/RUNTIME_VERIFICATION_REPORT.md
./tools/runtime-inspect/prepare-apk-runtime.sh <runtime-home>
./tools/device-verify/run.sh
```

If the runtime, Android SDK/NDK, ADB, or ARM64 device is unavailable, the final state remains `NOT VERIFIED`.
