# Vanilla 1.20.4 Boot Plan — 0.4

Milestone: `VANILLA_1_20_4_BOOT`

## Deterministic instance layout

```text
instance/
├── version.json
├── versions/1.20.4/1.20.4.jar
├── libraries/<maven-path>.jar
├── libraries/<maven-path>-native.jar
├── natives/<extracted .so>
├── assets/indexes/1.20.json
├── assets/objects/<prefix>/<hash>
├── logs/stdout.txt
├── logs/stderr.txt
└── runtime-ref.json
```

## Pipeline

```text
Mojang version manifest
        ↓
version resolution
        ↓
artifact graph
        ↓
JAR + native classifier resolution
        ↓
HTTPS download + declared hash
        ↓
native extraction/ABI validation
        ↓
asset index + object cache
        ↓
validated Java 17 Android runtime
        ↓
AndroidJvmBackend
        ↓
JVM
        ↓
LWJGL/native bridge
        ↓
Android Surface
        ↓
Minecraft 1.20.4
```

## PASS criteria

`VANILLA_1_20_4_BOOT = PASS` only after all links above are observed on a real ARM64 Android device.

A successful manifest parse, downloaded client JAR, or JVM source implementation does not advance this milestone.

## Current blocker chain

1. Android build environment is unavailable in the current workspace.
2. Selected JRE17 ARM64 artifact has not been acquired into the workspace for ELF/DT_NEEDED inspection.
3. No real ARM64 device execution evidence is available in this workspace.
4. LWJGL/Surface bridge is still a separate POC.
