# Android ARM64 Java POC — 0.3

## Decision

Do not implement a JVM from scratch. The first integration target is an existing mobile OpenJDK/JVM build compatible with Android ARM64. PojavLauncher/Amethyst provide public evidence that OpenJDK 8/17/21 ARM64 runtimes and custom native integration have been used for Minecraft Java on Android. This is evidence of feasibility, not a claim that NEXORA has verified it yet.

The archived `PojavLauncherTeam/android-openjdk-build-multiarch` project documents ARM64 Android OpenJDK builds. The PojavLauncher repository documents prebuilt JREs and a custom LWJGL build. These components have separate licenses and will not be copied into this repository without an explicit dependency/license decision.

## Android constraint

Android 10+ prevents direct `execve()` of binaries stored in the writable application home directory. Therefore the POC does **not** use `ProcessBuilder(filesDir/runtimes/.../bin/java)` as the JVM strategy. Native JVM loading is attempted through a JNI bridge using `dlopen()` of a validated `libjvm.so` path. The runtime artifact must be validated and its native dependency layout must be proven on-device.

## POC stages

1. APK installs and reports ABI/capabilities.
2. A validated ARM64 runtime descriptor is discovered under the app-managed runtime store.
3. Native bridge loads `lib/server/libjvm.so` and resolves `JNI_CreateJavaVM`.
4. JVM initialization is attempted.
5. Later stage: execute a minimal Java class through JNI.
6. Later stage: load a test `.so` through JNI and verify return value.
7. Later stage: attach Android Surface and prove graphics context creation.

## Current evidence level

- RuntimeProvider: IMPLEMENTED / UNIT_TESTED.
- Capability detection: IMPLEMENTED / UNIT_TESTED.
- Native bridge source: IMPLEMENTED / NOT BUILT in this environment.
- JVM startup: NOT VERIFIED_ON_ARM64.
- Java class execution: NOT IMPLEMENTED yet.
- JNI native library round-trip: NOT IMPLEMENTED yet.

The current environment has no Android SDK/NDK/Gradle installation suitable for an Android build, so no ARM64 APK verification is claimed.

## External evidence table

| Component | External evidence | NEXORA decision | License/compatibility note |
|---|---|---|---|
| Mobile OpenJDK ARM64 | PojavLauncher/Amethyst list OpenJDK 8/17/21 ARM64 | Integrate behind RuntimeProvider | Must audit exact runtime artifact/license before bundling |
| JVM loading | PojavLauncher source loads `libjli.so`, `libjvm.so` and other JVM libs | Use native bridge, not ProcessBuilder | Reimplement boundary; do not copy code |
| LWJGL | PojavLauncher documents custom LWJGL builds | Separate LWJGL provider later | LWJGL3 is BSD-3 according to its upstream attribution in Pojav docs |
| Graphics | Existing Android Java launchers use OpenGL-related native layers | First graphics POC should target the backend required by the chosen Minecraft/LWJGL stack | No Vulkan assumption |
| Android native loading | Android docs support `System.loadLibrary`; packaged native libraries live in the app native library directory | Keep launcher-owned JNI bridge in APK | Runtime-downloaded `.so` remains untrusted until validated |

## Target Minecraft version

`TARGET_VERSION = 1.20.4` for the first Vanilla boot attempt.

Reason: it is a stable release using Java 17-era runtime requirements and avoids immediately coupling the first proof to newer Java 21/native compatibility problems. This is an engineering target, not a claim that 1.20.4 is the newest supported release.
