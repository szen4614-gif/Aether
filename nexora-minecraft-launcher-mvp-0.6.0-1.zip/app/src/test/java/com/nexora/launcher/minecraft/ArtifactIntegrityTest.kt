package com.nexora.launcher.minecraft

import org.junit.Assert.*
import org.junit.Test
import java.io.File

class ArtifactIntegrityTest {
    @Test fun verifiesDeclaredAlgorithm() {
        val f = File.createTempFile("nexora", ".bin")
        f.writeText("hello")
        assertTrue(ArtifactIntegrity.verify(f, IntegritySpec("SHA-256", "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824")))
        assertFalse(ArtifactIntegrity.verify(f, IntegritySpec("SHA-256", "0000")))
        f.delete()
    }
}
