package com.nexora.launcher.runtime

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RuntimeProviderTest {
    @Test fun arm64DescriptorHasExpectedIdentity() {
        val d = RuntimeDescriptor("test", java.io.File("/runtime"), 17, "arm64-v8a", RuntimeSource.APP_MANAGED, true)
        assertEquals(17, d.major)
        assertEquals("arm64-v8a", d.abi)
        assertTrue(d.integrityVerified)
    }
}
