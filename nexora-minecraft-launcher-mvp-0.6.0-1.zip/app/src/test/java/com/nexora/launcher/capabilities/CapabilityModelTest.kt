package com.nexora.launcher.capabilities

import org.junit.Assert.assertTrue
import org.junit.Test

class CapabilityModelTest {
    @Test fun arm64IsDetectedFromAbiValue() {
        val c = DeviceCapabilities("arm64-v8a", 35, 1, 1, null, false, 8)
        assertTrue(c.isArm64)
    }
}
