package com.nexora.launcher

import com.nexora.launcher.security.PathPolicy
import org.junit.Test
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows

class PathPolicyTest {
    @Test fun blocksTraversal(){ assertThrows(IllegalArgumentException::class.java) { PathPolicy.safeChild(File("/tmp/root"),"../secret") } }
    @Test fun acceptsNormalPath(){ val f=PathPolicy.safeChild(File("/tmp/root"),"mods/test.jar"); assertEquals("test.jar",f.name) }
}
