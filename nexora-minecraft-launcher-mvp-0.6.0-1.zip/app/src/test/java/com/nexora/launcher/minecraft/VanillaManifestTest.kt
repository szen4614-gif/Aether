package com.nexora.launcher.minecraft

import org.junit.Assert.*
import org.junit.Test

class VanillaManifestTest {
    @Test fun parsesModernManifest() {
        val json = """{
          "id":"1.21.4","type":"release","mainClass":"net.minecraft.client.main.Main",
          "assets":"1.21","assetIndex":{"id":"1.21","url":"https://example/assets.json","sha1":"abc"},
          "javaVersion":{"majorVersion":21},
          "downloads":{"client":{"url":"https://example/client.jar","sha1":"def","size":12}},
          "arguments":{"jvm":["-Xmx2G"],"game":["--username","${'$'}{auth_player_name}"]},
          "libraries":[{"name":"org.example:test:1","downloads":{"artifact":{"path":"org/example/test/1/test.jar","url":"https://example/test.jar","sha1":"123","size":3}}}]
        }"""
        val m = VanillaManifestParser.parseVersion(json)
        assertEquals(21, m.javaMajor)
        assertEquals("net.minecraft.client.main.Main", m.mainClass)
        assertEquals(1, m.libraries.size)
        assertEquals("org/example/test/1/test.jar", m.libraries[0].path)
    }
}
