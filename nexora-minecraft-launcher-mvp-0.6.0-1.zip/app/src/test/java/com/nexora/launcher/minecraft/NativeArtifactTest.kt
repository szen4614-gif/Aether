package com.nexora.launcher.minecraft

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class NativeArtifactTest {
    @Test fun parsesAndResolvesNativeClassifier() {
        val json = """{
          "id":"1.20.4","type":"release","mainClass":"net.minecraft.client.main.Main",
          "javaVersion":{"majorVersion":17},"libraries":[{
            "name":"org.lwjgl:lwjgl:3.3.1",
            "natives":{"linux":"natives-linux-${'$'}{arch}"},
            "downloads":{"artifact":{"path":"org/lwjgl/lwjgl/3.3.1/lwjgl.jar","url":"https://libraries.minecraft.net/a.jar","sha1":"a"},
              "classifiers":{"natives-linux-64":{"path":"org/lwjgl/lwjgl/3.3.1/lwjgl-natives-linux-64.jar","url":"https://libraries.minecraft.net/n.jar","sha1":"b","size":4}}}
          }]}
        """
        val manifest = VanillaManifestParser.parseVersion(json)
        assertEquals("natives-linux-${'$'}{arch}", manifest.libraries.single().natives["linux"])
        val resolved = ArtifactResolver(File("/tmp/game")).resolve(manifest)
        assertTrue(resolved.any { it.kind == "native" && it.classifier == "natives-linux-64" })
    }
}
