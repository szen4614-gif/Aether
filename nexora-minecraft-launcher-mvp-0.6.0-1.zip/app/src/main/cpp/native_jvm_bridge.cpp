#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <mutex>

#define LOG_TAG "NEXORA_JVM"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using CreateJvmFn = jint (*)(JavaVM **, void **, void *);

static JavaVM *g_vm = nullptr;
static std::vector<void*> g_handles;
static std::mutex g_vmMutex;

static bool isFile(const std::string &path) {
    struct stat st{};
    return stat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode);
}

static void closeHandles() {
    for (auto it = g_handles.rbegin(); it != g_handles.rend(); ++it) {
        if (*it) dlclose(*it);
    }
    g_handles.clear();
}

static std::string jstringUtf(JNIEnv *env, jstring value) {
    if (!value) return {};
    const char *chars = env->GetStringUTFChars(value, nullptr);
    std::string result = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return result;
}

static bool checkAndLogException(JNIEnv *env, const char *where, bool printStack = true) {
    if (!env->ExceptionCheck()) return false;
    LOGE("Java exception at %s", where);
    if (printStack) env->ExceptionDescribe();
    return true;
}

static bool printAndClearThrowable(JNIEnv *env, const char *where) {
    if (!env->ExceptionCheck()) return false;
    LOGE("Java Throwable at %s", where);
    jthrowable throwable = env->ExceptionOccurred();
    env->ExceptionClear();
    if (throwable) {
        jclass throwableCls = env->GetObjectClass(throwable);
        jmethodID print = env->GetMethodID(throwableCls, "printStackTrace", "(Ljava/io/PrintStream;)V");
        jclass systemCls = env->FindClass("java/lang/System");
        jfieldID errField = systemCls ? env->GetStaticFieldID(systemCls, "err", "Ljava/io/PrintStream;") : nullptr;
        jobject err = (systemCls && errField) ? env->GetStaticObjectField(systemCls, errField) : nullptr;
        if (print && err) env->CallVoidMethod(throwable, print, err);
        env->ExceptionClear();
        if (err) env->DeleteLocalRef(err);
        if (systemCls) env->DeleteLocalRef(systemCls);
        if (throwableCls) env->DeleteLocalRef(throwableCls);
        env->DeleteLocalRef(throwable);
    }
    return true;
}

static bool setOutput(JNIEnv *env, const char *systemMethod, const std::string &path) {
    jclass fosCls = env->FindClass("java/io/FileOutputStream");
    if (!fosCls) return false;
    jmethodID fosCtor = env->GetMethodID(fosCls, "<init>", "(Ljava/lang/String;)V");
    if (!fosCtor) return false;
    jstring jPath = env->NewStringUTF(path.c_str());
    jobject fos = env->NewObject(fosCls, fosCtor, jPath);
    env->DeleteLocalRef(jPath);
    if (!fos || checkAndLogException(env, "FileOutputStream")) return false;

    jclass psCls = env->FindClass("java/io/PrintStream");
    if (!psCls) return false;
    jmethodID psCtor = env->GetMethodID(psCls, "<init>", "(Ljava/io/OutputStream;Z)V");
    if (!psCtor) return false;
    jobject ps = env->NewObject(psCls, psCtor, fos, JNI_TRUE);
    env->DeleteLocalRef(fos);
    if (!ps || checkAndLogException(env, "PrintStream")) return false;

    jclass systemCls = env->FindClass("java/lang/System");
    if (!systemCls) return false;
    jmethodID setter = env->GetStaticMethodID(systemCls, systemMethod, "(Ljava/io/PrintStream;)V");
    if (!setter) return false;
    env->CallStaticVoidMethod(systemCls, setter, ps);
    env->DeleteLocalRef(ps);
    return !env->ExceptionCheck();
}

static bool setOutputStreams(JNIEnv *env, const std::string &stdoutPath, const std::string &stderrPath) {
    return setOutput(env, "setOut", stdoutPath) && setOutput(env, "setErr", stderrPath);
}

static void flushOutputStreams(JNIEnv *env) {
    jclass systemCls = env->FindClass("java/lang/System");
    if (!systemCls) return;
    jfieldID outField = env->GetStaticFieldID(systemCls, "out", "Ljava/io/PrintStream;");
    jfieldID errField = env->GetStaticFieldID(systemCls, "err", "Ljava/io/PrintStream;");
    if (outField) {
        jobject out = env->GetStaticObjectField(systemCls, outField);
        if (out) {
            jclass psCls = env->GetObjectClass(out);
            jmethodID flush = env->GetMethodID(psCls, "flush", "()V");
            if (flush) env->CallVoidMethod(out, flush);
            env->DeleteLocalRef(psCls);
            env->DeleteLocalRef(out);
        }
    }
    if (errField) {
        jobject err = env->GetStaticObjectField(systemCls, errField);
        if (err) {
            jclass psCls = env->GetObjectClass(err);
            jmethodID flush = env->GetMethodID(psCls, "flush", "()V");
            if (flush) env->CallVoidMethod(err, flush);
            env->DeleteLocalRef(psCls);
            env->DeleteLocalRef(err);
        }
    }
    env->ExceptionClear();
    env->DeleteLocalRef(systemCls);
}

static std::vector<std::string> candidateJvmPaths(const std::string &home) {
    return {
        home + "/lib/server/libjvm.so",
        home + "/lib/aarch64/server/libjvm.so",
        home + "/lib/libjvm.so"
    };
}

static std::vector<std::string> helperLibraries(const std::string &home) {
    return {
        home + "/lib/jli/libjli.so",
        home + "/lib/libjli.so",
        home + "/lib/libverify.so",
        home + "/lib/libjava.so",
        home + "/lib/libnet.so",
        home + "/lib/libnio.so",
        home + "/lib/libjsig.so"
    };
}

static std::string findJvmPath(const std::string &home) {
    for (const auto &candidate : candidateJvmPaths(home)) {
        if (isFile(candidate)) return candidate;
    }
    return {};
}

static bool configureLibraryPath(const std::string &home) {
    const std::string libDir = home + "/lib";
    const std::string jliDir = home + "/lib/jli";
    const char *old = std::getenv("LD_LIBRARY_PATH");
    const std::string oldValue = old ? old : "";
    const std::string merged = jliDir + ":" + libDir + (oldValue.empty() ? "" : ":" + oldValue);
    return setenv("LD_LIBRARY_PATH", merged.c_str(), 1) == 0;
}

static int loadJvm(const std::string &home, std::vector<std::string> &lines, void **outJvmHandle) {
    const std::string jvmPath = findJvmPath(home);
    if (jvmPath.empty()) {
        lines.push_back("libjvm.so=FAIL:not found in known Android OpenJDK layouts");
        return -105;
    }
    lines.push_back("libjvm.so=PASS:" + jvmPath);
    configureLibraryPath(home);

    for (const auto &helper : helperLibraries(home)) {
        if (!isFile(helper)) continue;
        void *h = dlopen(helper.c_str(), RTLD_NOW | RTLD_GLOBAL);
        if (!h) {
            const char *error = dlerror();
            lines.push_back("native=" + helper + " FAIL:" + (error ? error : "unknown"));
            continue;
        }
        g_handles.push_back(h);
        lines.push_back("native=" + helper + " PASS");
    }

    void *jvm = dlopen(jvmPath.c_str(), RTLD_NOW | RTLD_GLOBAL);
    if (!jvm) {
        const char *error = dlerror();
        lines.push_back(std::string("libjvm.so=FAIL:dlopen:") + (error ? error : "unknown"));
        return -106;
    }
    g_handles.push_back(jvm);
    *outJvmHandle = jvm;
    return 0;
}

static int nativeValidate(const std::string &home, const std::string &expectedAbi, std::vector<std::string> &lines) {
    lines.push_back("abi=" + expectedAbi);
    std::lock_guard<std::mutex> lock(g_vmMutex);
    if (g_vm) {
        lines.push_back("runtime=FAIL:JVM already active");
        return -100;
    }
    void *jvm = nullptr;
    int rc = loadJvm(home, lines, &jvm);
    if (rc != 0) { closeHandles(); return rc; }
    auto create = reinterpret_cast<CreateJvmFn>(dlsym(jvm, "JNI_CreateJavaVM"));
    if (!create) {
        lines.push_back("JNI_CreateJavaVM=FAIL:not exported");
        closeHandles();
        return -107;
    }
    lines.push_back("JNI_CreateJavaVM=PASS");
    closeHandles();
    return 0;
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_com_nexora_launcher_nativebridge_NativeJvmBridge_validateNativeRuntime(JNIEnv *env, jclass, jstring home, jstring expectedAbi) {
    std::vector<std::string> lines;
    const int rc = nativeValidate(jstringUtf(env, home), jstringUtf(env, expectedAbi), lines);
    lines.push_back("result=" + std::to_string(rc));
    jclass stringCls = env->FindClass("java/lang/String");
    jobjectArray result = env->NewObjectArray(static_cast<jsize>(lines.size()), stringCls, nullptr);
    for (jsize i = 0; i < static_cast<jsize>(lines.size()); ++i) {
        jstring s = env->NewStringUTF(lines[i].c_str());
        env->SetObjectArrayElement(result, i, s);
        env->DeleteLocalRef(s);
    }
    return result;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_nexora_launcher_nativebridge_NativeJvmBridge_runMain(
        JNIEnv *env,
        jclass,
        jobject descriptor,
        jstring classpath,
        jstring mainClass,
        jobjectArray jvmOptions,
        jobjectArray args,
        jstring stdoutPath,
        jstring stderrPath,
        jstring nativeLibraryPath) {
    std::lock_guard<std::mutex> lock(g_vmMutex);
    if (g_vm) {
        LOGE("runMain called while a JVM is already active");
        return -100;
    }

    if (!descriptor) return -101;
    jclass descriptorCls = env->GetObjectClass(descriptor);
    jmethodID homeGetter = env->GetMethodID(descriptorCls, "getHome", "()Ljava/io/File;");
    if (!homeGetter) return -102;
    jobject home = env->CallObjectMethod(descriptor, homeGetter);
    if (checkAndLogException(env, "RuntimeDescriptor.getHome")) return -103;
    if (!home) return -104;

    jclass fileCls = env->GetObjectClass(home);
    jmethodID absoluteGetter = env->GetMethodID(fileCls, "getAbsolutePath", "()Ljava/lang/String;");
    if (!absoluteGetter) return -105;
    jstring homePath = (jstring) env->CallObjectMethod(home, absoluteGetter);
    if (checkAndLogException(env, "File.getAbsolutePath")) return -106;
    const std::string homePathStr = jstringUtf(env, homePath);

    void *jvmHandle = nullptr;
    std::vector<std::string> loadDiagnostics;
    const int loadRc = loadJvm(homePathStr, loadDiagnostics, &jvmHandle);
    for (const auto &line : loadDiagnostics) LOGI("%s", line.c_str());
    if (loadRc != 0 || !jvmHandle) {
        closeHandles();
        return loadRc != 0 ? loadRc : -107;
    }

    auto create = reinterpret_cast<CreateJvmFn>(dlsym(jvmHandle, "JNI_CreateJavaVM"));
    if (!create) {
        closeHandles();
        return -108;
    }

    std::vector<std::string> optionStorage;
    optionStorage.push_back("-Djava.home=" + homePathStr);
    optionStorage.push_back("-Djava.class.path=" + jstringUtf(env, classpath));
    if (nativeLibraryPath) optionStorage.push_back("-Djava.library.path=" + jstringUtf(env, nativeLibraryPath));
    if (nativeLibraryPath) optionStorage.push_back("-Dnexora.poc.native.path=" + jstringUtf(env, nativeLibraryPath) + "/libnexora_poc_native.so");
    optionStorage.push_back("-Djava.io.tmpdir=" + homePathStr + "/tmp");
    optionStorage.push_back("-Djava.awt.headless=true");
    if (jvmOptions) {
        const jsize optionCount = env->GetArrayLength(jvmOptions);
        for (jsize i = 0; i < optionCount; ++i) {
            auto option = (jstring) env->GetObjectArrayElement(jvmOptions, i);
            if (option) {
                optionStorage.push_back(jstringUtf(env, option));
                env->DeleteLocalRef(option);
            }
        }
    }

    std::vector<JavaVMOption> options(optionStorage.size());
    for (size_t i = 0; i < options.size(); ++i) options[i].optionString = optionStorage[i].data();
    JavaVMInitArgs vmArgs{};
    vmArgs.version = JNI_VERSION_1_8;
    vmArgs.nOptions = static_cast<jint>(options.size());
    vmArgs.options = options.data();
    vmArgs.ignoreUnrecognized = JNI_FALSE;

    JNIEnv *jvmEnv = nullptr;
    JavaVM *createdVm = nullptr;
    const jint createRc = create(&createdVm, reinterpret_cast<void **>(&jvmEnv), &vmArgs);
    if (createRc != JNI_OK || !createdVm || !jvmEnv) {
        LOGE("JNI_CreateJavaVM failed: %d", createRc);
        g_vm = nullptr;
        closeHandles();
        return createRc != 0 ? createRc : -109;
    }
    g_vm = createdVm;
    LOGI("JVM initialized; Java execution gate now begins");

    int result = 0;
    do {
        if (!setOutputStreams(jvmEnv, jstringUtf(env, stdoutPath), jstringUtf(env, stderrPath))) {
            checkAndLogException(jvmEnv, "redirect stdout/stderr");
            result = -110;
            break;
        }

        const std::string binaryName = jstringUtf(env, mainClass);
        std::string slashName = binaryName;
        for (char &c : slashName) if (c == '.') c = '/';
        jclass mainCls = jvmEnv->FindClass(slashName.c_str());
        if (printAndClearThrowable(jvmEnv, "FindClass(main)")) { result = -111; break; }
        if (!mainCls) { result = -112; break; }

        jmethodID mainMethod = jvmEnv->GetStaticMethodID(mainCls, "main", "([Ljava/lang/String;)V");
        if (printAndClearThrowable(jvmEnv, "GetStaticMethodID(main)")) { result = -113; break; }
        if (!mainMethod) { result = -114; break; }

        const jsize argc = args ? jvmEnv->GetArrayLength(args) : 0;
        jclass stringCls = jvmEnv->FindClass("java/lang/String");
        if (printAndClearThrowable(jvmEnv, "FindClass(String)")) { result = -115; break; }
        jobjectArray javaArgs = jvmEnv->NewObjectArray(argc, stringCls, nullptr);
        if (!javaArgs || printAndClearThrowable(jvmEnv, "NewObjectArray(args)")) { result = -116; break; }
        for (jsize i = 0; i < argc; ++i) {
            auto arg = (jstring) jvmEnv->GetObjectArrayElement(args, i);
            if (arg) {
                jvmEnv->SetObjectArrayElement(javaArgs, i, arg);
                jvmEnv->DeleteLocalRef(arg);
            }
        }
        if (printAndClearThrowable(jvmEnv, "SetObjectArrayElement(args)")) { result = -117; break; }

        jvmEnv->CallStaticVoidMethod(mainCls, mainMethod, javaArgs);
        if (printAndClearThrowable(jvmEnv, "CallStaticVoidMethod(main)")) {
            result = -118;
            break;
        }
        LOGI("Java main executed successfully");
    } while (false);

    flushOutputStreams(jvmEnv);
    const jint destroyRc = g_vm->DestroyJavaVM();
    LOGI("DestroyJavaVM returned %d", destroyRc);
    g_vm = nullptr;
    closeHandles();
    return result == 0 && destroyRc == JNI_OK ? 0 : (result != 0 ? result : destroyRc);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_nexora_launcher_nativebridge_NativeJvmBridge_isJvmActive(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_vmMutex);
    return g_vm != nullptr ? JNI_TRUE : JNI_FALSE;
}
