#include <jni.h>
#include <android/log.h>
#include <pthread.h>

#define LOG_TAG "NEXORA_POC"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jint JNICALL
Java_com_nexora_poc_HelloWorld_nativeRoundTrip(JNIEnv*, jclass, jint value) {
    LOGI("JNI round-trip received %d", value);
    return value + 1;
}
