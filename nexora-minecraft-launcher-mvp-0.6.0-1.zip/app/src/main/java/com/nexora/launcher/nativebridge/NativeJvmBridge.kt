package com.nexora.launcher.nativebridge

import com.nexora.launcher.runtime.RuntimeDescriptor

/**
 * JNI Invocation boundary. This is NOT a JVM implementation.
 * A successful JNI_CreateJavaVM call is only JVM_INITIALIZED; it is not JAVA_EXECUTED.
 */
object NativeJvmBridge {
    init { System.loadLibrary("nexora_jvm_bridge") }

    external fun validateNativeRuntime(home: String, expectedAbi: String): Array<String>

    external fun runMain(
        descriptor: RuntimeDescriptor,
        classpath: String,
        mainClass: String,
        jvmOptions: Array<String>,
        args: Array<String>,
        stdoutPath: String,
        stderrPath: String,
        nativeLibraryPath: String?
    ): Int

    external fun isJvmActive(): Boolean
}
