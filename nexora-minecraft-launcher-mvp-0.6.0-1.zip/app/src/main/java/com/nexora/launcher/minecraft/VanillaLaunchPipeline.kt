package com.nexora.launcher.minecraft

import com.nexora.launcher.accounts.AccountProvider
import com.nexora.launcher.process.MinecraftProcessManager
import com.nexora.launcher.runtime.JavaRuntimeManager
import java.io.File

class VanillaLaunchPipeline(
    private val javaManager: JavaRuntimeManager,
    private val accountProvider: AccountProvider,
    private val processManager: MinecraftProcessManager
) {
    data class PreparedLaunch(val plan: MinecraftProcessManager.LaunchPlan, val missing: List<String>)

    fun prepare(gameRoot: File, manifest: VersionManifest, artifacts: List<ArtifactResolver.ResolvedArtifact>, memoryMb: Int): PreparedLaunch {
        val missing = artifacts.filterNot { it.target.isFile }.map { "missing artifact: ${it.target}" }.toMutableList()
        val java = manifest.javaMajor?.let { javaManager.select(it) }
        if (java == null) missing += "compatible ARM64 Java runtime missing for major ${manifest.javaMajor ?: "unknown"}"
        val account = accountProvider.current()
        if (account == null) missing += "offline/local profile missing"
        val classpath = ClasspathBuilder().build(gameRoot, artifacts)
        if (classpath.isBlank()) missing += "classpath is empty"
        if (missing.isNotEmpty() || java == null || account == null) return PreparedLaunch(
            MinecraftProcessManager.LaunchPlan(File("/nonexistent"), emptyList(), emptyMap(), gameRoot), missing
        )
        val args = LaunchArguments()
        val jvm = args.jvmArgs(manifest, java.home.absolutePath, gameRoot.absolutePath, classpath, manifest.mainClass, memoryMb)
        val game = args.gameArgs(manifest, account.name, account.uuid, gameRoot.absolutePath, File(gameRoot, "assets").absolutePath, manifest.assetsId)
        return PreparedLaunch(MinecraftProcessManager.LaunchPlan(java.executable!!, jvm + game, mapOf("JAVA_HOME" to java.home.absolutePath), gameRoot), emptyList())
    }
}
