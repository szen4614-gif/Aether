package com.nexora.launcher.runtime

import android.content.Context
import java.io.File

class AndroidArm64RuntimeProvider(private val context: Context) : RuntimeProvider {
    override fun findCompatible(requiredMajor: Int, abi: String): RuntimeDescriptor? {
        if (abi != "arm64-v8a") return null
        val root = File(context.filesDir, "launcher/runtimes")
        if (!root.isDirectory) return null
        return root.listFiles()?.asSequence()
            ?.mapNotNull { candidate -> readDescriptor(candidate) }
            ?.filter { it.major == requiredMajor && it.abi == abi && it.integrityVerified }
            ?.sortedBy { it.id }
            ?.firstOrNull()
    }

    private fun readDescriptor(dir: File): RuntimeDescriptor? {
        val metadata = File(dir, "runtime.properties")
        if (!metadata.isFile) return null
        val values = runCatching { metadata.readLines().associate { line ->
            val i = line.indexOf('=')
            if (i <= 0) "" to "" else line.substring(0, i) to line.substring(i + 1)
        } }.getOrNull() ?: return null
        val major = values["java.major"]?.toIntOrNull() ?: return null
        val abi = values["abi"] ?: return null
        val verified = values["integrity.verified"] == "true"
        val algorithm = values["integrity.algorithm"]?.takeIf { it.isNotBlank() }
        val digest = values["integrity.digest"]?.takeIf { it.isNotBlank() }
        val source = values["source"]?.let { runCatching { RuntimeSource.valueOf(it) }.getOrNull() } ?: RuntimeSource.APP_MANAGED
        return RuntimeDescriptor(dir.name, dir, major, abi, source, verified, algorithm, digest)
    }
}
