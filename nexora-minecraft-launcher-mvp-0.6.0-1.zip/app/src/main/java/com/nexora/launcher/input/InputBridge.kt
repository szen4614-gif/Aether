package com.nexora.launcher.input

interface InputBridge {
    fun onKey(keyCode: Int, down: Boolean): Boolean
    fun onTouch(pointerId: Int, action: Int, x: Float, y: Float): Boolean
}
