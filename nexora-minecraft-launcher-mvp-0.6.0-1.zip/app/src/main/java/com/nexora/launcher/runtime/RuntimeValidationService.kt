package com.nexora.launcher.runtime

import com.nexora.launcher.nativebridge.NativeJvmBridge
import java.io.File

class RuntimeValidationService {
    fun validate(descriptor: RuntimeDescriptor, expectedAbi: String, requiredMajor: Int): RuntimeValidationReport {
        val base = RuntimeValidator().validateStructure(descriptor, expectedAbi, requiredMajor)
        val checks = base.checks.toMutableList()
        val jvm = File(descriptor.home, "lib/server/libjvm.so")
        checks += ValidationCheck(
            "ELF ABI",
            if (jvm.isFile && expectedAbi == "arm64-v8a" && ElfAbi.isArm64(jvm)) ValidationStatus.PASS else if (!jvm.isFile) ValidationStatus.NOT_TESTED else ValidationStatus.FAIL,
            if (!jvm.isFile) "libjvm.so unavailable" else if (ElfAbi.isArm64(jvm)) "AArch64 ELF" else "ELF is not AArch64"
        )

        val nativeChecks = runCatching { NativeJvmBridge.validateNativeRuntime(descriptor.home.absolutePath, expectedAbi).toList() }.getOrElse {
            listOf("native-validation=NOT_TESTED:${it.javaClass.simpleName}:${it.message}")
        }
        val nativeFail = nativeChecks.any { it.contains("FAIL") }
        checks += ValidationCheck("Native dependency resolution", when {
            nativeChecks.any { it.startsWith("JNI_CreateJavaVM=PASS") } && !nativeFail -> ValidationStatus.PASS
            nativeFail -> ValidationStatus.FAIL
            else -> ValidationStatus.NOT_TESTED
        }, nativeChecks.joinToString("; "))

        val highest = when {
            checks.any { it.status == ValidationStatus.FAIL } -> base.highestState
            nativeChecks.any { it.startsWith("JNI_CreateJavaVM=PASS") } -> RuntimeEvidenceState.NATIVE_LOADABLE
            else -> base.highestState
        }
        return RuntimeValidationReport(descriptor.id, checks, highest)
    }
}
