package com.nexora.launcher.versions

import android.content.Context
import com.nexora.launcher.android.StorageManager
import org.json.JSONArray
import java.io.File

class VersionManager(context: Context) {
    private val root=File(StorageManager(context).root,"versions").apply{mkdirs()}
    data class InstalledVersion(val id:String,val complete:Boolean,val directory:String)
    fun listInstalled():List<InstalledVersion> = root.listFiles()?.filter{it.isDirectory}?.map{d->InstalledVersion(d.name, File(d,"version.json").exists(), d.absolutePath)} ?: emptyList()
    fun validateDirectory(dir: File): Boolean = File(dir,"version.json").isFile
}
