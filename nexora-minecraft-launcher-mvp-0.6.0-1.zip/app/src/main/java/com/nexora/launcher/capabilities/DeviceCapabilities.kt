package com.nexora.launcher.capabilities

import android.app.ActivityManager
import android.content.Context
import android.os.Build

data class DeviceCapabilities(
    val abi: String,
    val apiLevel: Int,
    val totalRamBytes: Long,
    val availableStorageBytes: Long,
    val openGlEsVersion: String?,
    val vulkanFeaturePresent: Boolean,
    val cpuCount: Int
) {
    val isArm64: Boolean get() = abi == "arm64-v8a"
}

object CapabilityDetector {
    fun detect(context: Context): DeviceCapabilities {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also(am::getMemoryInfo)
        val storage = context.filesDir.usableSpace
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val glVersion = am.deviceConfigurationInfo?.reqGlEsVersion?.let { encoded ->
            val major = (encoded shr 16) and 0xffff
            val minor = encoded and 0xffff
            if (major == 0) null else "$major.$minor"
        }
        val vk = if (Build.VERSION.SDK_INT >= 24) {
            context.packageManager.hasSystemFeature("android.hardware.vulkan.level") ||
                context.packageManager.hasSystemFeature("android.hardware.vulkan.version")
        } else false
        return DeviceCapabilities(abi, Build.VERSION.SDK_INT, mem.totalMem, storage, glVersion, vk, Runtime.getRuntime().availableProcessors())
    }
}
