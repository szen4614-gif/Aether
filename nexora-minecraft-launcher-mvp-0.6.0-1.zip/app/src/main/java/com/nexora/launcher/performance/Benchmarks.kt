package com.nexora.launcher.performance

import android.os.SystemClock

class Benchmarks {
    fun measure(label:String, block:()->Unit):Long { val start=SystemClock.elapsedRealtimeNanos();block();return (SystemClock.elapsedRealtimeNanos()-start)/1_000_000 }
}
