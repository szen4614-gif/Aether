package com.nexora.launcher.minecraft

import java.io.File

class ClasspathBuilder {
    fun build(gameRoot: File, artifacts: List<ArtifactResolver.ResolvedArtifact>): String = artifacts
        .filter { it.kind == "library" || it.kind == "client" }
        .filter { it.target.isFile }
        .map { it.target.absolutePath }
        .joinToString(File.pathSeparator)
}
