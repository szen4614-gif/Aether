package com.nexora.launcher.poc

import com.nexora.launcher.nativebridge.NativeJvmBridge
import com.nexora.launcher.runtime.RuntimeDescriptor
import java.io.File

data class JavaPocResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val jvmDestroyed: Boolean
)

object AndroidJavaPoc {
    fun run(descriptor: RuntimeDescriptor, probeJar: File, workDir: File, nativeLibraryDir: String?): JavaPocResult {
        require(probeJar.isFile) { "POC probe JAR missing: $probeJar" }
        workDir.mkdirs()
        val stdout = File(workDir, "stdout.txt")
        val stderr = File(workDir, "stderr.txt")
        stdout.delete(); stderr.delete()
        val rc = NativeJvmBridge.runMain(
            descriptor = descriptor,
            classpath = probeJar.absolutePath,
            mainClass = "com.nexora.poc.HelloWorld",
            jvmOptions = emptyArray(),
            args = arrayOf("NEXORA_ANDROID_JAVA_POC"),
            stdoutPath = stdout.absolutePath,
            stderrPath = stderr.absolutePath,
            nativeLibraryPath = nativeLibraryDir
        )
        return JavaPocResult(rc, stdout.readTextOrEmpty(), stderr.readTextOrEmpty(), true)
    }

    private fun File.readTextOrEmpty(): String = if (isFile) readText() else ""
}
