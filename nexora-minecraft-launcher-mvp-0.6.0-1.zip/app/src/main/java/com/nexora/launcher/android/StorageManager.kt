package com.nexora.launcher.android

import android.content.Context
import java.io.File

class StorageManager(context: Context) {
    val root: File = File(context.filesDir, "launcher").apply { mkdirs() }
    val instances = File(root, "instances").apply { mkdirs() }
    val cache = File(root, "cache").apply { mkdirs() }
    val downloads = File(root, "downloads").apply { mkdirs() }
    val accounts = File(root, "accounts").apply { mkdirs() }
    val runtimes = File(root, "runtimes").apply { mkdirs() }

    fun instanceDir(id: String): File {
        require(Regex("[A-Za-z0-9._-]{1,80}").matches(id)) { "Invalid instance id" }
        return File(instances, id).apply { mkdirs() }
    }
}
