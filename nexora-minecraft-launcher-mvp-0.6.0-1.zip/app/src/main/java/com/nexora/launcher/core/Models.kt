package com.nexora.launcher.core

data class LauncherInstance(
    val id: String,
    val name: String,
    val minecraftVersion: String? = null,
    val loader: String? = null,
    val javaRuntimeId: String? = null,
    val memoryMb: Int = 1024,
    val directory: String
)

data class OfflineAccount(val id: String, val name: String, val uuid: String)

data class HardwareProfile(val tier: String, val abi: String, val ramMb: Long, val cores: Int, val androidApi: Int)
