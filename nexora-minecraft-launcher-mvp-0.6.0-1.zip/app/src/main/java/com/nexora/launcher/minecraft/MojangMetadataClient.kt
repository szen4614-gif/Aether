package com.nexora.launcher.minecraft

import java.net.HttpURLConnection
import java.net.URI

class MojangMetadataClient {
    companion object { const val VERSION_INDEX = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json" }

    fun fetchVersionIndex(): VersionIndex {
        val text = get(VERSION_INDEX)
        return VanillaManifestParser.parseIndex(text)
    }

    fun fetchVersion(ref: VersionRef): VersionManifest {
        val text = get(ref.url)
        if (ref.sha1 != null) {
            val actual = java.security.MessageDigest.getInstance("SHA-1").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }
            require(actual.equals(ref.sha1, true)) { "Version manifest SHA-1 mismatch for ${ref.id}" }
        }
        return VanillaManifestParser.parseVersion(text)
    }

    private fun get(url: String): String {
        val uri = URI(url)
        require(uri.scheme == "https")
        require(uri.host == "piston-meta.mojang.com")
        val c = uri.toURL().openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.connect()
        require(c.responseCode == 200) { "HTTP ${c.responseCode}" }
        return c.inputStream.bufferedReader().use { it.readText() }
    }
}
