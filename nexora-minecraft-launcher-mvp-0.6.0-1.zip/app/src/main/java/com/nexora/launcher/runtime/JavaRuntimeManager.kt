package com.nexora.launcher.runtime

import android.content.Context
import com.nexora.launcher.android.StorageManager
import java.io.File
import java.util.concurrent.TimeUnit

class JavaRuntimeManager(context: Context) {
    private val root = StorageManager(context).runtimes
    data class RuntimeInfo(val id: String, val home: File, val executable: File?, val major: Int?, val arch: String, val usable: Boolean, val reason: String? = null)

    fun detect(): List<RuntimeInfo> = root.listFiles()?.filter(File::isDirectory)?.map { dir -> inspect(dir) } ?: emptyList()

    fun select(requiredMajor: Int, preferredArch: String = "arm64-v8a"): RuntimeInfo? = detect()
        .filter { it.usable && it.major == requiredMajor && it.arch == preferredArch }
        .firstOrNull()

    private fun inspect(dir: File): RuntimeInfo {
        val executable = listOf(File(dir, "bin/java"), File(dir, "bin/java.exe")).firstOrNull { it.isFile }
        if (executable == null) return RuntimeInfo(dir.name, dir, null, null, detectArch(), false, "java executable not found")
        val version = runVersion(executable)
        val major = version?.let(::parseMajor)
        return RuntimeInfo(dir.name, dir, executable, major, detectArch(), major != null, if (major == null) "unable to execute java -version" else null)
    }

    private fun runVersion(java: File): String? = runCatching {
        val p = ProcessBuilder(java.absolutePath, "-version").redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().use { it.readText() }
        p.waitFor(5, TimeUnit.SECONDS)
        text
    }.getOrNull()

    private fun parseMajor(text: String): Int? {
        val match = Regex("version \"(\\d+)(?:\\.(\\d+))?").find(text) ?: return null
        val first = match.groupValues[1].toIntOrNull() ?: return null
        return if (first == 1) match.groupValues.getOrNull(2)?.toIntOrNull() else first
    }

    private fun detectArch(): String = System.getProperty("os.arch") ?: "unknown"
}
