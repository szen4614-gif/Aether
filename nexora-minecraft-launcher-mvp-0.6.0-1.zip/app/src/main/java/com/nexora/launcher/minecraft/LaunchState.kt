package com.nexora.launcher.minecraft

enum class LaunchState { IDLE, RESOLVING, DOWNLOADING, VERIFYING, PREPARING, READY, STARTING, RUNNING, EXITED, FAILED }

data class LaunchFailure(val state: LaunchState, val message: String, val missingDependencies: List<String> = emptyList())
