package com.nexora.launcher.minecraft

import org.json.JSONObject
import java.io.File

class AssetResolver {
    data class AssetObject(val name: String, val hash: String, val size: Long) {
        val prefix: String get() = hash.take(2)
        val url: String get() = "https://resources.download.minecraft.net/$prefix/$hash"
    }

    fun parseIndex(text: String): List<AssetObject> {
        val root = JSONObject(text).getJSONObject("objects")
        return root.keys().asSequence().map { name ->
            val o = root.getJSONObject(name)
            AssetObject(name, o.getString("hash"), o.getLong("size"))
        }.toList()
    }

    fun target(root: File, objectHash: String): File = File(root, "objects/${objectHash.take(2)}/$objectHash")
}
