package com.nexora.launcher.diagnostics

import android.content.Context
import android.os.Build
import android.os.Environment
import com.nexora.launcher.core.HardwareProfile

class Diagnostics(private val context: Context) {
    fun hardware(): HardwareProfile {
        val ram=(context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).memoryInfo.totalMem/1048576L
        val tier=when{ram<2500->"Entry";ram<5000->"Low";ram<8000->"Mid";ram<12000->"High";else->"Flagship"}
        return HardwareProfile(tier,Build.SUPPORTED_ABIS.firstOrNull()?:("unknown"),ram,Runtime.getRuntime().availableProcessors(),Build.VERSION.SDK_INT)
    }
    fun report():String { val h=hardware(); return "Device=${Build.MANUFACTURER} ${Build.MODEL}\nAndroid=${Build.VERSION.RELEASE} API=${h.androidApi}\nABI=${h.abi}\nRAM=${h.ramMb}MB\nCores=${h.cores}\nProfile=${h.tier}\nStorageFree=${Environment.getDataDirectory().freeSpace/1048576}MB" }
}
