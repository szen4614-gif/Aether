package com.nexora.launcher.minecraft

class LaunchArguments {
    fun jvmArgs(manifest: VersionManifest, javaHome: String, gameDir: String, classpath: String, mainClass: String, memoryMb: Int): List<String> = buildList {
        add("-Xms256M"); add("-Xmx${memoryMb}M")
        add("-Djava.library.path=$gameDir/natives")
        add("-Djava.home=$javaHome")
        add("-cp"); add(classpath)
        addAll(manifest.jvmArguments)
        add(mainClass)
    }

    fun gameArgs(manifest: VersionManifest, playerName: String, uuid: String, gameDir: String, assetsDir: String, assetsId: String?): List<String> {
        val vars = mapOf(
            "${'$'}{auth_player_name}" to playerName,
            "${'$'}{auth_uuid}" to uuid,
            "${'$'}{auth_accessToken}" to "0",
            "${'$'}{user_type}" to "legacy",
            "${'$'}{version_name}" to manifest.id,
            "${'$'}{game_directory}" to gameDir,
            "${'$'}{assets_root}" to assetsDir,
            "${'$'}{assets_index_name}" to (assetsId ?: "")
        )
        return manifest.gameArguments.map { arg -> vars.entries.fold(arg) { acc, e -> acc.replace(e.key, e.value) } }
    }
}
