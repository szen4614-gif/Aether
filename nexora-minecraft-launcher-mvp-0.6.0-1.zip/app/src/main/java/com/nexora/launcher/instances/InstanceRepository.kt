package com.nexora.launcher.instances

import android.content.Context
import com.nexora.launcher.android.StorageManager
import com.nexora.launcher.core.LauncherInstance
import org.json.JSONObject
import java.io.File

class InstanceRepository(context: Context) {
    private val storage = StorageManager(context)
    private val index = File(storage.root, "instances.json")

    fun list(): List<LauncherInstance> = if (!index.exists()) emptyList() else try {
        val array = org.json.JSONArray(index.readText())
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            LauncherInstance(o.getString("id"), o.getString("name"), o.optString("minecraftVersion").ifBlank { null }, o.optString("loader").ifBlank { null }, o.optString("javaRuntimeId").ifBlank { null }, o.optInt("memoryMb", 1024), o.getString("directory"))
        }
    } catch (_: Exception) { emptyList() }

    fun create(name: String): LauncherInstance {
        val id = name.trim().lowercase().replace(Regex("[^a-z0-9._-]+"), "-").trim('-').ifBlank { "instance" }
        val unique = generateSequence(id) { "$id-${it.hashCode().toUInt()}" }.first { candidate -> list().none { it.id == candidate } }
        val dir = storage.instanceDir(unique)
        val instance = LauncherInstance(unique, name.trim().ifBlank { "New Instance" }, directory = dir.absolutePath)
        save(list() + instance)
        return instance
    }

    private fun save(items: List<LauncherInstance>) {
        val array = org.json.JSONArray()
        items.forEach { i -> array.put(JSONObject().apply { put("id", i.id); put("name", i.name); put("minecraftVersion", i.minecraftVersion ?: ""); put("loader", i.loader ?: ""); put("javaRuntimeId", i.javaRuntimeId ?: ""); put("memoryMb", i.memoryMb); put("directory", i.directory) }) }
        index.writeText(array.toString(2))
    }
}
