package com.nexora.launcher.graphics

import android.view.Surface

interface GraphicsBridge {
    fun attach(surface: Surface): Boolean
    fun detach()
}
