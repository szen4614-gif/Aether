package com.nexora.launcher.security

import java.io.File

object PathPolicy {
    fun safeChild(root:File, relative:String):File { require(!relative.contains("\u0000")); val candidate=File(root,relative).canonicalFile; require(candidate.path==root.canonicalPath || candidate.path.startsWith(root.canonicalPath+File.separator)){"Path traversal blocked"};return candidate }
    fun validateZipEntry(name:String):Boolean = !name.startsWith("/") && !name.contains("\\") && name.split('/').none{it==".."}
}
