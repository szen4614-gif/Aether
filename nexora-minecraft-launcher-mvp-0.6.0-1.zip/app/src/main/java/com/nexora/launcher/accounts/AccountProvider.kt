package com.nexora.launcher.accounts

import com.nexora.launcher.core.OfflineAccount

interface AccountProvider {
    val kind: Kind
    fun current(): OfflineAccount?
    enum class Kind { OFFLINE_LOCAL, MICROSOFT_OFFICIAL }
}

class OfflineAccountProvider(private val manager: OfflineAccountManager) : AccountProvider {
    override val kind = AccountProvider.Kind.OFFLINE_LOCAL
    override fun current(): OfflineAccount? = manager.list().firstOrNull()
}
