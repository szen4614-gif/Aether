package com.nexora.launcher.runtime

import java.io.File
import java.io.RandomAccessFile

object ElfAbi {
    private const val ELF_MAGIC_0 = 0x7f
    private const val ELF_MAGIC_1 = 'E'.code
    private const val ELF_MAGIC_2 = 'L'.code
    private const val ELF_MAGIC_3 = 'F'.code
    private const val EM_AARCH64 = 183

    fun isArm64(file: File): Boolean = runCatching {
        RandomAccessFile(file, "r").use { raf ->
            if (raf.readUnsignedByte() != ELF_MAGIC_0 || raf.readUnsignedByte() != ELF_MAGIC_1 || raf.readUnsignedByte() != ELF_MAGIC_2 || raf.readUnsignedByte() != ELF_MAGIC_3) return false
            raf.seek(18)
            readU16Le(raf) == EM_AARCH64
        }
    }.getOrDefault(false)

    private fun readU16Le(raf: RandomAccessFile): Int = raf.readUnsignedByte() or (raf.readUnsignedByte() shl 8)
}
