package com.nexora.launcher.core

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LauncherLogger(context: Context) {
    private val file = File(context.filesDir, "launcher/logs/launcher.log").apply { parentFile?.mkdirs() }
    @Synchronized fun log(level: String, message: String) {
        val safe = message.replace(Regex("(?i)(token|password|secret)\\s*[=:]\\s*\\S+"), "$1=[REDACTED]")
        val line = "${SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(Date())} [$level] $safe\n"
        file.appendText(line)
    }
    fun path(): String = file.absolutePath
}
