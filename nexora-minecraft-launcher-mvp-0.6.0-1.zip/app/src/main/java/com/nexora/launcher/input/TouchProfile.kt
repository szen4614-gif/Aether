package com.nexora.launcher.input

data class TouchControl(val id:String,val x:Float,val y:Float,val size:Float,val alpha:Float,val action:String)
data class TouchLayout(val id:String,val name:String,val controls:List<TouchControl>)

object DefaultTouchLayouts {
    val bedrockLike=TouchLayout("bedrock-like","Bedrock-like",listOf(TouchControl("move",0.16f,0.76f,0.22f,0.72f,"move"),TouchControl("jump",0.84f,0.74f,0.12f,0.72f,"jump"),TouchControl("attack",0.84f,0.50f,0.12f,0.62f,"attack"),TouchControl("use",0.70f,0.50f,0.12f,0.62f,"use")))
}
