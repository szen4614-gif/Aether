package com.nexora.launcher.process

import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class MinecraftProcessManager {
    data class LaunchPlan(val executable: File, val arguments: List<String>, val environment: Map<String, String>, val workingDirectory: File)
    data class Result(val exitCode: Int, val stdout: List<String>, val stderr: List<String>)

    fun launch(plan: LaunchPlan, onLine: (stream: String, line: String) -> Unit, onExit: (Int) -> Unit): ProcessHandle {
        require(plan.executable.isFile) { "Java executable missing: ${plan.executable}" }
        require(plan.workingDirectory.isDirectory) { "Game directory missing: ${plan.workingDirectory}" }
        val pb = ProcessBuilder(listOf(plan.executable.absolutePath) + plan.arguments)
            .directory(plan.workingDirectory)
        pb.environment().putAll(plan.environment)
        val process = pb.start()
        val done = AtomicBoolean(false)
        thread(name = "nexora-mc-stdout") { process.inputStream.bufferedReader().forEachLine { onLine("stdout", it) } }
        thread(name = "nexora-mc-stderr") { process.errorStream.bufferedReader().forEachLine { onLine("stderr", it) } }
        thread(name = "nexora-mc-wait") {
            val code = process.waitFor()
            if (done.compareAndSet(false, true)) onExit(code)
        }
        return ProcessHandle(process)
    }
}

class ProcessHandle(private val process: Process) {
    fun isAlive(): Boolean = process.isAlive
    fun pid(): Long = runCatching { process.pid() }.getOrDefault(-1L)
    fun destroy() { process.destroy() }
    fun destroyForcibly() { process.destroyForcibly() }
}
