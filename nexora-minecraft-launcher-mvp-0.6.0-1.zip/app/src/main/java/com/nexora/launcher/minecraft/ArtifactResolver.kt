package com.nexora.launcher.minecraft

import java.io.File

class ArtifactResolver(private val gameRoot: File) {
    data class ResolvedArtifact(
        val source: String,
        val target: File,
        val integrity: IntegritySpec?,
        val kind: String,
        val classifier: String? = null,
        val extractExcludes: List<String> = emptyList()
    )

    fun resolve(manifest: VersionManifest, runtimeOs: String = "linux", runtimeArch: String = "aarch64"): List<ResolvedArtifact> = buildList {
        manifest.client?.let { add(ResolvedArtifact(it.url, File(gameRoot, it.path), it.sha1?.let { h -> IntegritySpec("SHA-1", h) }, "client")) }
        manifest.libraries.forEach { lib ->
            add(ResolvedArtifact(lib.url, File(gameRoot, "libraries/${lib.path}"), lib.sha1?.let { IntegritySpec("SHA-1", it) }, "library"))
            val classifierKey = lib.natives[runtimeOs]?.replace("${'$'}{arch}", if (runtimeArch == "aarch64") "64" else runtimeArch)
            val native = classifierKey?.let { key -> lib.classifiers.firstOrNull { it.classifier == key } }
            if (native != null) add(ResolvedArtifact(native.url, File(gameRoot, "libraries/${native.path}"), native.sha1?.let { IntegritySpec("SHA-1", it) }, "native", native.classifier, lib.extractExcludes))
        }
    }
}
