package com.nexora.launcher.minecraft

import org.json.JSONArray
import org.json.JSONObject

data class VersionRef(val id: String, val type: String, val url: String, val sha1: String?, val releaseTime: String?)
data class VersionIndex(val latestRelease: String?, val latestSnapshot: String?, val versions: List<VersionRef>)
data class Rule(val action: String, val osName: String? = null, val osArch: String? = null)
data class NativeArtifact(
    val classifier: String,
    val url: String,
    val sha1: String?,
    val size: Long?,
    val path: String,
    val rules: List<Rule> = emptyList()
)
data class LibraryArtifact(
    val name: String,
    val url: String,
    val sha1: String?,
    val size: Long?,
    val path: String,
    val rules: List<Rule> = emptyList(),
    val classifiers: List<NativeArtifact> = emptyList(),
    val natives: Map<String, String> = emptyMap(),
    val extractExcludes: List<String> = emptyList()
)
data class VersionManifest(
    val id: String,
    val type: String,
    val mainClass: String,
    val assetsId: String?,
    val assetsUrl: String?,
    val assetsSha1: String?,
    val client: LibraryArtifact?,
    val libraries: List<LibraryArtifact>,
    val jvmArguments: List<String>,
    val gameArguments: List<String>,
    val javaMajor: Int?
)

object VanillaManifestParser {
    fun parseIndex(text: String): VersionIndex {
        val root = JSONObject(text)
        val latest = root.optJSONObject("latest")
        val versions = root.optJSONArray("versions") ?: JSONArray()
        return VersionIndex(
            latest?.optString("release")?.takeIf { it.isNotBlank() },
            latest?.optString("snapshot")?.takeIf { it.isNotBlank() },
            (0 until versions.length()).map { i ->
                val v = versions.getJSONObject(i)
                VersionRef(v.getString("id"), v.getString("type"), v.getString("url"), v.optString("sha1").takeIf { it.isNotBlank() }, v.optString("releaseTime").takeIf { it.isNotBlank() })
            }
        )
    }

    fun parseVersion(text: String): VersionManifest {
        val root = JSONObject(text)
        val javaMajor = root.optJSONObject("javaVersion")?.optInt("majorVersion")?.takeIf { it > 0 }
        val args = root.optJSONObject("arguments")
        val jvm = args?.optJSONArray("jvm")?.let(::parseArgumentArray) ?: emptyList()
        val game = args?.optJSONArray("game")?.let(::parseArgumentArray)
            ?: root.optString("minecraftArguments").takeIf { it.isNotBlank() }?.split(" ") ?: emptyList()
        val assetIndex = root.optJSONObject("assetIndex")
        val client = root.optJSONObject("downloads")?.optJSONObject("client")?.let { download ->
            LibraryArtifact("minecraft-client-${root.getString("id")}", download.getString("url"), download.optString("sha1").takeIf { it.isNotBlank() }, download.optLong("size").takeIf { it > 0 }, "versions/${root.getString("id")}/${root.getString("id")}.jar")
        }
        val libraries = parseLibraries(root.optJSONArray("libraries") ?: JSONArray())
        return VersionManifest(root.getString("id"), root.optString("type", "release"), root.getString("mainClass"), root.optString("assets").takeIf { it.isNotBlank() }, assetIndex?.optString("url")?.takeIf { it.isNotBlank() }, assetIndex?.optString("sha1")?.takeIf { it.isNotBlank() }, client, libraries, jvm, game, javaMajor)
    }

    private fun parseArgumentArray(array: JSONArray): List<String> = buildList {
        for (i in 0 until array.length()) {
            when (val item = array.get(i)) {
                is String -> add(item)
                is JSONObject -> if (ruleSetAllows(item.optJSONArray("rules"))) {
                    when (val value = item.opt("value")) {
                        is String -> add(value)
                        is JSONArray -> for (j in 0 until value.length()) add(value.getString(j))
                    }
                }
            }
        }
    }

    private fun parseLibraries(array: JSONArray): List<LibraryArtifact> = buildList {
        for (i in 0 until array.length()) {
            val lib = array.getJSONObject(i)
            if (!ruleSetAllows(lib.optJSONArray("rules"))) continue
            val downloads = lib.optJSONObject("downloads") ?: continue
            val artifact = downloads.optJSONObject("artifact")
            val classifiersJson = downloads.optJSONObject("classifiers")
            val classifiers = classifiersJson?.let { obj ->
                obj.keys().asSequence().mapNotNull { key ->
                    val a = obj.optJSONObject(key) ?: return@mapNotNull null
                    val path = a.optString("path").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                    NativeArtifact(key, a.getString("url"), a.optString("sha1").takeIf { it.isNotBlank() }, a.optLong("size").takeIf { it > 0 }, path)
                }.toList()
            } ?: emptyList()
            val nativesJson = lib.optJSONObject("natives")
            val natives = nativesJson?.keys()?.asSequence()?.associateWith { nativesJson.getString(it) } ?: emptyMap()
            val excludes = lib.optJSONObject("extract")?.optJSONArray("exclude")?.let { a -> (0 until a.length()).map(a::getString) } ?: emptyList()
            if (artifact != null) {
                val path = artifact.optString("path").takeIf { it.isNotBlank() } ?: continue
                add(LibraryArtifact(lib.getString("name"), artifact.getString("url"), artifact.optString("sha1").takeIf { it.isNotBlank() }, artifact.optLong("size").takeIf { it > 0 }, path, classifiers = classifiers, natives = natives, extractExcludes = excludes))
            } else if (classifiers.isNotEmpty()) {
                add(LibraryArtifact(lib.getString("name"), classifiers.first().url, classifiers.first().sha1, classifiers.first().size, classifiers.first().path, classifiers = classifiers, natives = natives, extractExcludes = excludes))
            }
        }
    }

    private fun ruleSetAllows(rules: JSONArray?): Boolean {
        if (rules == null || rules.length() == 0) return true
        var allowed = false
        for (i in 0 until rules.length()) {
            val rule = rules.getJSONObject(i)
            val os = rule.optJSONObject("os")
            val matches = os == null || (os.optString("name").let { it.isBlank() || it == "linux" || it == "android" } && os.optString("arch").let { it.isBlank() || it == "x86_64" || it == "aarch64" || it == "arm64" })
            if (matches) allowed = rule.optString("action") == "allow"
        }
        return allowed
    }
}
