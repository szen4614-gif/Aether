package com.nexora.launcher.core

interface LauncherModule { val id: String; fun start(); fun stop() }

data class MinecraftLaunchSpec(
    val instanceDirectory: String,
    val javaExecutable: String,
    val javaMajor: Int,
    val mainClass: String,
    val jvmArguments: List<String>,
    val gameArguments: List<String>,
    val classpath: List<String>,
    val nativesDirectory: String,
    val environment: Map<String, String> = emptyMap(),
    val workingDirectory: String = instanceDirectory
)

interface MinecraftProcessManager : LauncherModule {
    fun launch(spec: MinecraftLaunchSpec): Process
    fun isRunning(): Boolean
    fun stopProcess()
}
