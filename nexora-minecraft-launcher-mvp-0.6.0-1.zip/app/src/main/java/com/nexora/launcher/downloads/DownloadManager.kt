package com.nexora.launcher.downloads

import com.nexora.launcher.minecraft.ArtifactIntegrity
import com.nexora.launcher.minecraft.IntegritySpec
import java.io.File
import java.net.HttpURLConnection
import java.net.URI

class DownloadManager(
    private val allowedHosts: Set<String> = setOf("piston-meta.mojang.com", "piston-data.mojang.com", "libraries.minecraft.net")
) {
    fun download(url: String, target: File, integrity: IntegritySpec? = null, maxBytes: Long = 512L * 1024 * 1024, progress: (Long, Long) -> Unit = {}): File {
        val uri = URI(url)
        require(uri.scheme == "https") { "Only HTTPS downloads are allowed" }
        require(uri.host.lowercase() in allowedHosts) { "Host is not allowlisted: ${uri.host}" }
        target.parentFile?.mkdirs()
        if (target.isFile && (integrity == null || ArtifactIntegrity.verify(target, integrity))) return target
        val part = File(target.parentFile, ".${target.name}.part")
        var offset = if (part.isFile) part.length() else 0L
        val connection = open(uri.toURL().toString(), offset)
        connection.use {
            val code = it.responseCode
            if (offset > 0 && code == HttpURLConnection.HTTP_OK) { part.delete(); offset = 0L; return download(url, target, integrity, maxBytes, progress) }
            require(code == HttpURLConnection.HTTP_OK || code == HttpURLConnection.HTTP_PARTIAL) { "HTTP $code" }
            val total = if (it.contentLengthLong >= 0) offset + it.contentLengthLong else -1L
            require(total <= maxBytes || total < 0) { "Artifact exceeds size limit" }
            it.inputStream.use { input -> part.outputStream().use { output ->
                if (offset > 0) output.channel.position(offset)
                val buffer = ByteArray(64 * 1024); var done = offset
                while (true) { val n = input.read(buffer); if (n < 0) break; done += n; require(done <= maxBytes) { "Artifact exceeds size limit" }; output.write(buffer, 0, n); progress(done, total) }
            }}
        }
        if (integrity != null) require(ArtifactIntegrity.verify(part, integrity)) { "Artifact integrity mismatch" }
        if (target.exists()) target.delete()
        check(part.renameTo(target)) { "Could not finalize download" }
        return target
    }

    private fun open(url: String, offset: Long): HttpURLConnection {
        val c = URI(url).toURL().openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = false
        if (offset > 0) c.setRequestProperty("Range", "bytes=$offset-")
        c.connect()
        if (c.responseCode in 300..399) {
            val location = c.getHeaderField("Location") ?: error("Redirect without Location")
            c.disconnect()
            val redirected = URI(location)
            require(redirected.scheme == "https" && redirected.host.lowercase() in allowedHosts) { "Redirect target is not allowlisted" }
            return open(redirected.toString(), offset)
        }
        return c
    }
}
