package com.nexora.launcher.runtime

import java.io.File

data class RuntimeDescriptor(
    val id: String,
    val home: File,
    val major: Int,
    val abi: String,
    val source: RuntimeSource,
    val integrityVerified: Boolean,
    val integrityAlgorithm: String? = null,
    val integrityDigest: String? = null
)

enum class RuntimeSource { APK_BUNDLED, APK_NATIVE, APP_MANAGED, EXTERNAL }

interface RuntimeProvider {
    fun findCompatible(requiredMajor: Int, abi: String): RuntimeDescriptor?
}
