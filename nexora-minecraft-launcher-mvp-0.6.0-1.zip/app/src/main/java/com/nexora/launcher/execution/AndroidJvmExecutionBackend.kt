package com.nexora.launcher.execution

import com.nexora.launcher.core.MinecraftLaunchSpec
import com.nexora.launcher.nativebridge.NativeJvmBridge
import com.nexora.launcher.runtime.RuntimeProvider
import java.io.File
import java.util.concurrent.atomic.AtomicReference

/**
 * Android backend owns the embedded JVM lifecycle. It is intentionally separate from ProcessBuilder.
 * The current implementation is a synchronous execution primitive for the POC; Minecraft integration
 * will move the same ownership to a dedicated runtime thread and lifecycle coordinator.
 */
class AndroidJvmExecutionBackend(
    private val runtimeProvider: RuntimeProvider,
    private val abi: String
) : AndroidJvmBackend {
    private val state = AtomicReference(ExecutionState.EXITED)
    private var thread: Thread? = null

    override fun start(spec: MinecraftLaunchSpec) {
        check(state.get() == ExecutionState.EXITED || state.get() == ExecutionState.FAILED) { "Execution already active" }
        state.set(ExecutionState.STARTING)
        thread = Thread({
            runCatching {
                val descriptor = runtimeProvider.findCompatible(spec.javaMajor, abi) ?: error("No compatible Android runtime for Java ${spec.javaMajor}")
                val logs = File(spec.instanceDirectory, "logs").apply { mkdirs() }
                state.set(ExecutionState.RUNNING)
                val rc = NativeJvmBridge.runMain(
                    descriptor,
                    spec.classpath.joinToString(File.pathSeparator),
                    spec.mainClass,
                    spec.jvmArguments.toTypedArray(),
                    spec.gameArguments.toTypedArray(),
                    File(logs, "stdout.txt").absolutePath,
                    File(logs, "stderr.txt").absolutePath,
                    spec.nativesDirectory
                )
                state.set(ExecutionState.EXITED)
            }.onFailure {
                state.set(ExecutionState.FAILED)
            }
        }, "nexora-android-jvm")
        thread!!.start()
    }

    override fun stop() {
        state.set(ExecutionState.STOPPING)
        // POC: NativeJvmBridge.runMain owns the synchronous JVM lifetime. An interrupt cannot safely
        // destroy an arbitrary JVM. A cooperative shutdown protocol is required before Minecraft boot.
        thread?.interrupt()
    }

    override fun state(): ExecutionState = state.get()
}
