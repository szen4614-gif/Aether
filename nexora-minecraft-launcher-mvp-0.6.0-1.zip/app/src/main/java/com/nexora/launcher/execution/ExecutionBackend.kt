package com.nexora.launcher.execution

import com.nexora.launcher.core.MinecraftLaunchSpec

enum class ExecutionState {
    STARTING, RUNNING, STOPPING, EXITED, FAILED, JVM_CRASH, NATIVE_CRASH, SURFACE_LOST, APP_BACKGROUND, APP_FOREGROUND
}

interface ExecutionBackend {
    fun start(spec: MinecraftLaunchSpec)
    fun stop()
    fun state(): ExecutionState
}

interface DesktopProcessBackend : ExecutionBackend
interface AndroidJvmBackend : ExecutionBackend
