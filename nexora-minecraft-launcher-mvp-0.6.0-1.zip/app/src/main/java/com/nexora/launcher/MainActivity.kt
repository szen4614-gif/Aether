package com.nexora.launcher

import android.app.Activity
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import com.nexora.launcher.accounts.OfflineAccountManager
import com.nexora.launcher.core.LauncherLogger
import com.nexora.launcher.diagnostics.Diagnostics
import com.nexora.launcher.instances.InstanceRepository

class MainActivity:Activity(){
    private lateinit var log:LauncherLogger
    private lateinit var instances:InstanceRepository
    private lateinit var accounts:OfflineAccountManager
    private lateinit var diagnostics:Diagnostics
    override fun onCreate(state:Bundle?){super.onCreate(state); log=LauncherLogger(this);instances=InstanceRepository(this);accounts=OfflineAccountManager(this);diagnostics=Diagnostics(this);log.log("INFO","Launcher started");render()}
    private fun render(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,32,24,24);setBackgroundColor(Color.rgb(16,17,20))}
        val title=TextView(this).apply{text="NEXORA Launcher";textSize=30f;setTextColor(Color.WHITE);setTypeface(typeface,1)}
        val sub=TextView(this).apply{text="Minecraft Java Edition • Android • MVP 0.6";textSize=14f;setTextColor(Color.LTGRAY);setPadding(0,6,0,20)}
        root.addView(title);root.addView(sub)
        val hw=diagnostics.hardware(); root.addView(card("Hardware", "${hw.tier} • ${hw.abi} • ${hw.ramMb} MB • ${hw.cores} cores"))
        root.addView(card("Instâncias", "${instances.list().size} configurada(s)"))
        root.addView(card("Contas offline", "${accounts.list().size} perfil(is) local(is)"))
        val play=Button(this).apply{text="JOGAR";setOnClickListener{Toast.makeText(context,"Execução Minecraft ainda depende do módulo de runtime/manifesto; nenhuma instalação proprietária foi incluída.",Toast.LENGTH_LONG).show()}}
        root.addView(play,LinearLayout.LayoutParams(-1,60).apply{setMargins(0,18,0,8)})
        val new=Button(this).apply{text="CRIAR INSTÂNCIA";setOnClickListener{val i=instances.create("Vanilla");log.log("INFO","Created instance ${i.id}");render()}}
        root.addView(new)
        val account=Button(this).apply{text="CRIAR CONTA OFFLINE";setOnClickListener{accounts.create("Player");log.log("INFO","Created offline profile");render()}}
        root.addView(account)
        val diag=Button(this).apply{text="DIAGNOSTICAR INSTALAÇÃO";setOnClickListener{AlertDialogHelper.show(this@MainActivity,"Diagnóstico",diagnostics.report())}}
        root.addView(diag)
        val footer=TextView(this).apply{text="Offline-first • ARM64-first • sem arquivos proprietários do Minecraft";setTextColor(Color.GRAY);gravity=Gravity.CENTER;setPadding(0,24,0,0)};root.addView(footer)
        setContentView(root)
    }
    private fun card(a:String,b:String)=TextView(this).apply{text="$a\n$b";textSize=16f;setTextColor(Color.WHITE);setPadding(16,16,16,16);setBackgroundColor(Color.rgb(30,31,36));layoutParams=LinearLayout.LayoutParams(-1,80).apply{setMargins(0,0,0,10)}}
}
object AlertDialogHelper{fun show(a:Activity,title:String,msg:String){android.app.AlertDialog.Builder(a).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show()}}
