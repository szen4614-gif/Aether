package com.nexora.launcher.minecraft

import java.io.File
import java.security.MessageDigest

/** Integrity is distinct from authenticity/provenance. The manifest's declared algorithm is authoritative. */
data class IntegritySpec(val algorithm: String, val expected: String)

object ArtifactIntegrity {
    fun verify(file: File, spec: IntegritySpec): Boolean {
        require(spec.expected.isNotBlank()) { "Missing expected digest" }
        val md = MessageDigest.getInstance(spec.algorithm.replace("-", "").uppercase())
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                md.update(buffer, 0, n)
            }
        }
        val actual = md.digest().joinToString("") { "%02x".format(it) }
        return actual.equals(spec.expected, ignoreCase = true)
    }
}
