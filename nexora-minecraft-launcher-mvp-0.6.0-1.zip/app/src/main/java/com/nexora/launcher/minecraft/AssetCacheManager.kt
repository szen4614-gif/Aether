package com.nexora.launcher.minecraft

import com.nexora.launcher.downloads.DownloadManager
import java.io.File
import java.net.HttpURLConnection
import java.net.URI

/** Deterministic per-instance asset cache: indexes/<id>.json and objects/<prefix>/<hash>. */
class AssetCacheManager(private val downloadManager: DownloadManager) {
    data class PreparedAssets(val indexFile: File, val objectsRoot: File, val missingObjects: Int)

    fun prepare(instanceRoot: File, manifest: VersionManifest): PreparedAssets {
        val assetsId = requireNotNull(manifest.assetsId) { "Version has no assets id" }
        val assetsUrl = requireNotNull(manifest.assetsUrl) { "Version has no asset index URL" }
        val assetsRoot = File(instanceRoot, "assets")
        val indexFile = File(assetsRoot, "indexes/$assetsId.json")
        downloadManager.download(assetsUrl, indexFile, manifest.assetsSha1?.let { IntegritySpec("SHA-1", it) }, maxBytes = 64L * 1024 * 1024)
        val objects = AssetResolver().parseIndex(indexFile.readText())
        var missing = 0
        objects.forEach { objectRef ->
            val target = AssetResolver().target(assetsRoot, objectRef.hash)
            if (!target.isFile || !ArtifactIntegrity.verify(target, IntegritySpec("SHA-1", objectRef.hash))) missing++
        }
        return PreparedAssets(indexFile, File(assetsRoot, "objects"), missing)
    }

    fun downloadAllObjects(instanceRoot: File): Int {
        val assetsRoot = File(instanceRoot, "assets")
        val indexFiles = File(assetsRoot, "indexes").listFiles()?.filter { it.isFile && it.extension == "json" } ?: return 0
        var downloaded = 0
        for (index in indexFiles) {
            for (object in AssetResolver().parseIndex(index.readText())) {
                val target = AssetResolver().target(assetsRoot, object.hash)
                if (!target.isFile || !ArtifactIntegrity.verify(target, IntegritySpec("SHA-1", object.hash))) {
                    downloadManager.download(object.url, target, IntegritySpec("SHA-1", object.hash), maxBytes = 64L * 1024 * 1024)
                    downloaded++
                }
            }
        }
        return downloaded
    }
}
