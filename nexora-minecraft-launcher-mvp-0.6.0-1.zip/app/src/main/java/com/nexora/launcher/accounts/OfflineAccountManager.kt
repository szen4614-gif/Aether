package com.nexora.launcher.accounts

import android.content.Context
import com.nexora.launcher.android.StorageManager
import com.nexora.launcher.core.OfflineAccount
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class OfflineAccountManager(context: Context) {
    private val file = File(StorageManager(context).accounts, "offline.json")
    fun list(): List<OfflineAccount> = if (!file.exists()) emptyList() else runCatching {
        val a = JSONArray(file.readText()); (0 until a.length()).map { val o=a.getJSONObject(it); OfflineAccount(o.getString("id"),o.getString("name"),o.getString("uuid")) }
    }.getOrDefault(emptyList())
    fun create(name: String): OfflineAccount {
        val clean=name.trim().ifBlank{"Player"}; val id=clean.lowercase().replace(" ","-")
        val digest=MessageDigest.getInstance("SHA-256").digest("NEXORA-OFFLINE:$clean".toByteArray(StandardCharsets.UTF_8))
        val uuid=digest.copyOfRange(0,16).joinToString("") { "%02x".format(it) }
        val a=OfflineAccount(id,clean,uuid); val all=list().filterNot{it.id==id}+a; val arr=JSONArray(); all.forEach{arr.put(JSONObject().apply{put("id",it.id);put("name",it.name);put("uuid",it.uuid)})}; file.writeText(arr.toString(2)); return a
    }
}
