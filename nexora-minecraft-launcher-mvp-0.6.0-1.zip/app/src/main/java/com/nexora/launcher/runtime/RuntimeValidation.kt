package com.nexora.launcher.runtime

import java.io.File

enum class RuntimeEvidenceState {
    DISCOVERED,
    INTEGRITY_VERIFIED,
    STRUCTURE_VERIFIED,
    NATIVE_LOADABLE,
    JVM_INITIALIZED,
    JAVA_EXECUTED,
    LWJGL_INITIALIZED,
    MINECRAFT_COMPATIBLE
}

enum class ValidationStatus { PASS, FAIL, NOT_TESTED }

data class ValidationCheck(
    val name: String,
    val status: ValidationStatus,
    val detail: String
)

data class RuntimeValidationReport(
    val runtimeId: String,
    val checks: List<ValidationCheck>,
    val highestState: RuntimeEvidenceState?
) {
    val passed: Boolean get() = checks.isNotEmpty() && checks.all { it.status == ValidationStatus.PASS } && highestState != null
}

class RuntimeValidator {
    fun validateStructure(
        descriptor: RuntimeDescriptor,
        expectedAbi: String,
        requiredMajor: Int,
        requiredFiles: List<String> = listOf(
            "lib/server/libjvm.so",
            "lib/libjli.so",
            "lib/libjava.so",
            "lib/libnet.so",
            "lib/libnio.so",
            "release"
        )
    ): RuntimeValidationReport {
        val checks = mutableListOf<ValidationCheck>()
        checks += ValidationCheck("ABI", if (descriptor.abi == expectedAbi) ValidationStatus.PASS else ValidationStatus.FAIL, "expected=$expectedAbi actual=${descriptor.abi}")
        checks += ValidationCheck("Java major", if (descriptor.major == requiredMajor) ValidationStatus.PASS else ValidationStatus.FAIL, "expected=$requiredMajor actual=${descriptor.major}")
        checks += ValidationCheck("Integrity", if (descriptor.integrityVerified) ValidationStatus.PASS else ValidationStatus.FAIL, "integrity.verified=${descriptor.integrityVerified}")

        val missing = requiredFiles.filterNot { File(descriptor.home, it).isFile }
        checks += ValidationCheck("Required files", if (missing.isEmpty()) ValidationStatus.PASS else ValidationStatus.FAIL, if (missing.isEmpty()) "all required files present" else "missing=${missing.joinToString()}")
        val releaseText = File(descriptor.home, "release").takeIf(File::isFile)?.readText().orEmpty()
        checks += ValidationCheck("Runtime metadata", if (releaseText.isNotBlank()) ValidationStatus.PASS else ValidationStatus.FAIL, if (releaseText.isNotBlank()) "release metadata present" else "release metadata missing")

        val highest = when {
            checks.any { it.status == ValidationStatus.FAIL } -> null
            descriptor.integrityVerified -> RuntimeEvidenceState.STRUCTURE_VERIFIED
            else -> RuntimeEvidenceState.DISCOVERED
        }
        return RuntimeValidationReport(descriptor.id, checks, highest)
    }
}
