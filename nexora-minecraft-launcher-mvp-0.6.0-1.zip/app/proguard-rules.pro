# MVP: keep default Android optimization rules.
