# NEXORA Minecraft Java Launcher — real implementation foundation

This repository is an **incremental Android implementation**, not an HTML mockup. It follows the supplied NEXORA and launcher specifications: modular core, ARM64 priority, offline-first behavior, isolated instances, secure file handling, diagnostics and benchmark hooks.

## Honest status

**Implemented in this MVP:**
- Android application shell (Kotlin/Android Gradle)
- persistent instance registry and isolated instance directories
- offline local profiles with deterministic UUID-like identifiers
- hardware profile detection
- structured launcher log file with basic secret redaction
- storage/cache/download/runtime directory model
- HTTPS download primitive with SHA-256 verification
- path traversal protection primitive
- touch-layout data model
- diagnostics report
- benchmark timing primitive
- GitHub Actions build pipeline

**Not yet implemented:**
- real Minecraft version manifest resolution and asset/library installation
- official Microsoft authentication flow
- embedded Java runtime distribution/selection for all required versions
- actual Minecraft process bootstrap and native graphics/input bridge
- Fabric/Forge/NeoForge/Quilt installer integrations
- content APIs, browser sandbox, mod dependency solver
- resource-pack/shader/world managers
- production touchscreen overlay connected to Java input

These omissions are deliberate: the repository does not claim a working Minecraft launch until the relevant modules are implemented and tested.

## NEXORA strategy

The supplied NEXORA specification requires a Compiler 0 → Minimal NEXORA → Compiler 1 → self-hosting path and explicitly says the first implementation must not invent nonexistent APIs. Because this repository does not contain a working NEXORA compiler/runtime yet, the Android MVP uses Kotlin as the **bootstrap implementation language**, while keeping launcher modules behind interfaces and documenting a migration boundary. The NEXORA compiler is a separate workstream and must be validated before replacing Kotlin modules.

## Build on GitHub

The workflow installs a known Gradle version and runs `assembleDebug` plus unit tests. No Minecraft proprietary files are stored here.

## Legal boundary

The launcher is intended to work with Minecraft files obtained through legitimate user-authorized channels. Do not commit proprietary Minecraft binaries, credentials, tokens or copyrighted assets.

## 0.3 direction: Android ARM64 Java POC

The project now has an explicit native JVM bridge boundary and device capability detection. It does not bundle a JVM and does not claim JVM execution yet. The next evidence gate is an ARM64 Android device executing a validated existing mobile OpenJDK runtime and running a minimal Java class.

TARGET_VERSION for the first Vanilla boot is Minecraft 1.20.4.

## MVP 0.4 — execution evidence boundary

The 0.4 cycle separates JVM initialization from Java execution and introduces:

- Android Java POC with a real `main()` call;
- stdout/stderr redirection and exit result;
- JNI Java → native `.so` → Java round-trip;
- independent runtime evidence states;
- `RuntimeValidator` and native dependency diagnostics;
- `ExecutionBackend` split between desktop process execution and Android embedded JVM execution;
- first-class Minecraft native classifier modeling;
- deterministic asset index/object cache preparation;
- exact Java 17 ARM64 runtime candidate record for the first device test.

**Important:** this workspace still has no Android SDK/NDK/Gradle toolchain capable of producing and installing the APK, and no real ARM64 device evidence is available here. Therefore `ANDROID_JAVA_POC`, `ANDROID_LWJGL_POC` and `VANILLA_1_20_4_BOOT` remain **NOT VERIFIED ON DEVICE**.

## MVP 0.5 execution gate

The next milestone is evidence-first. `ANDROID_JAVA_POC` remains `NOT VERIFIED` until a real ARM64 Android device executes the bundled Java/JNI probe with a verified Java 17 Android runtime and records successful JVM initialization, Java execution, JNI round-trip, stdout/stderr, and `DestroyJavaVM()`.

## MVP 0.6 — Android Java verification app

A separate `:android-java-verification` APK now isolates the first executable question: whether an Android ARM64 OpenJDK 17 can be loaded through the JNI Invocation API and execute a Java main method that performs a native 41→42 round trip. The app is intentionally disposable and does not share launcher UI or production execution state.

Use `./tools/device-verify/run.sh` when Android SDK/NDK, ADB, an ARM64 device and an extracted runtime are available. The command never promotes source/build evidence into execution/functional PASS.

## 0.6 — Android Java verification experiment

`android-java-verification/` is a separate disposable APK whose only job is to establish the Android ARM64 Java execution chain. It reports explicit evidence markers and uses `tools/device-verify/run.sh` as the mechanical device gate. `ANDROID_JAVA_POC` remains NOT VERIFIED until a real ARM64 Android device produces `FINAL=PASS`.

The runtime archive is never considered verified from a public hash alone. `tools/runtime-inspect/inspect.sh` inspects the supplied binary itself, including ELF/ABI, dynamic dependencies, SONAME/RPATH/RUNPATH and `JNI_CreateJavaVM`.


### Android runtime loading model

The 0.6 verification app intentionally separates executable native runtime code from JRE data. OpenJDK `.so` files are prepared for APK `lib/arm64-v8a/`; non-native JRE data is provisioned into app-private storage. The verification gate does not treat a writable private `.so` tree as an Android execution solution. See `docs/ANDROID_RUNTIME_LOADING.md`.
