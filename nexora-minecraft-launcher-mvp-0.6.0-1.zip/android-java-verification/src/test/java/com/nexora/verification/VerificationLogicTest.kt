package com.nexora.verification

import org.junit.Assert.assertNotNull
import org.junit.Test
import java.io.File

class VerificationLogicTest {
    @Test fun missingRuntimeHasNoDigest() {
        assertNotNull(RuntimeDigest.sha256Tree(File("/path/that/does/not/exist")) == null)
    }
}
