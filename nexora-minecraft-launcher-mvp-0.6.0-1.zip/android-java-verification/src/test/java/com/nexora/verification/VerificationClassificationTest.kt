package com.nexora.verification

import org.junit.Assert.assertEquals
import org.junit.Test

enum class VerificationKind { PASS, EXPECTED_FAILURE, CRASH, INFRASTRUCTURE_FAILURE }
fun classify(lines: List<String>): VerificationKind = when {
    lines.any { it.startsWith("FINAL=PASS") } -> VerificationKind.PASS
    lines.any { it.startsWith("FINAL=EXPECTED_FAILURE") } -> VerificationKind.EXPECTED_FAILURE
    lines.any { it.startsWith("FINAL=CRASH") } -> VerificationKind.CRASH
    lines.any { it.startsWith("FINAL=INFRASTRUCTURE_FAILURE") } -> VerificationKind.INFRASTRUCTURE_FAILURE
    else -> VerificationKind.INFRASTRUCTURE_FAILURE
}
class VerificationClassificationTest {
    @Test fun separatesOutcomes() {
        assertEquals(VerificationKind.PASS, classify(listOf("FINAL=PASS")))
        assertEquals(VerificationKind.EXPECTED_FAILURE, classify(listOf("FINAL=EXPECTED_FAILURE:CLASS_MISSING")))
        assertEquals(VerificationKind.CRASH, classify(listOf("FINAL=CRASH:UnsatisfiedLinkError")))
        assertEquals(VerificationKind.INFRASTRUCTURE_FAILURE, classify(listOf("FINAL=INFRASTRUCTURE_FAILURE:RUNTIME_MISSING")))
    }
}
