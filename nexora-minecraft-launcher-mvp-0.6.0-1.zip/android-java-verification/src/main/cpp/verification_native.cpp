#include <jni.h>

extern "C" JNIEXPORT jint JNICALL
Java_com_nexora_poc_HelloWorld_nativeRoundTrip(JNIEnv *, jclass, jint value) {
    return value + 1;
}
