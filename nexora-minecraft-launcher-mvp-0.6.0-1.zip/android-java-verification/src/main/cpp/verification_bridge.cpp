#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <cstdlib>
#include <string>
#include <vector>
#include <mutex>

#define LOG_TAG "NEXORA_VERIFY"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using CreateJvmFn = jint (*)(JavaVM **, void **, void *);

static std::mutex g_mutex;
static JavaVM *g_vm = nullptr;
static std::vector<void*> g_handles;
static bool g_runCompleted = false;

static bool isFile(const std::string& p) { struct stat st{}; return stat(p.c_str(), &st) == 0 && S_ISREG(st.st_mode); }
static void closeHandles() { for (auto it = g_handles.rbegin(); it != g_handles.rend(); ++it) if (*it) dlclose(*it); g_handles.clear(); }
static std::string js(JNIEnv* env, jstring value) { if (!value) return {}; const char* p = env->GetStringUTFChars(value, nullptr); std::string out = p ? p : ""; if (p) env->ReleaseStringUTFChars(value, p); return out; }
static void add(std::vector<std::string>& out, const std::string& line) { out.push_back(line); LOGI("%s", line.c_str()); }
static bool exception(JNIEnv* env, const char* where, std::vector<std::string>& out) { if (!env->ExceptionCheck()) return false; env->ExceptionDescribe(); env->ExceptionClear(); add(out, std::string(where) + "=FAIL:Java exception"); return true; }
static std::string findJvm(const std::string& nativeDir) { const std::string p[] = {nativeDir+"/libjvm.so", nativeDir+"/lib/server/libjvm.so"}; for (const auto& x : p) if (isFile(x)) return x; return {}; }
static jobjectArray makeArray(JNIEnv* env, const std::vector<std::string>& values) { jclass c = env->FindClass("java/lang/String"); jobjectArray a = env->NewObjectArray((jsize)values.size(), c, nullptr); for (jsize i=0; i<(jsize)values.size(); ++i) { jstring s=env->NewStringUTF(values[i].c_str()); env->SetObjectArrayElement(a,i,s); env->DeleteLocalRef(s); } env->DeleteLocalRef(c); return a; }

static int runJvm(const std::string& home, const std::string& cp, const std::string& mainClass,
                  const std::vector<std::string>& args, const std::vector<std::string>& vmOptions,
                  const std::string& nativeDir, int fault, std::vector<std::string>& out) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_vm) { add(out, "STATE=FAIL:JVM_ALREADY_ACTIVE"); return -100; }
    if (g_runCompleted) { add(out, "STATE=FAIL:PROCESS_RESTART_REQUIRED"); add(out, "FINAL=INFRASTRUCTURE_FAILURE:PROCESS_RESTART_REQUIRED"); return -120; }
    add(out, "SOURCE=PASS"); add(out, "ABI=arm64-v8a");
    const std::string jvmPath = findJvm(nativeDir);
    if (jvmPath.empty()) { add(out, "LIBJVM=FAIL:not found"); return -101; }
    add(out, "LIBJVM=PASS:" + jvmPath);

    const std::string libDir=nativeDir;
    const char* old=getenv("LD_LIBRARY_PATH");
    const std::string merged=libDir+(old&&*old ? ":"+std::string(old) : "");
    if (setenv("LD_LIBRARY_PATH", merged.c_str(), 1) != 0) { add(out,"LD_LIBRARY_PATH=FAIL:setenv"); return -102; }
    add(out,"LD_LIBRARY_PATH=PASS");

    const std::string helpers[] = { libDir+"/libjli.so", libDir+"/libjava.so", libDir+"/libnet.so", libDir+"/libnio.so", libDir+"/libjsig.so", libDir+"/libverify.so" };
    for (const auto& p : helpers) {
        if (!isFile(p)) continue;
        void* h=dlopen(p.c_str(),RTLD_NOW|RTLD_GLOBAL);
        if (!h) { const char* e=dlerror(); add(out,std::string("DEPENDENCY=FAIL:")+p+":"+(e?e:"unknown")); closeHandles(); return -103; }
        g_handles.push_back(h); add(out,"DEPENDENCY=PASS:"+p);
    }

    void* jvmHandle=dlopen(jvmPath.c_str(),RTLD_NOW|RTLD_GLOBAL);
    if (!jvmHandle) { const char* e=dlerror(); add(out,std::string("JVM_LOAD=FAIL:")+(e?e:"unknown")); closeHandles(); return -104; }
    g_handles.push_back(jvmHandle); add(out,"JVM_LOAD=PASS"); add(out,"RUNTIME_NATIVE_LOADABLE=PASS");
    auto create=reinterpret_cast<CreateJvmFn>(dlsym(jvmHandle,"JNI_CreateJavaVM"));
    if (!create) { add(out,"JNI_CreateJavaVM=FAIL:not exported"); closeHandles(); return -105; }
    add(out,"JNI_CreateJavaVM=FOUND");

    std::vector<std::string> storage={"-Djava.home="+home,"-Djava.class.path="+cp,"-Djava.library.path="+nativeDir,"-Dnexora.poc.native.path="+nativeDir+"/libnexora_poc_native.so","-Djava.io.tmpdir="+home+"/tmp","-Djava.awt.headless=true"};
    storage.insert(storage.end(), vmOptions.begin(), vmOptions.end());
    std::vector<JavaVMOption> options(storage.size()); for (size_t i=0;i<options.size();++i) options[i].optionString=storage[i].data();
    JavaVMInitArgs vmArgs{}; vmArgs.version=JNI_VERSION_1_8; vmArgs.nOptions=(jint)options.size(); vmArgs.options=options.data(); vmArgs.ignoreUnrecognized=JNI_FALSE;

    JavaVM* vm=nullptr; JNIEnv* jni=nullptr;
    const jint createRc=create(&vm,reinterpret_cast<void**>(&jni),&vmArgs);
    if (createRc == JNI_OK) add(out,"JNI_CreateJavaVM=PASS:0"); else add(out,"JNI_CreateJavaVM=FAIL:"+std::to_string(createRc));
    if (createRc!=JNI_OK || !vm || !jni) { add(out,"JVM_INIT=FAIL"); closeHandles(); if (fault==6) add(out,"FINAL=EXPECTED_FAILURE:JVM_CREATE"); else add(out,"FINAL=FAIL:JNI_CREATE"); return createRc != 0 ? createRc : -106; }
    g_vm=vm; add(out,"JVM_INIT=PASS"); add(out,"JVM_INITIALIZED=PASS");

    int result=0;
    std::string targetMainClass = fault==1 ? "com.nexora.poc.MissingHelloWorld" : mainClass;
    std::string binary=targetMainClass; for(char& c:binary) if(c=='.') c='/';
    jclass cls=jni->FindClass(binary.c_str());
    if (exception(jni,"FindClass",out) || !cls) { add(out,"FindClass=FAIL:not found"); result=-107; }
    else add(out,"FindClass=PASS");
    jmethodID mainMethod=nullptr;
    if(result==0){ mainMethod=jni->GetStaticMethodID(cls,fault==2?"missingMain":"main","([Ljava/lang/String;)V"); if(exception(jni,"GetStaticMethodID",out)||!mainMethod){add(out,"main=FAIL:not found");result=-108;} else add(out,"main=FOUND"); }
    if(result==0){
        jclass sys=jni->FindClass("java/lang/System");
        if(fault==3 || fault==5){ jmethodID setp=jni->GetStaticMethodID(sys,"setProperty","(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;"); const char* key=fault==3?"nexora.poc.throw":"nexora.poc.failRoundTrip"; jstring k=jni->NewStringUTF(key),v=jni->NewStringUTF("true"); jni->CallStaticObjectMethod(sys,setp,k,v); jni->DeleteLocalRef(k); jni->DeleteLocalRef(v); jni->ExceptionClear(); }
        jclass sc=jni->FindClass("java/lang/String"); jobjectArray ja=jni->NewObjectArray((jsize)args.size(),sc,nullptr);
        for(jsize i=0;i<(jsize)args.size();++i){jstring a=jni->NewStringUTF(args[i].c_str());jni->SetObjectArrayElement(ja,i,a);jni->DeleteLocalRef(a);} 
        jni->CallStaticVoidMethod(cls,mainMethod,ja);
        if(exception(jni,"main",out)){add(out,"JAVA_EXEC=FAIL");result=-109;} else add(out,"JAVA_EXEC=PASS");
        if(result==0 && (fault==0 || fault==5)){ jmethodID getp=jni->GetStaticMethodID(sys,"getProperty","(Ljava/lang/String;)Ljava/lang/String;"); jstring key=jni->NewStringUTF("nexora.jni.result"); jobject value=jni->CallStaticObjectMethod(sys,getp,key); std::string got=value?js(jni,(jstring)value):""; if(got=="42") add(out,"JNI_ROUNDTRIP=PASS:41->42"); else {add(out,"JNI_ROUNDTRIP=FAIL:"+got); result=-111;} jni->DeleteLocalRef(key); }
        jni->DeleteLocalRef(ja); jni->DeleteLocalRef(sc); jni->DeleteLocalRef(sys);
    }
    if(cls) jni->DeleteLocalRef(cls);

    const jint destroyRc=vm->DestroyJavaVM();
    g_vm=nullptr; g_runCompleted=true; add(out,"DestroyJavaVM="+std::to_string(destroyRc));
    // Do not dlclose libjvm after a VM lifecycle. The Invocation API does not
    // promise safe re-loading of a JVM in the same process; the verification
    // app therefore treats one JVM lifecycle per process as the test boundary.
    if(fault==4){add(out,"JVM_SHUTDOWN=FAIL:INJECTED_TEST_HOOK");add(out,"FINAL=EXPECTED_FAILURE:SHUTDOWN_FAILURE");return result==0? -110:result;}
    if(destroyRc!=JNI_OK){add(out,"JVM_SHUTDOWN=FAIL");return result==0?destroyRc:result;}
    add(out,"JVM_SHUTDOWN=PASS");
    if(fault==3 && result!=0){add(out,"FINAL=EXPECTED_FAILURE:JAVA_EXCEPTION");return result;}
    if(fault==5 && result!=0){add(out,"JNI_ROUNDTRIP=FAIL:expected injected 41->40");add(out,"FINAL=EXPECTED_FAILURE:JNI_ROUNDTRIP");return result;}
    if(result!=0){add(out,"FINAL=FAIL");return result;}
    add(out,"FINAL=PASS"); return 0;
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_com_nexora_verification_VerificationBridge_run(JNIEnv* env,jclass,jstring home,jstring cp,jstring mainClass,jobjectArray args,jobjectArray vmOptions,jstring nativeDir,jint fault){
    std::vector<std::string> values,argsNative,optsNative;
    if(args){jsize n=env->GetArrayLength(args);for(jsize i=0;i<n;++i){auto a=(jstring)env->GetObjectArrayElement(args,i);argsNative.push_back(js(env,a));env->DeleteLocalRef(a);}}
    if(vmOptions){jsize n=env->GetArrayLength(vmOptions);for(jsize i=0;i<n;++i){auto a=(jstring)env->GetObjectArrayElement(vmOptions,i);optsNative.push_back(js(env,a));env->DeleteLocalRef(a);}}
    const int rc=runJvm(js(env,home),js(env,cp),js(env,mainClass),argsNative,optsNative,js(env,nativeDir),fault,values); values.push_back("RETURN_CODE="+std::to_string(rc)); return makeArray(env,values);
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_nexora_verification_VerificationBridge_isJvmActive(JNIEnv*,jclass){std::lock_guard<std::mutex> lock(g_mutex);return g_vm?JNI_TRUE:JNI_FALSE;}
