package com.nexora.verification

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.*
import java.io.File

class VerificationActivity : Activity() {
    private lateinit var log: TextView
    private fun runtimeHome() = File(filesDir, "verification-runtime")
    private fun nativeRuntimeDir() = File(applicationInfo.nativeLibraryDir)
    private fun probeJar() = File(filesDir, "probe/java-poc.jar")

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,16,16,16) }
        val title = TextView(this).apply { text = "ANDROID_JAVA_POC 0.6"; textSize = 22f }
        log = TextView(this).apply { textSize = 12f; typeface = android.graphics.Typeface.MONOSPACE; setTextIsSelectable(true) }
        val run = Button(this).apply { text = "RUN VERIFICATION"; setOnClickListener { execute(0) } }
        val failures = Button(this).apply { text = "RUN EXPECTED CLASS FAILURE"; setOnClickListener { execute(1) } }
        root.addView(title); root.addView(run); root.addView(failures)
        root.addView(ScrollView(this).apply { addView(log) }, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        append("READY\nABI=${Build.SUPPORTED_ABIS.joinToString()}\nRUNTIME=${runtimeHome().absolutePath}")
        if (intent.getBooleanExtra("RUN_POC", false)) execute(intent.getIntExtra("FAULT_MODE", 0))
    }

    private fun execute(faultMode: Int) {
        Thread {
            val runtime = runtimeHome()
            val probe = ensureProbeJar()
            append("RUNTIME_FOUND=${if (runtime.isDirectory) "PASS" else "FAIL"}")
            append("ABI=PASS:${Build.SUPPORTED_ABIS.joinToString()}")
            append("JAVA_MAJOR=${parseMajor(File(runtime,"release"))}")
            append("RUNTIME_DATA_SHA256=${RuntimeDigest.sha256Tree(runtime) ?: "NOT_AVAILABLE"}")
            val nativeDir = nativeRuntimeDir()
            val jvm = File(nativeDir, "libjvm.so")
            append("NATIVE_LIBRARY_DIR=${nativeDir.absolutePath}")
            append("LIBJVM=${if (jvm.isFile) jvm.absolutePath else "FAIL:not found in APK nativeLibraryDir"}")
            append("RUNTIME_NATIVE_LOADABLE=${if (jvm.isFile) "CANDIDATE" else "FAIL"}")
            append("PROBE_JAR=${probe.isFile}")
            if (!runtime.isDirectory || !jvm.isFile || !probe.isFile || Build.SUPPORTED_ABIS.none { it == "arm64-v8a" }) {
                append("FINAL=INFRASTRUCTURE_FAILURE:PRECONDITION"); return@Thread
            }
            val result = runCatching { VerificationBridge.run(runtime.absolutePath, probe.absolutePath, "com.nexora.poc.HelloWorld", arrayOf("NEXORA_ANDROID_JAVA_POC"), if (faultMode == 6) arrayOf("-XnexoraDefinitelyInvalidOption") else emptyArray(), nativeDir.absolutePath, faultMode).toList() }
            if (result.isFailure) { append("FINAL=CRASH:${result.exceptionOrNull()?.javaClass?.simpleName}:${result.exceptionOrNull()?.message}"); return@Thread }
            result.getOrThrow().forEach(::append)
        }.start()
    }

    private fun ensureProbeJar(): File { val out=probeJar(); if(out.isFile)return out; out.parentFile!!.mkdirs(); assets.open("poc/java-poc.jar").use{input->out.outputStream().use{input.copyTo(it)}}; return out }
    private fun parseMajor(release:File):String { if(!release.isFile)return "NOT_AVAILABLE"; return Regex("JAVA_VERSION=\\\"?(\\d+)").find(release.readText())?.groupValues?.get(1) ?: "NOT_AVAILABLE" }
    private fun append(text:String) { Log.i("NEXORA_VERIFY",text); runOnUiThread { log.append(text+"\n") } }
}
