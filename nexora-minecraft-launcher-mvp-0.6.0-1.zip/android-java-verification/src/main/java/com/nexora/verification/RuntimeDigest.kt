package com.nexora.verification

import java.io.File
import java.security.MessageDigest

object RuntimeDigest {
    fun sha256Tree(root: File): String? {
        if (!root.isDirectory) return null
        val md = MessageDigest.getInstance("SHA-256")
        val files = root.walkTopDown().filter { it.isFile }.sortedBy { it.relativeTo(root).path }.toList()
        for (file in files) {
            val rel = file.relativeTo(root).path.replace(File.separatorChar, '/')
            md.update(rel.toByteArray(Charsets.UTF_8)); md.update(0)
            file.inputStream().use { input -> val buf = ByteArray(1024 * 1024); while (true) { val n = input.read(buf); if (n < 0) break; md.update(buf, 0, n) } }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
