package com.nexora.verification

object VerificationBridge {
    init { System.loadLibrary("nexora_verification_bridge") }
    external fun run(home: String, classpath: String, mainClass: String, args: Array<String>, vmOptions: Array<String>, nativeLibDir: String, fault: Int): Array<String>
    external fun isJvmActive(): Boolean
}
